package com.horrorsteve.client;

import com.horrorsteve.config.HorrorClientConfig;
import com.horrorsteve.entity.HorrorSteveEntity;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.util.math.MathHelper;

/**
 * The vanilla player model plus the wrong things: head locked on the camera while the body looks elsewhere, broken
 * walking, arms in the wrong place, the 67 gesture, and the face distortion variants (scale, spin, tilt, vanish).
 */
public class HorrorSteveModel extends PlayerEntityModel<HorrorSteveEntity> {
    public HorrorSteveModel(ModelPart root) {
        super(root, false);
    }

    private static final float DEG = (float) (Math.PI / 180.0);

    @Override
    public void setAngles(HorrorSteveEntity e, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch) {
        boolean noLimbs = e.hasHsFlag(HorrorSteveEntity.F_NO_LIMBS) || e.hasHsFlag(HorrorSteveEntity.F_FROZEN) || e.hasHsFlag(HorrorSteveEntity.F_FLOAT);
        super.setAngles(e, noLimbs ? 0 : limbAngle, noLimbs ? 0 : limbDistance, animationProgress, headYaw, headPitch);

        // reset anything we change
        head.xScale = 1f;
        head.yScale = 1f;
        head.zScale = 1f;
        head.visible = true;
        hat.visible = true;

        if (e.hasHsFlag(HorrorSteveEntity.F_HEAD_LOCK)) {
            head.yaw = MathHelper.wrapDegrees(e.getLookYaw() - e.bodyYaw) * DEG * -1f;
            head.pitch = e.getLookPitch() * DEG;
        }
        if (e.hasHsFlag(HorrorSteveEntity.F_BROKEN_WALK)) {
            float t = animationProgress * 0.9f;
            leftLeg.pitch = MathHelper.sin(t) * 1.3f * Math.min(1f, limbDistance * 3f);
            rightLeg.pitch = MathHelper.sin(t) * 1.3f * Math.min(1f, limbDistance * 3f);
            leftArm.pitch = MathHelper.sin(t) * 1.4f;
            rightArm.pitch = MathHelper.sin(t) * 1.4f;
            leftLeg.roll = 0.25f;
            rightLeg.roll = -0.25f;
        }
        if (e.hasHsFlag(HorrorSteveEntity.F_ARMS_WRONG)) {
            leftArm.pitch = -2.9f + MathHelper.sin(animationProgress * 0.05f) * 0.1f;
            rightArm.pitch = 0.4f;
            rightArm.roll = 0.6f;
        }
        if (e.hasHsFlag(HorrorSteveEntity.F_TPOSE)) {
            leftArm.roll = -1.57f;
            rightArm.roll = 1.57f;
            leftArm.pitch = 0;
            rightArm.pitch = 0;
        }
        if (e.hasHsFlag(HorrorSteveEntity.F_TWITCH)) {
            float tw = MathHelper.sin(animationProgress * 9f) * MathHelper.sin(animationProgress * 0.7f);
            if (tw > 0.85f) {
                head.roll += 0.5f;
                head.yaw += 0.6f;
            }
        }
        if (e.hasHsFlag(HorrorSteveEntity.F_FLOAT)) {
            leftLeg.pitch = 0.1f;
            rightLeg.pitch = -0.1f;
            leftArm.roll = -0.15f;
            rightArm.roll = 0.15f;
        }

        // the 67 gesture: alternating raised palms with a bounce
        int anim = e.getAnim();
        if (anim == HorrorSteveEntity.ANIM_MEME67 || anim == HorrorSteveEntity.ANIM_MEME67_B) {
            float t = animationProgress * (anim == HorrorSteveEntity.ANIM_MEME67 ? 0.95f : 1.35f);
            float up = MathHelper.sin(t);
            leftArm.pitch = -1.45f - up * 0.75f;
            rightArm.pitch = -1.45f + up * 0.75f;
            leftArm.yaw = 0.25f;
            rightArm.yaw = -0.25f;
            leftArm.roll = -0.1f;
            rightArm.roll = 0.1f;
            head.pitch = -0.15f + MathHelper.sin(t * 2f) * 0.12f;
            head.roll = MathHelper.sin(t) * 0.12f;
            leftLeg.pitch = MathHelper.sin(t * 2f) * 0.25f;
            rightLeg.pitch = -MathHelper.sin(t * 2f) * 0.25f;
            body.pitch = MathHelper.sin(t * 2f) * 0.06f;
        } else if (anim == HorrorSteveEntity.ANIM_ARMS_UP) {
            leftArm.pitch = -3.0f;
            rightArm.pitch = -3.0f;
        }

        applyDistortion(e, animationProgress);
        hat.copyTransform(head);
        jacket.copyTransform(body);
    }

    private void applyDistortion(HorrorSteveEntity e, float animationProgress) {
        int v = e.getDistort();
        if (v == HorrorSteveEntity.D_NONE || !HorrorClientConfig.get().allowModelDistortion) return;
        float dt = Math.max(0f, animationProgress - e.distortStart);
        float s = (float) Math.max(0.2, HorrorClientConfig.get().effectStrength);
        switch (v) {
            case HorrorSteveEntity.D_SHAKE -> {
                head.yaw += MathHelper.sin(dt * 2.9f) * 0.55f * s;
                head.roll += MathHelper.sin(dt * 3.7f) * 0.3f * s;
            }
            case HorrorSteveEntity.D_TILT -> head.roll = 1.45f * Math.min(1f, dt / 6f);
            case HorrorSteveEntity.D_FLICKER -> {
                boolean off = ((int) (dt / 2f)) % 2 == 1;
                head.visible = !off;
                hat.visible = !off;
            }
            case HorrorSteveEntity.D_STRETCH -> {
                head.yScale = 1f + 1.3f * Math.min(1f, dt / 8f);
                head.xScale = 0.85f;
                head.zScale = 0.85f;
            }
            case HorrorSteveEntity.D_SQUASH -> {
                head.yScale = 0.45f;
                head.xScale = 1.5f;
                head.zScale = 1.5f;
            }
            case HorrorSteveEntity.D_BIG -> {
                float k = 1f + 0.8f * Math.min(1f, dt / 10f);
                head.xScale = k;
                head.yScale = k;
                head.zScale = k;
            }
            case HorrorSteveEntity.D_TINY -> {
                head.xScale = 0.5f;
                head.yScale = 0.5f;
                head.zScale = 0.5f;
            }
            case HorrorSteveEntity.D_SPIN -> head.yaw = dt * 0.75f;
            case HorrorSteveEntity.D_VANISH -> {
                head.visible = false;
                hat.visible = false;
            }
            case HorrorSteveEntity.D_LONGNECK -> {
                head.yScale = 2.2f + MathHelper.sin(dt * 0.4f) * 0.2f;
                head.xScale = 0.8f;
                head.zScale = 0.8f;
            }
            case HorrorSteveEntity.D_EYES -> {
                head.pitch += MathHelper.sin(dt * 1.7f) * 0.1f;
                head.yaw += MathHelper.sin(dt * 0.9f) * 0.15f;
            }
            case HorrorSteveEntity.D_UNKNOWN -> {
                head.yScale = 1.8f + MathHelper.sin(dt * 0.3f) * 0.5f;
                head.xScale = 0.8f;
                head.zScale = 0.8f;
                head.yaw = dt * 0.35f + MathHelper.sin(dt * 3f) * 0.4f;
                head.roll = MathHelper.sin(dt * 0.5f) * 0.6f;
            }
            default -> {
            }
        }
    }
}
