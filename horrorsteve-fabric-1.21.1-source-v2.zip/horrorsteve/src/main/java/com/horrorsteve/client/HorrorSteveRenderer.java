package com.horrorsteve.client;

import com.horrorsteve.HorrorSteveMod;
import com.horrorsteve.config.HorrorClientConfig;
import com.horrorsteve.entity.HorrorSteveEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.feature.HeldItemFeatureRenderer;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

import java.util.Optional;
import java.util.UUID;

/**
 * Renders Steve. Normal skin by default (the vanilla Steve texture), with replacement faces for distortion events.
 * Decoys are invisible to everyone except the player they were made for.
 */
public class HorrorSteveRenderer extends MobEntityRenderer<HorrorSteveEntity, HorrorSteveModel> {
    private static final Identifier NORMAL = Identifier.of("minecraft", "textures/entity/player/wide/steve.png");
    private static final Identifier BLANK = HorrorSteveMod.id("textures/entity/steve_blank.png");
    private static final Identifier DARK = HorrorSteveMod.id("textures/entity/steve_dark.png");
    private static final Identifier SMILE = HorrorSteveMod.id("textures/entity/steve_smile.png");
    private static final Identifier EYES = HorrorSteveMod.id("textures/entity/steve_eyes.png");

    public HorrorSteveRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new HorrorSteveModel(ctx.getPart(EntityModelLayers.PLAYER)), 0.5f);
        this.addFeature(new HeldItemFeatureRenderer<>(this, ctx.getHeldItemRenderer()));
    }

    @Override
    public Identifier getTexture(HorrorSteveEntity e) {
        int v = e.getDistort();
        if (v == HorrorSteveEntity.D_NONE || !HorrorClientConfig.get().allowModelDistortion) return NORMAL;
        float dt = Math.max(0, e.age - e.distortStart);
        return switch (v) {
            case HorrorSteveEntity.D_FLICKER -> ((int) (dt / 2f)) % 2 == 0 ? NORMAL : BLANK;
            case HorrorSteveEntity.D_BLANK -> BLANK;
            case HorrorSteveEntity.D_DARK -> DARK;
            case HorrorSteveEntity.D_SMILE -> SMILE;
            case HorrorSteveEntity.D_EYES -> EYES;
            case HorrorSteveEntity.D_UNKNOWN -> ((int) (dt / 3f)) % 3 == 0 ? EYES : DARK;
            default -> NORMAL;
        };
    }

    @Override
    public boolean shouldRender(HorrorSteveEntity e, Frustum frustum, double x, double y, double z) {
        Optional<UUID> only = e.getVisibleTo();
        if (only.isPresent()) {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || !only.get().equals(mc.player.getUuid())) return false;
        }
        return super.shouldRender(e, frustum, x, y, z);
    }

    @Override
    public void render(HorrorSteveEntity e, float yaw, float tickDelta, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light) {
        if (e.hasHsFlag(HorrorSteveEntity.F_BODY_LOCK)) {
            float lock = e.getBodyLockYaw();
            e.bodyYaw = lock;
            e.prevBodyYaw = lock;
        }
        matrices.push();
        int anim = e.getAnim();
        float t = e.age + tickDelta;
        if (anim == HorrorSteveEntity.ANIM_MEME67 || anim == HorrorSteveEntity.ANIM_MEME67_B) {
            float speed = anim == HorrorSteveEntity.ANIM_MEME67 ? 0.95f : 1.35f;
            matrices.translate(0, Math.abs(MathHelper.sin(t * speed * 2f)) * 0.12, 0);
        }
        if (e.hasHsFlag(HorrorSteveEntity.F_FLOAT)) {
            matrices.translate(0, 0.15 + MathHelper.sin(t * 0.1f) * 0.08, 0);
        }
        super.render(e, yaw, tickDelta, matrices, vertexConsumers, light);
        matrices.pop();
    }

    @Override
    protected boolean hasLabel(HorrorSteveEntity e) {
        return e.isCustomNameVisible() && e.hasCustomName() && super.hasLabel(e);
    }

    @SuppressWarnings("unused")
    private static Text unused() {
        return null;
    }
}
