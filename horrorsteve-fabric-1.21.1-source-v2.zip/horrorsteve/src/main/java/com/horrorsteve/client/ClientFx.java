package com.horrorsteve.client;

import com.horrorsteve.HorrorSteveMod;
import com.horrorsteve.config.HorrorClientConfig;
import com.horrorsteve.network.FxPayload;
import com.horrorsteve.network.OverlayPayload;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.Identifier;

import java.util.Random;

/**
 * Client-side effect state and HUD drawing. Everything here is filtered by horrorsteve-client.json, and every effect
 * is drawn on the HUD only: no real screen is ever replaced, no input is ever blocked, nothing is written to disk.
 */
public final class ClientFx {
    private static final Random RNG = new Random();
    private static final Identifier SMILE = HorrorSteveMod.id("textures/entity/steve_smile.png");

    private static int shakeTicks, vignetteTicks, darknessTicks, staticTicks, fovTicks, flashTicks, tiltTicks, blackoutTicks, glitchTicks;
    private static float shakeI, vignetteI, darknessI, staticI, fovI, flashI, blackoutI, glitchI;
    private static int fovDirection = 0;
    private static float lastDx, lastDy;
    private static int originalFov = -1;

    private static int overlayKind, overlayTicks, overlayMax;
    private static String overlayText = "";

    private ClientFx() {}

    private static float strength() {
        return (float) HorrorClientConfig.get().effectStrength;
    }

    public static void onFx(FxPayload p) {
        HorrorClientConfig c = HorrorClientConfig.get();
        float i = Math.max(0f, Math.min(1.5f, p.intensity())) * strength();
        if (strength() <= 0.01f) return;
        int t = Math.max(1, Math.min(2400, p.ticks()));
        switch (p.type()) {
            case FxPayload.SHAKE -> {
                if (c.allowScreenShake) {
                    shakeTicks = t;
                    shakeI = i;
                }
            }
            case FxPayload.VIGNETTE -> {
                if (c.allowVignette) {
                    vignetteTicks = t;
                    vignetteI = i;
                }
            }
            case FxPayload.DARKNESS -> {
                if (c.allowDarkness) {
                    darknessTicks = t;
                    darknessI = i;
                }
            }
            case FxPayload.STATIC -> {
                if (c.allowStaticNoise) {
                    staticTicks = t;
                    staticI = i;
                }
            }
            case FxPayload.FOV_NARROW, FxPayload.FOV_WIDE -> {
                if (c.allowFovEffects) {
                    fovTicks = t;
                    fovI = i;
                    fovDirection = p.type() == FxPayload.FOV_NARROW ? -1 : 1;
                }
            }
            case FxPayload.FLASH -> {
                if (c.allowFlashing) {
                    flashTicks = Math.max(3, t);
                    flashI = i;
                }
            }
            case FxPayload.BLACKOUT -> {
                if (c.allowDarkness) {
                    blackoutTicks = t;
                    blackoutI = 1f;
                }
            }
            case FxPayload.GLITCH -> {
                if (c.allowStaticNoise) {
                    glitchTicks = t;
                    glitchI = i;
                }
            }
            default -> {
            }
        }
    }

    public static void onOverlay(OverlayPayload p) {
        HorrorClientConfig c = HorrorClientConfig.get();
        if (strength() <= 0.01f) return;
        switch (p.kind()) {
            case OverlayPayload.FAKE_CRASH, OverlayPayload.FAKE_TITLE, OverlayPayload.FAKE_LOADING, OverlayPayload.FAKE_SAVING -> {
                if (!c.allowFakeScreens) return;
            }
            case OverlayPayload.FACE -> {
                if (!c.allowJumpscareVisuals) return;
            }
            default -> {
            }
        }
        overlayKind = p.kind();
        overlayText = p.text();
        overlayTicks = Math.max(1, Math.min(200, p.ticks()));
        overlayMax = overlayTicks;
    }

    public static void tick(MinecraftClient mc) {
        if (mc.player == null) {
            reset(mc);
            return;
        }
        if (shakeTicks > 0) {
            shakeTicks--;
            float dx = (RNG.nextFloat() - 0.5f) * 2f * shakeI * 1.6f;
            float dy = (RNG.nextFloat() - 0.5f) * 2f * shakeI * 1.2f;
            mc.player.setYaw(mc.player.getYaw() + dx - lastDx);
            mc.player.setPitch(Math.max(-90f, Math.min(90f, mc.player.getPitch() + dy - lastDy)));
            lastDx = dx;
            lastDy = dy;
            if (shakeTicks == 0) {
                mc.player.setYaw(mc.player.getYaw() - lastDx);
                mc.player.setPitch(Math.max(-90f, Math.min(90f, mc.player.getPitch() - lastDy)));
                lastDx = 0;
                lastDy = 0;
            }
        }
        if (vignetteTicks > 0) vignetteTicks--;
        if (darknessTicks > 0) darknessTicks--;
        if (staticTicks > 0) staticTicks--;
        if (flashTicks > 0) flashTicks--;
        if (blackoutTicks > 0) blackoutTicks--;
        if (glitchTicks > 0) glitchTicks--;
        if (overlayTicks > 0) overlayTicks--;
        if (fovTicks > 0) {
            if (originalFov < 0) originalFov = mc.options.getFov().getValue();
            fovTicks--;
            float k = Math.min(1f, fovTicks / 20f) * fovI;
            int target = Math.max(30, Math.min(110, originalFov + Math.round(fovDirection * 22f * k)));
            mc.options.getFov().setValue(target);
            if (fovTicks == 0) restoreFov(mc);
        }
    }

    public static void restoreFov(MinecraftClient mc) {
        if (originalFov >= 0 && mc.options != null) {
            mc.options.getFov().setValue(originalFov);
        }
        originalFov = -1;
    }

    public static void reset(MinecraftClient mc) {
        restoreFov(mc);
        shakeTicks = vignetteTicks = darknessTicks = staticTicks = fovTicks = flashTicks = tiltTicks = blackoutTicks = glitchTicks = 0;
        overlayTicks = 0;
        lastDx = lastDy = 0;
    }

    private static int argb(float alpha, int rgb) {
        int a = Math.max(0, Math.min(255, Math.round(alpha * 255f)));
        return (a << 24) | (rgb & 0xFFFFFF);
    }

    public static void render(DrawContext g, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        int w = g.getScaledWindowWidth();
        int h = g.getScaledWindowHeight();

        if (darknessTicks > 0) {
            float a = Math.min(1f, darknessTicks / 15f) * darknessI;
            g.fill(0, 0, w, h, argb(Math.min(0.85f, a), 0x000000));
        }
        if (vignetteTicks > 0) {
            float a = Math.min(1f, vignetteTicks / 30f) * vignetteI;
            int edge = argb(Math.min(0.9f, a), 0x000000);
            int clear = argb(0f, 0x000000);
            int bw = w / 4;
            int bh = h / 4;
            g.fillGradient(0, 0, w, bh, edge, clear);
            g.fillGradient(0, h - bh, w, h, clear, edge);
            for (int i = 0; i < 6; i++) {
                float f = 1f - i / 6f;
                int col = argb(Math.min(0.9f, a) * f * 0.5f, 0x000000);
                g.fill(i * (bw / 6), 0, (i + 1) * (bw / 6), h, col);
                g.fill(w - (i + 1) * (bw / 6), 0, w - i * (bw / 6), h, col);
            }
        }
        if (staticTicks > 0 || glitchTicks > 0) {
            float a = Math.min(1f, Math.max(staticTicks, glitchTicks) / 10f) * Math.max(staticI, glitchI);
            int n = (int) (140 * Math.min(1f, a));
            for (int i = 0; i < n; i++) {
                int x = RNG.nextInt(Math.max(1, w));
                int y = RNG.nextInt(Math.max(1, h));
                int gray = 80 + RNG.nextInt(170);
                g.fill(x, y, x + 2 + RNG.nextInt(8), y + 1 + RNG.nextInt(3), argb(0.5f * a, gray << 16 | gray << 8 | gray));
            }
            if (glitchTicks > 0 && RNG.nextInt(6) == 0) {
                int y = RNG.nextInt(Math.max(1, h));
                g.fill(0, y, w, y + 2 + RNG.nextInt(6), argb(0.18f * glitchI, 0xFF00FF));
            }
        }
        if (flashTicks > 0) {
            g.fill(0, 0, w, h, argb(Math.min(0.8f, 0.8f * flashI) * (flashTicks / 4f > 1f ? 1f : flashTicks / 4f), 0xFFFFFF));
        }
        if (blackoutTicks > 0) {
            float a = blackoutTicks > 5 ? 1f : blackoutTicks / 5f;
            g.fill(0, 0, w, h, argb(a * blackoutI, 0x000000));
        }
        if (overlayTicks > 0) drawOverlay(g, mc, w, h);
    }

    private static void drawOverlay(DrawContext g, MinecraftClient mc, int w, int h) {
        float life = overlayMax <= 0 ? 0 : 1f - (overlayTicks / (float) overlayMax);
        switch (overlayKind) {
            case OverlayPayload.TEXT_67 -> {
                float pop = Math.min(1f, life * 6f);
                float fade = overlayTicks < 8 ? overlayTicks / 8f : 1f;
                float scale = (4f + 6f * pop) * (h / 270f) * (1f + 0.04f * (float) Math.sin(life * 40f));
                drawBigText(g, mc, overlayText.isEmpty() ? "67" : overlayText, w, h, scale, argb(fade, 0xFFFFFF));
            }
            case OverlayPayload.BIG_TEXT -> drawBigText(g, mc, overlayText, w, h, 3f, argb(1f, 0xFFFFFF));
            case OverlayPayload.FACE -> {
                int size = Math.min(w, h);
                int x = (w - size) / 2;
                int y = (h - size) / 2;
                g.fill(0, 0, w, h, argb(0.85f, 0x000000));
                g.drawTexture(SMILE, x, y, size, size, 8, 8, 8, 8, 64, 64);
            }
            case OverlayPayload.FAKE_CRASH -> {
                g.fill(0, 0, w, h, 0xFF1E1E1E);
                var tr = mc.textRenderer;
                int y = h / 2 - 40;
                g.drawCenteredTextWithShadow(tr, "Minecraft Java Edition has stopped responding", w / 2, y, 0xFFFFFF);
                g.drawCenteredTextWithShadow(tr, "java.lang.IllegalStateException: Steve is already in this world", w / 2, y + 16, 0xFF5555);
                g.drawCenteredTextWithShadow(tr, "Generating crash report...", w / 2, y + 32, 0xAAAAAA);
                if (overlayTicks < overlayMax / 2) g.drawCenteredTextWithShadow(tr, "...just kidding.", w / 2, y + 56, 0x777777);
            }
            case OverlayPayload.FAKE_TITLE -> {
                g.fillGradient(0, 0, w, h, 0xFF101820, 0xFF050505);
                var tr = mc.textRenderer;
                drawBigText(g, mc, "MINECRAFT", w, h / 2, 3f, 0xFFB0B0B0);
                int bx = w / 2 - 100;
                String[] labels = {"Singleplayer", "Multiplayer", "Minecraft Realms", "Options..."};
                for (int i = 0; i < labels.length; i++) {
                    g.fill(bx, h / 2 + i * 24, bx + 200, h / 2 + i * 24 + 20, 0xFF3A3A3A);
                    g.drawCenteredTextWithShadow(tr, labels[i], w / 2, h / 2 + i * 24 + 6, 0xE0E0E0);
                }
            }
            case OverlayPayload.FAKE_LOADING, OverlayPayload.FAKE_SAVING -> {
                g.fill(0, 0, w, h, 0xFF2B1D12);
                var tr = mc.textRenderer;
                g.drawCenteredTextWithShadow(tr, overlayText.isEmpty() ? "Loading terrain..." : overlayText, w / 2, h / 2 - 12, 0xFFFFFF);
                int pct = Math.min(99, (int) (life * 100f));
                int bw = 182;
                int bx = w / 2 - bw / 2;
                g.fill(bx, h / 2 + 4, bx + bw, h / 2 + 10, 0xFF000000);
                g.fill(bx, h / 2 + 4, bx + (int) (bw * (pct / 100f)), h / 2 + 10, 0xFF55FF55);
                g.drawCenteredTextWithShadow(tr, pct + "%", w / 2, h / 2 + 16, 0xAAAAAA);
            }
            default -> {
            }
        }
    }

    private static void drawBigText(DrawContext g, MinecraftClient mc, String text, int w, int h, float scale, int color) {
        var tr = mc.textRenderer;
        var m = g.getMatrices();
        m.push();
        m.translate(w / 2f, h / 2f, 0);
        m.scale(scale, scale, 1f);
        int tw = tr.getWidth(text);
        g.drawText(tr, text, -tw / 2, -4, color, true);
        m.pop();
    }
}
