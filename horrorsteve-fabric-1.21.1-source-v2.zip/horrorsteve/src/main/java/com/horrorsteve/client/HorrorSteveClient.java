package com.horrorsteve.client;

import com.horrorsteve.config.HorrorClientConfig;
import com.horrorsteve.entity.ModEntities;
import com.horrorsteve.network.FxPayload;
import com.horrorsteve.network.OverlayPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;

public class HorrorSteveClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        HorrorClientConfig.load();
        EntityRendererRegistry.register(ModEntities.HORROR_STEVE, HorrorSteveRenderer::new);
        ClientPlayNetworking.registerGlobalReceiver(FxPayload.ID, (payload, context) -> ClientFx.onFx(payload));
        ClientPlayNetworking.registerGlobalReceiver(OverlayPayload.ID, (payload, context) -> ClientFx.onOverlay(payload));
        ClientTickEvents.END_CLIENT_TICK.register(ClientFx::tick);
        HudRenderCallback.EVENT.register(ClientFx::render);
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> ClientFx.reset(client));
        ClientLifecycleEvents.CLIENT_STOPPING.register(ClientFx::restoreFov);
    }
}
