package com.horrorsteve.fear;

import com.horrorsteve.progression.PlayerProfile;
import com.horrorsteve.progression.Trait;

/** The entity's estimate of how afraid the player is (0..100). Drives distortion, events and jumpscares. */
public final class FearTracker {
    private FearTracker() {}

    /** Called once per second per player. */
    public static void tick(PlayerProfile p, double entityDistance, boolean entityVisible, boolean faceLook,
                            int lightLevel, boolean underground, double health, boolean chased) {
        double d = -0.35;
        if (entityVisible && entityDistance < 24) d += 1.6;
        if (faceLook && entityDistance < 14) d += 2.2;
        if (lightLevel <= 3 && underground) d += 0.45;
        if (health <= 6) d += 0.5;
        if (chased) d += 2.5;
        p.fear = Math.max(0, Math.min(100, p.fear + d));
        if (d > 1.0) p.bump(Trait.FEARFUL, 0.05);
    }

    public static void spike(PlayerProfile p, double amount) {
        p.fear = Math.max(0, Math.min(100, p.fear + amount));
    }

    public static double level(PlayerProfile p) {
        return p.fear / 100.0;
    }
}
