package com.horrorsteve.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.horrorsteve.HorrorSteveMod;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/** Server-side configuration: config/horrorsteve.json */
public class HorrorConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static HorrorConfig instance = new HorrorConfig();

    public boolean modEnabled = true;
    /** Only "en" ships by default. Extra languages can be added as dialogue files. */
    public String language = "en";
    /** 0.0 (very mild) .. 2.0 (intense) */
    public double horrorIntensity = 1.0;
    public double entityFrequency = 1.0;
    public double eventFrequency = 1.0;
    public double dialogueFrequency = 1.0;
    public double jumpscareFrequency = 1.0;
    public double progressionSpeed = 1.0;
    public boolean soundEffects = true;
    public boolean music = true;
    public boolean loudSounds = true;
    public boolean cameraEffects = true;
    public boolean visualDistortion = true;
    public boolean jumpscares = true;
    public boolean fakeSystemMessages = true;
    public boolean blockDestruction = true;
    public int maxDestructionRadius = 6;
    public int restoreDelaySeconds = 90;
    public boolean structuresEnabled = true;
    /** PER_PLAYER: every player gets their own haunting. SHARED: the entity may switch targets. */
    public String multiplayerBehavior = "PER_PLAYER";
    public boolean meme67Enabled = true;
    public int meme67CooldownSeconds = 45;
    /** Seconds of playtime before anything happens at all. */
    public int graceSeconds = 300;
    public int maxEntitiesTotal = 6;
    public boolean debug = false;

    public static HorrorConfig get() {
        return instance;
    }

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("horrorsteve.json");
    }

    public static void load() {
        try {
            Path p = path();
            if (Files.exists(p)) {
                HorrorConfig loaded = GSON.fromJson(Files.readString(p), HorrorConfig.class);
                if (loaded != null) instance = loaded;
            }
            instance.sanitize();
            save();
        } catch (Exception e) {
            HorrorSteveMod.LOG.error("Could not read horrorsteve.json, using defaults", e);
            instance = new HorrorConfig();
        }
    }

    public static void save() {
        try {
            Files.createDirectories(path().getParent());
            Files.writeString(path(), GSON.toJson(instance));
        } catch (Exception e) {
            HorrorSteveMod.LOG.error("Could not write horrorsteve.json", e);
        }
    }

    private void sanitize() {
        horrorIntensity = clamp(horrorIntensity, 0, 2);
        entityFrequency = clamp(entityFrequency, 0, 3);
        eventFrequency = clamp(eventFrequency, 0, 3);
        dialogueFrequency = clamp(dialogueFrequency, 0, 3);
        jumpscareFrequency = clamp(jumpscareFrequency, 0, 3);
        progressionSpeed = clamp(progressionSpeed, 0.05, 20);
        maxDestructionRadius = Math.max(0, Math.min(16, maxDestructionRadius));
        restoreDelaySeconds = Math.max(10, Math.min(3600, restoreDelaySeconds));
        meme67CooldownSeconds = Math.max(1, Math.min(3600, meme67CooldownSeconds));
        graceSeconds = Math.max(0, graceSeconds);
        maxEntitiesTotal = Math.max(1, Math.min(32, maxEntitiesTotal));
        if (language == null) language = "en";
        if (multiplayerBehavior == null) multiplayerBehavior = "PER_PLAYER";
    }

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    public boolean sharedMode() {
        return "SHARED".equalsIgnoreCase(multiplayerBehavior);
    }
}
