package com.horrorsteve.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.horrorsteve.HorrorSteveMod;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/** Client-side accessibility options: config/horrorsteve-client.json. Each player controls their own. */
public class HorrorClientConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static HorrorClientConfig instance = new HorrorClientConfig();

    public boolean allowFlashing = true;
    public boolean allowScreenShake = true;
    public boolean allowFovEffects = true;
    public boolean allowVignette = true;
    public boolean allowStaticNoise = true;
    public boolean allowDarkness = true;
    public boolean allowFakeScreens = true;
    public boolean allowJumpscareVisuals = true;
    public boolean allowModelDistortion = true;
    /** Multiplies effect strength. 0 disables all intensity-based effects. */
    public double effectStrength = 1.0;

    public static HorrorClientConfig get() {
        return instance;
    }

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("horrorsteve-client.json");
    }

    public static void load() {
        try {
            Path p = path();
            if (Files.exists(p)) {
                HorrorClientConfig loaded = GSON.fromJson(Files.readString(p), HorrorClientConfig.class);
                if (loaded != null) instance = loaded;
            }
            instance.effectStrength = Math.max(0, Math.min(2, instance.effectStrength));
            Files.createDirectories(p.getParent());
            Files.writeString(p, GSON.toJson(instance));
        } catch (Exception e) {
            HorrorSteveMod.LOG.error("Could not read horrorsteve-client.json, using defaults", e);
            instance = new HorrorClientConfig();
        }
    }
}
