package com.horrorsteve.world;

import net.minecraft.block.BlockState;
import net.minecraft.network.packet.s2c.play.BlockUpdateS2CPacket;
import net.minecraft.registry.RegistryKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Client-only fake blocks. Packets are sent to one player; the server world is never changed, so illusions can never
 * damage anything. They vanish after a while, or when the player walks up to them.
 */
public final class IllusionManager {
    private static final class Group {
        UUID player;
        RegistryKey<World> dim;
        Map<BlockPos, BlockState> blocks;
        long expire;
        double approach;
        Vec3d center;
    }

    private static final List<Group> GROUPS = new ArrayList<>();
    private static long tickCounter = 0;

    private IllusionManager() {}

    public static void show(ServerPlayerEntity p, Map<BlockPos, BlockState> blocks, int lifeTicks, double approachRadius) {
        if (blocks.isEmpty()) return;
        Map<BlockPos, BlockState> copy = new HashMap<>();
        int n = 0;
        for (Map.Entry<BlockPos, BlockState> e : blocks.entrySet()) {
            if (n++ >= 220) break;
            copy.put(e.getKey().toImmutable(), e.getValue());
        }
        Group g = new Group();
        g.player = p.getUuid();
        g.dim = p.getWorld().getRegistryKey();
        g.blocks = copy;
        g.expire = tickCounter + lifeTicks;
        g.approach = approachRadius;
        double sx = 0, sy = 0, sz = 0;
        for (BlockPos b : copy.keySet()) {
            sx += b.getX();
            sy += b.getY();
            sz += b.getZ();
        }
        g.center = new Vec3d(sx / copy.size() + 0.5, sy / copy.size() + 0.5, sz / copy.size() + 0.5);
        GROUPS.add(g);
        for (Map.Entry<BlockPos, BlockState> e : copy.entrySet()) {
            p.networkHandler.sendPacket(new BlockUpdateS2CPacket(e.getKey(), e.getValue()));
        }
    }

    public static void tick(MinecraftServer server) {
        tickCounter++;
        if (GROUPS.isEmpty() || tickCounter % 5 != 0) return;
        Iterator<Group> it = GROUPS.iterator();
        while (it.hasNext()) {
            Group g = it.next();
            ServerPlayerEntity p = server.getPlayerManager().getPlayer(g.player);
            if (p == null || p.getWorld().getRegistryKey() != g.dim) {
                it.remove();
                continue;
            }
            boolean approached = g.approach > 0 && p.getPos().squaredDistanceTo(g.center) < g.approach * g.approach;
            if (tickCounter >= g.expire || approached) {
                restore(p, g);
                it.remove();
            }
        }
    }

    private static void restore(ServerPlayerEntity p, Group g) {
        if (!(p.getWorld() instanceof ServerWorld w)) return;
        for (BlockPos pos : g.blocks.keySet()) {
            p.networkHandler.sendPacket(new BlockUpdateS2CPacket(pos, w.getBlockState(pos)));
        }
    }

    public static void clear(UUID player, MinecraftServer server) {
        ServerPlayerEntity p = server.getPlayerManager().getPlayer(player);
        Iterator<Group> it = GROUPS.iterator();
        while (it.hasNext()) {
            Group g = it.next();
            if (g.player.equals(player)) {
                if (p != null && p.getWorld().getRegistryKey() == g.dim) restore(p, g);
                it.remove();
            }
        }
    }

    public static void clearAll(MinecraftServer server) {
        for (Group g : new ArrayList<>(GROUPS)) clear(g.player, server);
        GROUPS.clear();
    }
}
