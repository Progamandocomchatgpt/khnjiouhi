package com.horrorsteve.world;

import com.horrorsteve.HorrorSteveMod;
import com.horrorsteve.ai.SpawnLocator;
import com.horrorsteve.config.HorrorConfig;
import com.horrorsteve.dialogue.DialogueDatabase;
import com.horrorsteve.util.Rand;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.SignBlockEntity;
import net.minecraft.block.entity.SignText;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.property.Properties;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Builds the entity's rare structures at runtime (only inside already-loaded chunks, only into free or natural blocks,
 * never over player builds). Structure positions are saved so signs can point at them and visits can be counted.
 */
public final class StructureBuilder {
    public static final int STRANGE_HOUSE = 1;
    public static final int ABANDONED_ROOM = 2;
    public static final int CHAMBER = 3;
    public static final int FAKE_BASE = 4;
    public static final int CORRIDOR = 5;
    public static final int SIGN_ROOM = 6;

    private StructureBuilder() {}

    private static final class Plan {
        final Map<BlockPos, BlockState> blocks = new LinkedHashMap<>();
        final List<BlockPos> signs = new ArrayList<>();

        void set(BlockPos p, BlockState s) {
            blocks.put(p.toImmutable(), s);
        }

        void box(BlockPos o, int x1, int y1, int z1, int x2, int y2, int z2, BlockState s) {
            for (int x = x1; x <= x2; x++) for (int y = y1; y <= y2; y++) for (int z = z1; z <= z2; z++) set(o.add(x, y, z), s);
        }

        /** Hollow shell with walls/floor/roof of "shell" and an air interior. */
        void shell(BlockPos o, int half, int height, BlockState shell) {
            box(o, -half, -1, -half, half, height, half, shell);
            box(o, -half + 1, 0, -half + 1, half - 1, height - 1, half - 1, Blocks.AIR.getDefaultState());
        }

        void sign(BlockPos p) {
            set(p, Blocks.OAK_SIGN.getDefaultState().with(Properties.ROTATION, Rand.range(0, 15)));
            signs.add(p.toImmutable());
        }
    }

    // ---------------------------------------------------------------- public API

    public static boolean buildRandom(ServerWorld w, ServerPlayerEntity p) {
        if (!HorrorConfig.get().structuresEnabled || w.getRegistryKey() != World.OVERWORLD) return false;
        HorrorWorldState st = HorrorWorldState.get(w.getServer());
        long here = st.structures.stream().filter(s -> s.dim.equals(RestorationManager.dimKey(w))).count();
        if (here >= 12) return false;
        int type = Rand.weighted(List.of(1, 2, 3, 4, 5, 6), t -> switch (t) {
            case STRANGE_HOUSE -> 22;
            case ABANDONED_ROOM -> 20;
            case CHAMBER -> 8;
            case FAKE_BASE -> 22;
            case CORRIDOR -> 10;
            default -> 18;
        });
        return build(w, p, type);
    }

    public static boolean build(ServerWorld w, ServerPlayerEntity p, int type) {
        for (int attempt = 0; attempt < 6; attempt++) {
            BlockPos origin = siteFor(w, p, type);
            if (origin == null) continue;
            Plan plan = planFor(type, origin);
            if (!verify(w, plan)) continue;
            apply(w, plan, origin, type);
            return true;
        }
        return false;
    }

    private static boolean surfaceType(int type) {
        return type == STRANGE_HOUSE || type == FAKE_BASE || type == CORRIDOR;
    }

    private static BlockPos siteFor(ServerWorld w, ServerPlayerEntity p, int type) {
        if (surfaceType(type)) {
            Vec3d v = SpawnLocator.ring(w, p, 34, 64, 0, 360, true);
            if (v == null) return null;
            BlockPos g = BlockPos.ofFloored(v);
            return type == CORRIDOR ? g.up(9) : g;
        }
        double ang = Rand.range(0, Math.PI * 2);
        double d = Rand.range(18, 48);
        int x = (int) Math.floor(p.getX() + Math.cos(ang) * d);
        int z = (int) Math.floor(p.getZ() + Math.sin(ang) * d);
        if (!SpawnLocator.loaded(w, x, z)) return null;
        int top = Math.max(w.getBottomY() + 14, Math.min(p.getBlockY(), w.getSeaLevel() - 14));
        int y = Rand.range(w.getBottomY() + 8, top);
        return new BlockPos(x, y, z);
    }

    private static Plan planFor(int type, BlockPos o) {
        Plan pl = new Plan();
        switch (type) {
            case STRANGE_HOUSE -> {
                pl.shell(o, 3, 4, Blocks.OAK_PLANKS.getDefaultState());
                pl.box(o, -3, -1, -3, 3, -1, 3, Blocks.SPRUCE_PLANKS.getDefaultState());
                pl.set(o.add(0, 0, -3), Blocks.AIR.getDefaultState());
                pl.set(o.add(0, 1, -3), Blocks.AIR.getDefaultState());
                pl.sign(o);
                pl.sign(o.add(2, 0, 2));
            }
            case FAKE_BASE -> {
                pl.shell(o, 2, 3, Blocks.DIRT.getDefaultState());
                pl.set(o.add(0, 0, -2), Blocks.AIR.getDefaultState());
                pl.set(o.add(0, 1, -2), Blocks.AIR.getDefaultState());
                pl.set(o.add(1, 0, 1), Blocks.CRAFTING_TABLE.getDefaultState());
                pl.set(o.add(-1, 0, 1), Blocks.FURNACE.getDefaultState());
                pl.set(o.add(1, 0, -3), Blocks.TORCH.getDefaultState());
                pl.sign(o.add(0, 0, 1));
            }
            case ABANDONED_ROOM -> {
                pl.shell(o, 3, 4, Blocks.STONE_BRICKS.getDefaultState());
                pl.box(o, -3, 4, -3, 3, 4, 3, Blocks.CRACKED_STONE_BRICKS.getDefaultState());
                pl.box(o, -3, -1, -3, 3, -1, 3, Blocks.MOSSY_STONE_BRICKS.getDefaultState());
                pl.sign(o);
            }
            case CHAMBER -> {
                pl.shell(o, 4, 5, Blocks.DEEPSLATE_BRICKS.getDefaultState());
                for (int sx = -3; sx <= 3; sx += 6) for (int sz = -3; sz <= 3; sz += 6)
                    pl.box(o, sx, 0, sz, sx, 4, sz, Blocks.POLISHED_DEEPSLATE.getDefaultState());
                pl.sign(o);
                pl.sign(o.add(2, 0, 2));
            }
            case SIGN_ROOM -> {
                pl.shell(o, 2, 3, Blocks.COBBLESTONE.getDefaultState());
                pl.sign(o.add(1, 0, 1));
                pl.sign(o.add(-1, 0, 1));
                pl.sign(o.add(1, 0, -1));
                pl.sign(o.add(-1, 0, -1));
            }
            case CORRIDOR -> {
                BlockState bricks = Blocks.STONE_BRICKS.getDefaultState();
                pl.box(o, 0, -1, -1, 23, 2, 1, bricks);
                pl.box(o, 0, 0, 0, 23, 1, 0, Blocks.AIR.getDefaultState());
                pl.sign(o.add(11, 0, 0));
            }
            default -> {
            }
        }
        return pl;
    }

    private static boolean verify(ServerWorld w, Plan plan) {
        for (BlockPos pos : plan.blocks.keySet()) {
            if (!SpawnLocator.loaded(w, pos.getX(), pos.getZ())) return false;
            if (!WorldProtection.canChange(w, pos)) return false;
        }
        return true;
    }

    private static void apply(ServerWorld w, Plan plan, BlockPos origin, int type) {
        if (surfaceType(type) && type != CORRIDOR) {
            // fill small gaps under the footprint so the building does not float
            for (BlockPos pos : new ArrayList<>(plan.blocks.keySet())) {
                if (pos.getY() == origin.getY() - 1) {
                    for (int d = 1; d <= 3; d++) {
                        BlockPos under = pos.down(d);
                        if (w.getBlockState(under).isAir() && WorldProtection.canChange(w, under)) {
                            w.setBlockState(under, Blocks.DIRT.getDefaultState(), 2);
                        }
                    }
                }
            }
        }
        for (Map.Entry<BlockPos, BlockState> e : plan.blocks.entrySet()) {
            w.setBlockState(e.getKey(), e.getValue(), 2);
        }
        HorrorWorldState st = HorrorWorldState.get(w.getServer());
        for (BlockPos s : plan.signs) {
            writeSign(w, s, randomLines());
            st.signs.add(HorrorWorldState.signKey(RestorationManager.dimKey(w), s.asLong()));
        }
        HorrorWorldState.Structure rec = new HorrorWorldState.Structure();
        rec.dim = RestorationManager.dimKey(w);
        rec.pos = origin.asLong();
        rec.type = type;
        st.structures.add(rec);
        st.markDirty();
        HorrorSteveMod.LOG.info("Horror structure type {} built at {}", type, origin.toShortString());
    }

    // ---------------------------------------------------------------- signs

    public static String[] randomLines() {
        String raw = DialogueDatabase.pick("signs.text");
        if (raw == null) raw = "I was here|first";
        return raw.split("\\|");
    }

    public static void writeSign(ServerWorld w, BlockPos pos, String[] lines) {
        if (w.getBlockEntity(pos) instanceof SignBlockEntity sbe) {
            sbe.changeText(t -> {
                SignText x = t;
                for (int i = 0; i < 4; i++) {
                    x = x.withMessage(i, Text.literal(i < lines.length ? lines[i].trim() : ""));
                }
                return x;
            }, true);
            sbe.setWaxed(true);
            sbe.markDirty();
        }
    }

    /** Places a temporary sign (restored later) on solid ground; returns true if placed. */
    public static boolean placeTemporarySign(ServerWorld w, BlockPos pos, String[] lines, int restoreSeconds) {
        if (!WorldProtection.isFree(w, pos)) return false;
        BlockPos below = pos.down();
        if (w.getBlockState(below).getCollisionShape(w, below).isEmpty()) return false;
        BlockState sign = Blocks.OAK_SIGN.getDefaultState().with(Properties.ROTATION, Rand.range(0, 15));
        if (!RestorationManager.change(w, pos, sign, restoreSeconds)) return false;
        writeSign(w, pos, lines);
        HorrorWorldState st = HorrorWorldState.get(w.getServer());
        st.signs.add(HorrorWorldState.signKey(RestorationManager.dimKey(w), pos.asLong()));
        st.markDirty();
        return true;
    }

    public static BlockPos nearestStructure(ServerWorld w, BlockPos from) {
        HorrorWorldState st = HorrorWorldState.get(w.getServer());
        BlockPos best = null;
        double bd = Double.MAX_VALUE;
        String dim = RestorationManager.dimKey(w);
        for (HorrorWorldState.Structure s : st.structures) {
            if (!s.dim.equals(dim)) continue;
            BlockPos bp = BlockPos.fromLong(s.pos);
            double d = bp.getSquaredDistance(from);
            if (d < bd) {
                bd = d;
                best = bp;
            }
        }
        return best;
    }
}
