package com.horrorsteve.world;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.registry.Registries;
import net.minecraft.state.property.Property;
import net.minecraft.util.Identifier;

import java.util.Optional;

/** Stores a block state as a plain string ("minecraft:oak_door;facing=north;open=false") so it survives in NBT. */
public final class BlockCodec {
    private BlockCodec() {}

    public static String encode(BlockState s) {
        StringBuilder sb = new StringBuilder(Registries.BLOCK.getId(s.getBlock()).toString());
        for (Property<?> p : s.getProperties()) {
            sb.append(';').append(p.getName()).append('=').append(valueName(s, p));
        }
        return sb.toString();
    }

    private static <T extends Comparable<T>> String valueName(BlockState s, Property<T> p) {
        return p.name(s.get(p));
    }

    public static BlockState decode(String str) {
        String[] parts = str.split(";");
        Identifier id = Identifier.tryParse(parts[0]);
        Block b = id == null ? net.minecraft.block.Blocks.AIR : Registries.BLOCK.get(id);
        BlockState st = b.getDefaultState();
        for (int i = 1; i < parts.length; i++) {
            int eq = parts[i].indexOf('=');
            if (eq < 0) continue;
            Property<?> prop = b.getStateManager().getProperty(parts[i].substring(0, eq));
            if (prop != null) st = apply(st, prop, parts[i].substring(eq + 1));
        }
        return st;
    }

    private static <T extends Comparable<T>> BlockState apply(BlockState s, Property<T> p, String v) {
        Optional<T> o = p.parse(v);
        return o.isPresent() ? s.with(p, o.get()) : s;
    }
}
