package com.horrorsteve.world;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/** Decides what the entity may touch. Anything that is not clearly natural terrain is left alone. */
public final class WorldProtection {
    private WorldProtection() {}

    public static boolean isNatural(BlockState s) {
        if (s.isAir()) return true;
        return s.isIn(BlockTags.BASE_STONE_OVERWORLD) || s.isIn(BlockTags.BASE_STONE_NETHER)
                || s.isIn(BlockTags.DIRT) || s.isIn(BlockTags.SAND) || s.isIn(BlockTags.LEAVES)
                || s.isOf(Blocks.GRAVEL) || s.isOf(Blocks.SNOW) || s.isOf(Blocks.SNOW_BLOCK)
                || s.isOf(Blocks.END_STONE) || s.isOf(Blocks.SHORT_GRASS) || s.isOf(Blocks.TALL_GRASS)
                || s.isOf(Blocks.FERN) || s.isOf(Blocks.SANDSTONE) || s.isOf(Blocks.CLAY)
                || s.isOf(Blocks.TERRACOTTA) || s.isOf(Blocks.MOSS_BLOCK) || s.isOf(Blocks.COBWEB);
    }

    /** True if the position may be replaced by something (air or natural, no block entity, not unbreakable, away from spawn). */
    public static boolean canChange(ServerWorld w, BlockPos pos) {
        if (w.isOutOfHeightLimit(pos)) return false;
        BlockState s = w.getBlockState(pos);
        if (!s.getFluidState().isEmpty()) return false;
        if (!s.isAir() && s.getHardness(w, pos) < 0) return false;
        if (w.getBlockEntity(pos) != null) return false;
        if (w.getRegistryKey() == World.OVERWORLD) {
            BlockPos spawn = w.getSpawnPos();
            long dx = spawn.getX() - pos.getX();
            long dz = spawn.getZ() - pos.getZ();
            if (dx * dx + dz * dz < 48L * 48L) return false;
        }
        return isNatural(s);
    }

    /** Positions we can safely put a new block into (air or replaceable plants). */
    public static boolean isFree(ServerWorld w, BlockPos pos) {
        if (w.isOutOfHeightLimit(pos)) return false;
        BlockState s = w.getBlockState(pos);
        return s.isAir() || s.isReplaceable() && s.getFluidState().isEmpty();
    }
}
