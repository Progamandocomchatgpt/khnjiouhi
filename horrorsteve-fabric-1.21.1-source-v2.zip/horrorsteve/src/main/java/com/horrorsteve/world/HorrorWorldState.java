package com.horrorsteve.world;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.PersistentState;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** World-saved: pending block restorations, spawned structures and the signs the entity placed. */
public class HorrorWorldState extends PersistentState {
    public static final PersistentState.Type<HorrorWorldState> TYPE =
            new PersistentState.Type<>(HorrorWorldState::new, HorrorWorldState::fromNbt, null);

    public static final class Restore {
        public String dim;
        public long pos;
        public String original;
        public String expected;
        public long due;
    }

    public static final class Structure {
        public String dim;
        public long pos;
        public int type;
    }

    public final List<Restore> restores = new ArrayList<>();
    public final List<Structure> structures = new ArrayList<>();
    public final Set<String> signs = new HashSet<>();

    public static HorrorWorldState get(MinecraftServer server) {
        return server.getOverworld().getPersistentStateManager().getOrCreate(TYPE, "horrorsteve_world");
    }

    public static String signKey(String dim, long pos) {
        return dim + "|" + pos;
    }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
        NbtList rl = new NbtList();
        for (Restore r : restores) {
            NbtCompound c = new NbtCompound();
            c.putString("dim", r.dim);
            c.putLong("pos", r.pos);
            c.putString("orig", r.original);
            c.putString("exp", r.expected);
            c.putLong("due", r.due);
            rl.add(c);
        }
        nbt.put("restores", rl);
        NbtList sl = new NbtList();
        for (Structure s : structures) {
            NbtCompound c = new NbtCompound();
            c.putString("dim", s.dim);
            c.putLong("pos", s.pos);
            c.putInt("type", s.type);
            sl.add(c);
        }
        nbt.put("structures", sl);
        NbtList gl = new NbtList();
        for (String s : signs) gl.add(net.minecraft.nbt.NbtString.of(s));
        nbt.put("signs", gl);
        return nbt;
    }

    public static HorrorWorldState fromNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
        HorrorWorldState st = new HorrorWorldState();
        NbtList rl = nbt.getList("restores", NbtElement.COMPOUND_TYPE);
        for (int i = 0; i < rl.size(); i++) {
            NbtCompound c = rl.getCompound(i);
            Restore r = new Restore();
            r.dim = c.getString("dim");
            r.pos = c.getLong("pos");
            r.original = c.getString("orig");
            r.expected = c.getString("exp");
            r.due = c.getLong("due");
            st.restores.add(r);
        }
        NbtList sl = nbt.getList("structures", NbtElement.COMPOUND_TYPE);
        for (int i = 0; i < sl.size(); i++) {
            NbtCompound c = sl.getCompound(i);
            Structure s = new Structure();
            s.dim = c.getString("dim");
            s.pos = c.getLong("pos");
            s.type = c.getInt("type");
            st.structures.add(s);
        }
        NbtList gl = nbt.getList("signs", NbtElement.STRING_TYPE);
        for (int i = 0; i < gl.size(); i++) st.signs.add(gl.getString(i));
        return st;
    }
}
