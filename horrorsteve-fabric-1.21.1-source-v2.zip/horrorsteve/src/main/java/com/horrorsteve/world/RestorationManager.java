package com.horrorsteve.world;

import com.horrorsteve.HorrorSteveMod;
import com.horrorsteve.config.HorrorConfig;
import net.minecraft.block.BlockState;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import java.util.Iterator;

/**
 * Every real block change the entity makes goes through here: the original state is logged (and saved with the world) and
 * put back later. A block the player has since changed is never overwritten. Everything is restored on server stop.
 */
public final class RestorationManager {
    private static final int MAX_LOG = 3000;

    private RestorationManager() {}

    public static String dimKey(ServerWorld w) {
        return w.getRegistryKey().getValue().toString();
    }

    /** Changes a block and schedules its restoration. Returns false if refused. */
    public static boolean change(ServerWorld w, BlockPos pos, BlockState next, int delaySeconds) {
        HorrorWorldState st = HorrorWorldState.get(w.getServer());
        if (st.restores.size() >= MAX_LOG) return false;
        BlockState orig = w.getBlockState(pos);
        HorrorWorldState.Restore r = new HorrorWorldState.Restore();
        r.dim = dimKey(w);
        r.pos = pos.asLong();
        r.original = BlockCodec.encode(orig);
        r.expected = BlockCodec.encode(next);
        r.due = w.getTime() + 20L * Math.max(5, delaySeconds);
        w.setBlockState(pos, next, 3);
        r.expected = BlockCodec.encode(w.getBlockState(pos));
        st.restores.add(r);
        st.markDirty();
        return true;
    }

    public static int defaultDelay() {
        return HorrorConfig.get().restoreDelaySeconds;
    }

    public static void tick(MinecraftServer server) {
        HorrorWorldState st = HorrorWorldState.get(server);
        if (st.restores.isEmpty()) return;
        int done = process(server, st, false);
        if (done > 0) st.markDirty();
    }

    public static int restoreAll(MinecraftServer server) {
        HorrorWorldState st = HorrorWorldState.get(server);
        int n = process(server, st, true);
        if (n > 0) st.markDirty();
        return n;
    }

    private static int process(MinecraftServer server, HorrorWorldState st, boolean force) {
        int count = 0;
        Iterator<HorrorWorldState.Restore> it = st.restores.iterator();
        while (it.hasNext()) {
            HorrorWorldState.Restore r = it.next();
            Identifier id = Identifier.tryParse(r.dim);
            ServerWorld w = id == null ? null : server.getWorld(RegistryKey.of(RegistryKeys.WORLD, id));
            if (w == null) {
                it.remove();
                continue;
            }
            if (!force && w.getTime() < r.due) continue;
            BlockPos pos = BlockPos.fromLong(r.pos);
            if (!w.getChunkManager().isChunkLoaded(pos.getX() >> 4, pos.getZ() >> 4)) {
                if (force) it.remove();
                continue;
            }
            try {
                BlockState now = w.getBlockState(pos);
                if (BlockCodec.encode(now).equals(r.expected)) {
                    w.setBlockState(pos, BlockCodec.decode(r.original), 3);
                    count++;
                }
            } catch (Exception e) {
                HorrorSteveMod.LOG.warn("Restore failed at {}", pos, e);
            }
            it.remove();
        }
        return count;
    }
}
