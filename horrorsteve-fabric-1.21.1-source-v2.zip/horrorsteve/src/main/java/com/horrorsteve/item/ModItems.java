package com.horrorsteve.item;

import com.horrorsteve.HorrorSteveMod;
import com.horrorsteve.entity.ModEntities;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public final class ModItems {
    public static final Item SPAWN_EGG = Registry.register(
            Registries.ITEM,
            HorrorSteveMod.id("horror_steve_spawn_egg"),
            new SpawnEggItem(ModEntities.HORROR_STEVE, 0x3B2A1A, 0x00A8A8, new Item.Settings()));

    private ModItems() {}

    public static void register() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.SPAWN_EGGS).register(entries -> entries.add(SPAWN_EGG));
    }
}
