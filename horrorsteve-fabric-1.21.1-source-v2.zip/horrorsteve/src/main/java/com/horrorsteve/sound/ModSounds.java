package com.horrorsteve.sound;

import com.horrorsteve.HorrorSteveMod;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

/** Custom sound events. Their .ogg files live in assets/horrorsteve/sounds and are mapped in sounds.json. */
public final class ModSounds {
    public static final SoundEvent WHISPER = reg("whisper");
    public static final SoundEvent BREATH = reg("breath");
    public static final SoundEvent STATIC = reg("static");
    public static final SoundEvent STEP = reg("step");
    public static final SoundEvent TELEPORT = reg("teleport");
    public static final SoundEvent DISTORT = reg("distort");
    public static final SoundEvent JUMPSCARE = reg("jumpscare");
    public static final SoundEvent AMBIENT_FAR = reg("ambient_far");
    public static final SoundEvent HEARTBEAT = reg("heartbeat");
    public static final SoundEvent KNOCK = reg("knock");
    public static final SoundEvent MEME67 = reg("meme67");
    public static final SoundEvent GLITCH = reg("glitch");
    public static final SoundEvent RARE = reg("rare");
    public static final SoundEvent MUSIC_TENSION = reg("music_tension");
    public static final SoundEvent MUSIC_CHASE = reg("music_chase");
    public static final SoundEvent MUSIC_UNKNOWN = reg("music_unknown");

    private ModSounds() {}

    private static SoundEvent reg(String name) {
        Identifier id = HorrorSteveMod.id(name);
        return Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
    }

    public static void register() {
        // Loading this class registers every event above.
    }
}
