package com.horrorsteve.language;

/** Language registry. Only English is bundled; adding a language means adding a dialogue file and an entry here. */
public enum Language {
    EN("en");

    public final String code;

    Language(String code) {
        this.code = code;
    }

    public static Language fromCode(String code) {
        if (code != null) {
            for (Language l : values()) if (l.code.equalsIgnoreCase(code)) return l;
        }
        return EN;
    }
}
