package com.horrorsteve.entity;

import com.horrorsteve.HorrorSteveMod;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public final class ModEntities {
    public static final EntityType<HorrorSteveEntity> HORROR_STEVE = Registry.register(
            Registries.ENTITY_TYPE,
            HorrorSteveMod.id("horror_steve"),
            EntityType.Builder.create(HorrorSteveEntity::new, SpawnGroup.MONSTER)
                    .dimensions(0.6F, 1.8F)
                    .eyeHeight(1.62F)
                    .maxTrackingRange(8)
                    .build("horror_steve"));

    private ModEntities() {}

    public static void register() {
        FabricDefaultAttributeRegistry.register(HORROR_STEVE, HorrorSteveEntity.createAttributes());
    }
}
