package com.horrorsteve.entity;

import com.horrorsteve.HorrorSteveMod;
import com.horrorsteve.ai.HorrorBrain;
import com.horrorsteve.server.HorrorDirector;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.Optional;
import java.util.UUID;

/**
 * A Steve that is not quite Steve. One class serves three roles:
 * MAIN (the haunting itself), DECOY (an illusion only one player can see) and FAKE_PLAYER (pretends to be a player).
 * All behaviour is decided on the server by {@link HorrorBrain}; the client only renders tracked values.
 */
public class HorrorSteveEntity extends PathAwareEntity {
    public static final int ROLE_MAIN = 0;
    public static final int ROLE_DECOY = 1;
    public static final int ROLE_FAKE_PLAYER = 2;

    // pose / behaviour flags (tracked, read by the model)
    public static final int F_HEAD_LOCK = 1;
    public static final int F_BODY_LOCK = 2;
    public static final int F_FROZEN = 4;
    public static final int F_FLOAT = 8;
    public static final int F_NO_LIMBS = 16;
    public static final int F_BROKEN_WALK = 32;
    public static final int F_ARMS_WRONG = 64;
    public static final int F_BACKWARD = 128;
    public static final int F_TWITCH = 256;
    public static final int F_TPOSE = 512;

    public static final int ANIM_NONE = 0;
    public static final int ANIM_MEME67 = 1;
    public static final int ANIM_MEME67_B = 2;
    public static final int ANIM_ARMS_UP = 3;

    // face distortion variants
    public static final int D_NONE = 0;
    public static final int D_FLICKER = 1;
    public static final int D_SHAKE = 2;
    public static final int D_STRETCH = 3;
    public static final int D_SQUASH = 4;
    public static final int D_BIG = 5;
    public static final int D_TINY = 6;
    public static final int D_BLANK = 7;
    public static final int D_SMILE = 8;
    public static final int D_DARK = 9;
    public static final int D_SPIN = 10;
    public static final int D_VANISH = 11;
    public static final int D_TILT = 12;
    public static final int D_LONGNECK = 13;
    public static final int D_EYES = 14;
    public static final int D_UNKNOWN = 15;

    private static final TrackedData<Integer> STAGE = DataTracker.registerData(HorrorSteveEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> ROLE = DataTracker.registerData(HorrorSteveEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> ANIM = DataTracker.registerData(HorrorSteveEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> DISTORT = DataTracker.registerData(HorrorSteveEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Integer> FLAGS = DataTracker.registerData(HorrorSteveEntity.class, TrackedDataHandlerRegistry.INTEGER);
    private static final TrackedData<Float> LOOK_YAW = DataTracker.registerData(HorrorSteveEntity.class, TrackedDataHandlerRegistry.FLOAT);
    private static final TrackedData<Float> LOOK_PITCH = DataTracker.registerData(HorrorSteveEntity.class, TrackedDataHandlerRegistry.FLOAT);
    private static final TrackedData<Float> BODY_LOCK_YAW = DataTracker.registerData(HorrorSteveEntity.class, TrackedDataHandlerRegistry.FLOAT);
    private static final TrackedData<Optional<UUID>> VISIBLE_TO = DataTracker.registerData(HorrorSteveEntity.class, TrackedDataHandlerRegistry.OPTIONAL_UUID);

    // server-only state
    public HorrorBrain hsBrain;
    public int sessionToken = HorrorSteveMod.SESSION;
    public UUID targetId;
    public int lifespan = 20 * 90;
    public boolean stale = false;
    /** Client-only: entity age when the current distortion started. */
    public int distortStart = 0;

    public HorrorSteveEntity(EntityType<? extends HorrorSteveEntity> type, World world) {
        super(type, world);
        this.setPersistent();
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return MobEntity.createMobAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 100.0)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.28)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 3.0)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 96.0);
    }

    @Override
    protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(STAGE, 1);
        builder.add(ROLE, ROLE_MAIN);
        builder.add(ANIM, ANIM_NONE);
        builder.add(DISTORT, D_NONE);
        builder.add(FLAGS, 0);
        builder.add(LOOK_YAW, 0f);
        builder.add(LOOK_PITCH, 0f);
        builder.add(BODY_LOCK_YAW, 0f);
        builder.add(VISIBLE_TO, Optional.empty());
    }

    @Override
    public void onTrackedDataSet(TrackedData<?> data) {
        super.onTrackedDataSet(data);
        if (DISTORT.equals(data)) {
            this.distortStart = this.age;
        }
    }

    // ---- tracked accessors ----
    public int getStageValue() { return dataTracker.get(STAGE); }
    public void setStageValue(int v) { if (getStageValue() != v) dataTracker.set(STAGE, v); }
    public int getRole() { return dataTracker.get(ROLE); }
    public void setRole(int v) { dataTracker.set(ROLE, v); }
    public int getAnim() { return dataTracker.get(ANIM); }
    public void setAnim(int v) { if (getAnim() != v) dataTracker.set(ANIM, v); }
    public int getDistort() { return dataTracker.get(DISTORT); }
    public void setDistort(int v) { if (getDistort() != v) dataTracker.set(DISTORT, v); }
    public int getFlags() { return dataTracker.get(FLAGS); }
    public boolean hasHsFlag(int f) { return (getFlags() & f) != 0; }

    public void setHsFlag(int f, boolean on) {
        int cur = getFlags();
        int next = on ? (cur | f) : (cur & ~f);
        if (next != cur) dataTracker.set(FLAGS, next);
    }

    public float getLookYaw() { return dataTracker.get(LOOK_YAW); }
    public float getLookPitch() { return dataTracker.get(LOOK_PITCH); }
    public float getBodyLockYaw() { return dataTracker.get(BODY_LOCK_YAW); }
    public Optional<UUID> getVisibleTo() { return dataTracker.get(VISIBLE_TO); }
    public void setVisibleTo(UUID id) { dataTracker.set(VISIBLE_TO, Optional.ofNullable(id)); }

    // ---- behaviour helpers (server) ----
    /** Makes only the head follow a point (independent of the body). */
    public void lookAt(Vec3d point) {
        Vec3d eye = this.getEyePos();
        float yaw = com.horrorsteve.util.Geo.yawTo(eye, point);
        float pitch = com.horrorsteve.util.Geo.pitchTo(eye, point);
        if (Math.abs(yaw - getLookYaw()) > 0.5f) dataTracker.set(LOOK_YAW, yaw);
        if (Math.abs(pitch - getLookPitch()) > 0.5f) dataTracker.set(LOOK_PITCH, pitch);
        setHsFlag(F_HEAD_LOCK, true);
        this.setHeadYaw(yaw);
    }

    public void releaseHead() {
        setHsFlag(F_HEAD_LOCK, false);
    }

    /** Freezes the body orientation (used for walking backwards / standing wrongly). */
    public void lockBody(float yaw) {
        dataTracker.set(BODY_LOCK_YAW, yaw);
        setHsFlag(F_BODY_LOCK, true);
    }

    public void unlockBody() {
        setHsFlag(F_BODY_LOCK, false);
    }

    /** Turns the whole entity to face a point. */
    public void faceToward(Vec3d point) {
        float yaw = com.horrorsteve.util.Geo.yawTo(this.getPos(), point);
        this.setYaw(yaw);
        this.setBodyYaw(yaw);
        this.setHeadYaw(yaw);
        this.setPitch(0);
    }

    public void teleportTo(double x, double y, double z) {
        this.refreshPositionAndAngles(x, y, z, this.getYaw(), this.getPitch());
        this.getNavigation().stop();
        this.setVelocity(Vec3d.ZERO);
        this.velocityModified = true;
    }

    public ServerPlayerEntity resolveTarget() {
        if (!(getWorld() instanceof ServerWorld sw)) return null;
        if (targetId != null) {
            ServerPlayerEntity p = sw.getServer().getPlayerManager().getPlayer(targetId);
            if (p != null && !p.isRemoved() && p.getWorld() == getWorld() && !p.isSpectator()) return p;
            if (p != null && p.getWorld() != getWorld()) return null;
        }
        net.minecraft.entity.player.PlayerEntity near = sw.getClosestPlayer(this, 128);
        if (near instanceof ServerPlayerEntity sp && !sp.isSpectator()) {
            if (targetId == null) targetId = sp.getUuid();
            return sp;
        }
        return null;
    }

    @Override
    public void tick() {
        super.tick();
        if (getWorld().isClient) return;
        if (stale || sessionToken != HorrorSteveMod.SESSION) {
            this.discard();
            return;
        }
        if (hsBrain == null) hsBrain = new HorrorBrain(this);
        hsBrain.tick((ServerWorld) getWorld());
        if (hasHsFlag(F_BODY_LOCK)) {
            float yaw = getBodyLockYaw();
            this.setBodyYaw(yaw);
            this.setYaw(yaw);
        }
    }

    @Override
    public boolean damage(DamageSource source, float amount) {
        if (getWorld().isClient) return false;
        if (source.isOf(net.minecraft.entity.damage.DamageTypes.GENERIC_KILL)
                || source.isOf(net.minecraft.entity.damage.DamageTypes.OUT_OF_WORLD)) {
            return super.damage(source, amount);
        }
        if (source.getAttacker() instanceof ServerPlayerEntity p && hsBrain != null) {
            hsBrain.onAttacked(p);
        }
        return false;
    }

    @Override
    public boolean isPushable() {
        return getRole() == ROLE_MAIN && super.isPushable();
    }

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);
        nbt.putInt("hsSession", sessionToken);
        nbt.putInt("hsRole", getRole());
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);
        sessionToken = nbt.contains("hsSession") ? nbt.getInt("hsSession") : 0;
        if (nbt.contains("hsRole")) setRole(nbt.getInt("hsRole"));
        if (sessionToken != HorrorSteveMod.SESSION) stale = true;
    }
}
