package com.horrorsteve.dialogue;

import com.horrorsteve.config.HorrorConfig;
import com.horrorsteve.entity.HorrorSteveEntity;
import com.horrorsteve.progression.PlayerProfile;
import com.horrorsteve.progression.Stat;
import com.horrorsteve.progression.Trait;
import com.horrorsteve.server.Advancements;
import com.horrorsteve.server.HorrorDirector;
import com.horrorsteve.server.Messenger;
import com.horrorsteve.server.PlayerSession;
import com.horrorsteve.util.Geo;
import com.horrorsteve.util.Rand;
import com.horrorsteve.util.Scheduler;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.List;
import java.util.UUID;

/** Chooses what the entity says. Fully offline: classification + weighted mode + local JSON lines. */
public final class DialogueEngine {
    private enum Mode { TRUTH, LIE, REFUSE, UNRELATED, ELLIPSIS }

    private record M(Mode m, double w) {}

    private DialogueEngine() {}

    public static String tier(int stage) {
        return stage <= 2 ? "early" : stage <= 5 ? "mid" : "late";
    }

    // ------------------------------------------------------------------ player chat

    public static void onChat(ServerPlayerEntity p, String msg) {
        HorrorConfig cfg = HorrorConfig.get();
        if (!cfg.modEnabled || cfg.dialogueFrequency <= 0) return;
        PlayerProfile prof = HorrorDirector.profile(p);
        PlayerSession sess = HorrorDirector.session(p);
        ChatCategory cat = ChatClassifier.classify(msg);
        prof.remember(msg, cat.key());
        sess.lastChatTick = Scheduler.now();
        if (ChatClassifier.isGoAway(msg)) prof.inc(Stat.GO_AWAY);
        switch (cat) {
            case STOP -> prof.bump(Trait.AVOIDANT, 1.0);
            case INSULT -> {
                prof.inc(Stat.INSULTS);
                prof.bump(Trait.AGGRESSIVE, 1.5);
            }
            case THREAT -> {
                prof.inc(Stat.THREATS);
                prof.bump(Trait.AGGRESSIVE, 2.0);
                prof.bump(Trait.CONFRONTATIONAL, 1.0);
            }
            case LOCATION -> {
                prof.inc(Stat.ASKED_WHERE);
                prof.bump(Trait.CURIOUS, 1.0);
            }
            case FEAR -> prof.bump(Trait.FEARFUL, 1.0);
            case IDENTITY, ABOUT_ENTITY, REAL -> prof.bump(Trait.CURIOUS, 1.0);
            default -> {
            }
        }
        int stage = HorrorDirector.effectiveStage(p);
        boolean present = HorrorDirector.mainEntityOf(p) != null;
        double chance = stage <= 1 ? (present ? 0.7 : 0.18) : stage == 2 ? (present ? 0.85 : 0.4) : stage <= 4 ? 0.8 : 0.9;
        if (stage >= 2 && (cat == ChatCategory.GREETING || cat == ChatCategory.LOCATION || cat == ChatCategory.REAL)) chance = Math.max(chance, 0.85);
        chance *= Math.min(1.5, cfg.dialogueFrequency);
        if (!Rand.chance(Math.min(1.0, chance))) return;

        Reply reply = compose(p, prof, stage, cat, msg, present);
        if (reply == null || reply.text == null) return;
        int delay = Math.max(25, Math.min(110, reply.text.length() * 2 + Rand.range(10, 40)));
        prof.inc(Stat.CONVERSATIONS);
        Advancements.grant(p, "you_answered");
        final UUID id = p.getUuid();
        final net.minecraft.server.MinecraftServer server = p.server;
        final String text = reply.text;
        final Runnable after = reply.after;
        Scheduler.later(delay, () -> {
            ServerPlayerEntity q = server.getPlayerManager().getPlayer(id);
            if (q == null) return;
            Messenger.say(q, text);
            if (after != null) after.run();
        });
        actions(p, prof, stage, cat, present, delay);
    }

    private static void actions(ServerPlayerEntity p, PlayerProfile prof, int stage, ChatCategory cat, boolean present, int delay) {
        final UUID id = p.getUuid();
        final net.minecraft.server.MinecraftServer server = p.server;
        if (cat == ChatCategory.STOP && present && stage <= 3 && Rand.chance(0.5)) {
            Scheduler.later(delay + 40, () -> {
                ServerPlayerEntity q = server.getPlayerManager().getPlayer(id);
                if (q != null) HorrorDirector.dismissMain(q);
            });
        }
        if (cat == ChatCategory.THREAT && stage >= 4 && Rand.chance(0.3)) {
            Scheduler.later(delay + 60, () -> {
                ServerPlayerEntity q = server.getPlayerManager().getPlayer(id);
                if (q != null) HorrorDirector.startChase(q);
            });
        }
        if (cat == ChatCategory.INSULT && stage >= 3 && Rand.chance(0.2)) {
            Scheduler.later(delay + 80, () -> {
                ServerPlayerEntity q = server.getPlayerManager().getPlayer(id);
                if (q != null) HorrorDirector.runRandomEvent(q);
            });
        }
    }

    private static final class Reply {
        String text;
        Runnable after;

        Reply(String text, Runnable after) {
            this.text = text;
            this.after = after;
        }
    }

    private static Reply compose(ServerPlayerEntity p, PlayerProfile prof, int stage, ChatCategory cat, String msg, boolean present) {
        String tier = tier(stage);
        if (stage >= 8 && Rand.chance(0.6)) return new Reply(DialogueDatabase.pick("unknown.reply"), null);
        if (Rand.chance(0.26 + 0.02 * stage)) {
            String m = MemorySystem.line(prof, cat);
            if (m != null) {
                Advancements.grant(p, "it_remembered");
                return new Reply(fill(m, p, msg), null);
            }
        }
        List<M> modes = List.of(
                new M(Mode.TRUTH, 45),
                new M(Mode.LIE, 16 + stage),
                new M(Mode.REFUSE, 8 + stage),
                new M(Mode.UNRELATED, 3 + stage * 1.5),
                new M(Mode.ELLIPSIS, 9 + stage));
        Mode mode = Rand.weighted(modes, M::w).m();
        switch (mode) {
            case ELLIPSIS -> {
                return new Reply(Rand.pick("...", "...", "......", "..."), null);
            }
            case REFUSE -> {
                String s = DialogueDatabase.pick("responses.refuse." + tier);
                if (s != null) return new Reply(fill(s, p, msg), null);
            }
            case UNRELATED -> {
                String s = DialogueDatabase.pick("responses.unrelated");
                if (s != null) return new Reply(fill(s, p, msg), null);
            }
            default -> {
            }
        }
        if (cat == ChatCategory.LOCATION) return locationReply(p, stage, mode == Mode.TRUTH, present);
        String key = "responses." + cat.key();
        String line = null;
        if (mode == Mode.LIE) line = DialogueDatabase.pick(key + ".lie");
        if (line == null) line = DialogueDatabase.pick(key + "." + tier);
        if (line == null) line = DialogueDatabase.pick(key + ".mid");
        if (line == null) line = DialogueDatabase.pick("responses.other." + tier);
        return line == null ? null : new Reply(fill(line, p, msg), null);
    }

    private static Reply locationReply(ServerPlayerEntity p, int stage, boolean truth, boolean present) {
        HorrorSteveEntity e = HorrorDirector.mainEntityOf(p);
        String real = e != null ? Geo.describe(p, e.getPos()) : null;
        if (truth) {
            if (real == null) {
                if (stage <= 1) return new Reply(DialogueDatabase.pick("responses.location.unknown"), null);
                Runnable spawn = () -> HorrorDirector.spawnBehind(p);
                return new Reply(template("responses.location.truth", "behind you"), spawn);
            }
            return new Reply(template("responses.location.truth", real), null);
        }
        String dir = real == null ? Rand.pick("behind you", "in front of you", "above you", "below you", "to your left") : Geo.opposite(real);
        return new Reply(template("responses.location.lie", dir), null);
    }

    private static String template(String key, String dir) {
        String s = DialogueDatabase.pick(key);
        if (s == null) return "Look " + dir + ".";
        return s.replace("{dir}", dir);
    }

    public static String fill(String s, ServerPlayerEntity p, String msg) {
        if (s == null) return null;
        return s.replace("{name}", p.getName().getString()).replace("{msg}", msg == null ? "" : msg);
    }

    // ------------------------------------------------------------------ events that speak

    public static void reactAttack(ServerPlayerEntity p, PlayerProfile prof, int stage) {
        if (!Rand.chance(0.7)) return;
        String line = prof.get(Stat.ATTACKS) >= 2 && Rand.chance(0.6)
                ? DialogueDatabase.pick("memory.attacked")
                : DialogueDatabase.pick("reactions.attack." + tier(stage));
        if (line != null) Messenger.sayLater(p, line, Rand.range(10, 50));
    }

    public static String fakePlayerChat() {
        String s = DialogueDatabase.pick("fake_players.chat");
        return s == null ? "..." : s;
    }

    /** An unprompted message ("I see you.", "Don't turn around."...). */
    public static void randomMessage(ServerPlayerEntity p, PlayerProfile prof, PlayerSession sess, int stage) {
        HorrorConfig cfg = HorrorConfig.get();
        if (cfg.dialogueFrequency <= 0 || !Messenger.canSpeakUnprompted(sess)) return;
        String line;
        if (stage >= 8) {
            line = DialogueDatabase.pick("unknown.message");
        } else {
            double r = Rand.r().nextDouble();
            String rarity = r < 0.66 ? "common" : r < 0.88 ? "uncommon" : (r < 0.98 || stage < 4) ? "rare" : "legendary";
            line = DialogueDatabase.pick("random." + rarity);
        }
        if (line == null) return;
        line = fill(line, p, "");
        if (stage >= 2 && Rand.chance(0.35)) Messenger.whisper(p, line);
        else Messenger.say(p, line);
    }

    /** A contextual line keyed under "context.<key>" (death, house, sleep...). */
    public static void context(ServerPlayerEntity p, String key, int delayTicks) {
        String line = DialogueDatabase.pick("context." + key);
        if (line == null) return;
        Messenger.sayLater(p, fill(line, p, ""), delayTicks);
    }

    public static void line(ServerPlayerEntity p, String key, int delayTicks) {
        String line = DialogueDatabase.pick(key);
        if (line == null) return;
        Messenger.sayLater(p, fill(line, p, ""), delayTicks);
    }
}
