package com.horrorsteve.dialogue;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.horrorsteve.HorrorSteveMod;
import com.horrorsteve.config.HorrorConfig;
import com.horrorsteve.language.Language;
import com.horrorsteve.util.Rand;
import net.fabricmc.loader.api.FabricLoader;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Local, offline dialogue store. Loads the bundled data/horrorsteve/dialogue/en.json and then merges every *.json file
 * found in config/horrorsteve/dialogue/ (lines are appended, so server owners can expand dialogue without touching the jar).
 * Nested JSON objects become dotted keys: {"responses":{"greeting":{"early":[...]}}} -> "responses.greeting.early".
 */
public final class DialogueDatabase {
    private static final Map<String, List<String>> LINES = new HashMap<>();
    private static boolean loaded = false;

    private DialogueDatabase() {}

    public static synchronized void reload() {
        LINES.clear();
        Language lang = Language.fromCode(HorrorConfig.get().language);
        try (InputStream in = DialogueDatabase.class.getResourceAsStream("/data/horrorsteve/dialogue/" + lang.code + ".json")) {
            if (in != null) merge(in);
            else HorrorSteveMod.LOG.error("Bundled dialogue file for {} is missing", lang.code);
        } catch (Exception e) {
            HorrorSteveMod.LOG.error("Failed to load bundled dialogue", e);
        }
        Path dir = FabricLoader.getInstance().getConfigDir().resolve("horrorsteve").resolve("dialogue");
        try {
            Files.createDirectories(dir);
            try (DirectoryStream<Path> ds = Files.newDirectoryStream(dir, "*.json")) {
                for (Path p : ds) {
                    try (InputStream in = Files.newInputStream(p)) {
                        merge(in);
                    } catch (Exception e) {
                        HorrorSteveMod.LOG.warn("Skipping bad dialogue file {}: {}", p.getFileName(), e.getMessage());
                    }
                }
            }
        } catch (Exception e) {
            HorrorSteveMod.LOG.warn("Could not scan custom dialogue folder", e);
        }
        loaded = true;
        HorrorSteveMod.LOG.info("Dialogue loaded: {} keys", LINES.size());
    }

    private static void merge(InputStream in) throws Exception {
        try (Reader r = new InputStreamReader(in, StandardCharsets.UTF_8)) {
            JsonElement root = JsonParser.parseReader(r);
            if (root.isJsonObject()) walk("", root.getAsJsonObject());
        }
    }

    private static void walk(String prefix, JsonObject obj) {
        for (Map.Entry<String, JsonElement> e : obj.entrySet()) {
            String key = prefix.isEmpty() ? e.getKey() : prefix + "." + e.getKey();
            JsonElement v = e.getValue();
            if (v.isJsonObject()) {
                walk(key, v.getAsJsonObject());
            } else if (v.isJsonArray()) {
                JsonArray arr = v.getAsJsonArray();
                List<String> list = LINES.computeIfAbsent(key, k -> new ArrayList<>());
                for (JsonElement x : arr) if (x.isJsonPrimitive()) list.add(x.getAsString());
            } else if (v.isJsonPrimitive()) {
                LINES.computeIfAbsent(key, k -> new ArrayList<>()).add(v.getAsString());
            }
        }
    }

    public static List<String> get(String key) {
        if (!loaded) reload();
        List<String> l = LINES.get(key);
        return l == null ? List.of() : l;
    }

    public static boolean has(String key) {
        return !get(key).isEmpty();
    }

    public static String pick(String key) {
        return Rand.pick(get(key));
    }

    public static int totalLines() {
        if (!loaded) reload();
        int n = 0;
        for (List<String> l : LINES.values()) n += l.size();
        return n;
    }
}
