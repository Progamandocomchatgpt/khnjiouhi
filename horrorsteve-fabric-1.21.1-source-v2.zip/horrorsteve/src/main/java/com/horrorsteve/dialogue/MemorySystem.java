package com.horrorsteve.dialogue;

import com.horrorsteve.progression.PlayerProfile;
import com.horrorsteve.progression.Stat;
import com.horrorsteve.util.Rand;

import java.util.ArrayList;
import java.util.List;

/**
 * The entity only claims to remember things that really happened: every candidate here is gated by a persisted counter
 * or flag in the player's profile.
 */
public final class MemorySystem {
    private MemorySystem() {}

    private static void add(List<String> keys, boolean cond, String key) {
        if (cond && DialogueDatabase.has(key)) keys.add(key);
    }

    private static List<String> candidates(PlayerProfile p, ChatCategory cat) {
        List<String> k = new ArrayList<>();
        add(k, p.get(Stat.GO_AWAY) >= 2 && (cat == ChatCategory.STOP || cat == ChatCategory.OTHER), "memory.go_away");
        add(k, p.get(Stat.ATTACKS) >= 1 && (cat == ChatCategory.THREAT || cat == ChatCategory.INSULT || cat == ChatCategory.ABOUT_ENTITY), "memory.attacked");
        add(k, p.get(Stat.RAN) >= 3 && (cat == ChatCategory.ESCAPE || cat == ChatCategory.FEAR || cat == ChatCategory.STOP), "memory.ran");
        add(k, p.get(Stat.ASKED_WHERE) >= 2 && cat == ChatCategory.LOCATION, "memory.asked_where");
        add(k, p.get(Stat.INSULTS) >= 2 && (cat == ChatCategory.INSULT || cat == ChatCategory.GREETING || cat == ChatCategory.APOLOGY), "memory.insults");
        add(k, p.get(Stat.IGNORED) >= 3 && (cat == ChatCategory.GREETING || cat == ChatCategory.QUESTION), "memory.ignored");
        add(k, p.get(Stat.DEATHS) >= 2 && (cat == ChatCategory.DEATH || cat == ChatCategory.FEAR || cat == ChatCategory.HELP), "memory.deaths");
        add(k, p.get(Stat.MEME67) >= 1 && (cat == ChatCategory.LAUGH || cat == ChatCategory.OTHER || cat == ChatCategory.GREETING), "memory.meme67");
        add(k, p.get(Stat.SIGNS_DESTROYED) >= 1 && (cat == ChatCategory.QUESTION || cat == ChatCategory.ABOUT_ENTITY), "memory.signs_destroyed");
        add(k, p.get(Stat.CONVERSATIONS) >= 15 && (cat == ChatCategory.GREETING || cat == ChatCategory.THANKS), "memory.talkative");
        add(k, p.get(Stat.INSTRUCTIONS_REFUSED) >= 2 && (cat == ChatCategory.REQUEST || cat == ChatCategory.QUESTION), "memory.refused");
        add(k, p.get(Stat.SLEEPS) >= 5 && (cat == ChatCategory.GREETING || cat == ChatCategory.OTHER), "memory.slept");
        add(k, p.get(Stat.FACE_SECONDS) >= 30 && (cat == ChatCategory.IDENTITY || cat == ChatCategory.REAL), "memory.stared");
        return k;
    }

    /** A truthful memory line relevant to this kind of message, or null. */
    public static String line(PlayerProfile p, ChatCategory cat) {
        List<String> keys = candidates(p, cat);
        if (keys.isEmpty()) return null;
        return DialogueDatabase.pick(Rand.pick(keys));
    }

    /** A truthful memory line triggered by a specific key (used by events); null if the condition fails. */
    public static String forKey(PlayerProfile p, String key) {
        return DialogueDatabase.has(key) ? DialogueDatabase.pick(key) : null;
    }
}
