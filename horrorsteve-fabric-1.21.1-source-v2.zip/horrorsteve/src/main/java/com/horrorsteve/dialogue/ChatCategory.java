package com.horrorsteve.dialogue;

public enum ChatCategory {
    GREETING, QUESTION, THREAT, FEAR, INSULT, REQUEST, IDENTITY, LOCATION, MINECRAFT, WORLD,
    ABOUT_ENTITY, DEATH, ESCAPE, STOP, REAL, THANKS, APOLOGY, LAUGH, HELP, HEROBRINE, OTHER;

    public String key() {
        return name().toLowerCase();
    }
}
