package com.horrorsteve.dialogue;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Pattern;

/** Keyword classification of what the player typed. Ordered: the first matching pattern wins. */
public final class ChatClassifier {
    private static final Map<ChatCategory, Pattern> PATTERNS = new LinkedHashMap<>();

    private static void p(ChatCategory c, String regex) {
        PATTERNS.put(c, Pattern.compile(regex, Pattern.CASE_INSENSITIVE));
    }

    static {
        p(ChatCategory.HEROBRINE, "\\b(herobrine|null|entity ?303|notch)\\b");
        p(ChatCategory.THREAT, "\\b(kill you|i will kill|i'll kill|destroy you|delete you|ban you|i'll find you|i will find you|hunt you|i'll end you|you're dead|you are dead|come at me|fight me|i'm going to kill)\\b");
        p(ChatCategory.INSULT, "\\b(stupid|idiot|dumb|ugly|noob|trash|loser|moron|creep|freak|garbage|shut up|hate you|fuck|shit|bitch|bastard|asshole|suck)\\b");
        p(ChatCategory.STOP, "\\b(go away|leave me alone|stop it|stop following|stop watching|stop that|stop|get lost|piss off|leave me|back off|don'?t follow|quit it)\\b");
        p(ChatCategory.APOLOGY, "\\b(sorry|apologi[sz]e|forgive me|my bad)\\b");
        p(ChatCategory.THANKS, "\\b(thanks|thank you|thx|ty|appreciate)\\b");
        p(ChatCategory.FEAR, "\\b(scared|afraid|terrified|frightened|creepy|i'?m scared|please don'?t|don'?t hurt|spooked|freaked)\\b");
        p(ChatCategory.HELP, "\\b(help|save me|somebody|anyone there|is anyone)\\b");
        p(ChatCategory.LOCATION, "\\b(where are you|where r u|where'?re you|where u at|show yourself|come out|where is steve|where did you go|are you near|are you here|are you close|where is it|where were you)\\b");
        p(ChatCategory.REAL, "\\b(are you real|r u real|you real|do you exist|are you a mod|are you part of the game|are you a bug|are you a glitch|is this real|are you ai)\\b");
        p(ChatCategory.IDENTITY, "\\b(who are you|what are you|who r u|what r u|your name|who is this|what is your name|who is steve|who made you|who installed)\\b");
        p(ChatCategory.ESCAPE, "\\b(escape|get out|how do i leave|how to leave|let me go|let me out|let me leave|run away|how do i get away|way out|exit)\\b");
        p(ChatCategory.DEATH, "\\b(die|death|dead|dying|kill me|am i dead|will i die|afterlife|respawn)\\b");
        p(ChatCategory.ABOUT_ENTITY, "\\b(what do you want|why are you|why me|why do you|what is your goal|what's your goal|what is your purpose|why are you following|why are you watching|are you alone|do you live|where do you live|do you sleep|what do you do)\\b");
        p(ChatCategory.WORLD, "\\b(world|seed|dimension|nether|the end|biome|village|stronghold|ender dragon|overworld|portal|chunk|sky|moon)\\b");
        p(ChatCategory.MINECRAFT, "\\b(minecraft|creeper|zombie|skeleton|enderman|mojang|mod|modded|fabric|server|steve|alex|diamond|netherite|redstone|sword|pickaxe)\\b");
        p(ChatCategory.REQUEST, "\\b(can you|could you|would you|will you|give me|show me|tell me|please|let me|teach me|do something)\\b");
        p(ChatCategory.GREETING, "^\\s*(hi|hello|hey|yo|sup|hii+|heya|howdy|greetings|good (morning|evening|night|day)|hola|what'?s up|wassup)\\b");
        p(ChatCategory.LAUGH, "\\b(lol|lmao|haha+|hehe+|rofl|xd|funny)\\b");
    }

    private ChatClassifier() {}

    public static ChatCategory classify(String text) {
        String t = text == null ? "" : text.trim();
        if (t.isEmpty()) return ChatCategory.OTHER;
        for (Map.Entry<ChatCategory, Pattern> e : PATTERNS.entrySet()) {
            if (e.getValue().matcher(t).find()) return e.getKey();
        }
        if (t.endsWith("?")) return ChatCategory.QUESTION;
        return ChatCategory.OTHER;
    }

    /** "go away" specifically (memory material), as opposed to other stop requests. */
    public static boolean isGoAway(String text) {
        return text != null && Pattern.compile("\\b(go away|leave me alone|get lost|piss off|leave me|back off)\\b", Pattern.CASE_INSENSITIVE).matcher(text).find();
    }
}
