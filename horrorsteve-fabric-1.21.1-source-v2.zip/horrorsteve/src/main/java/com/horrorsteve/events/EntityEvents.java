package com.horrorsteve.events;

import com.horrorsteve.ai.SpawnLocator;
import com.horrorsteve.config.HorrorConfig;
import com.horrorsteve.server.HorrorDirector;
import com.horrorsteve.server.Jumpscares;
import com.horrorsteve.util.Geo;
import com.horrorsteve.util.Rand;
import com.horrorsteve.util.Scheduler;
import com.horrorsteve.world.RestorationManager;
import com.horrorsteve.world.WorldProtection;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/** Appearances, jumpscares, chases, traps. */
public final class EntityEvents {
    private EntityEvents() {}

    public static void register() {
        EventRegistry.add("entity_appear", EventRarity.COMMON, 1, 7, 120, c -> HorrorDirector.mainEntityOf(c.player()) == null, c ->
                HorrorDirector.spawnMain(c.player(), SpawnLocator.defaultFor(c.world(), c.player(), c.stage())));
        EventRegistry.add("jumpscare_behind", EventRarity.RARE, 4, 7, 300, c -> Jumpscares.allowed(c.player(), false),
                c -> Jumpscares.behind(c.player(), false));
        EventRegistry.add("jumpscare_face", EventRarity.RARE, 4, 7, 300, c -> Jumpscares.allowed(c.player(), false),
                c -> Jumpscares.face(c.player(), false));
        EventRegistry.add("jumpscare_blackout", EventRarity.RARE, 4, 7, 300, c -> Jumpscares.allowed(c.player(), false),
                c -> Jumpscares.blackout(c.player(), false));
        EventRegistry.add("jumpscare_rush", EventRarity.RARE, 5, 7, 300, c -> Jumpscares.allowed(c.player(), false),
                c -> Jumpscares.rush(c.player(), false));
        EventRegistry.add("chase", EventRarity.RARE, 4, 7, 300,
                c -> !c.profile().flag("ending_peace") && Scheduler.now() - c.session().lastChaseTick > 20 * 90,
                c -> HorrorDirector.startChase(c.player()));

        EventRegistry.add("trap_web", EventRarity.UNCOMMON, 4, 7, 200, c -> true, c -> {
            Vec3d look = Geo.horizontalLook(c.player());
            for (int i = 2; i <= 4; i++) {
                BlockPos p = BlockPos.ofFloored(c.player().getPos().add(look.multiply(i)));
                if (WorldProtection.isFree(c.world(), p)) RestorationManager.change(c.world(), p, Blocks.COBWEB.getDefaultState(), 25);
            }
        });
        EventRegistry.add("trap_walls", EventRarity.RARE, 5, 7, 400, c -> true, c -> {
            Vec3d back = Geo.horizontalLook(c.player()).multiply(-2.5);
            BlockPos base = BlockPos.ofFloored(c.player().getPos().add(back));
            for (int y = 0; y <= 1; y++) {
                BlockPos p = base.up(y);
                if (WorldProtection.isFree(c.world(), p)) RestorationManager.change(c.world(), p, Blocks.COBBLESTONE.getDefaultState(), 40);
            }
        });
        EventRegistry.add("block_trail", EventRarity.RARE, 4, 7, 300, c -> HorrorConfig.get().blockDestruction, c -> {
            Vec3d back = c.player().getPos().subtract(Geo.horizontalLook(c.player()).multiply(4));
            EventUtil.destroyAround(c.world(), back, 4, 8, HorrorConfig.get().restoreDelaySeconds);
        });
    }
}
