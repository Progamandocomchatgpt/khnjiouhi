package com.horrorsteve.events;

import com.horrorsteve.HorrorSteveMod;
import com.horrorsteve.config.HorrorConfig;
import com.horrorsteve.util.Rand;
import com.horrorsteve.util.Scheduler;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Predicate;

/** All events, grouped by rarity. Add an event anywhere with {@link #add}. */
public final class EventRegistry {
    private static final Map<String, HorrorEvent> EVENTS = new LinkedHashMap<>();

    private EventRegistry() {}

    public static void bootstrap() {
        EVENTS.clear();
        EnvironmentEvents.register();
        IllusionEvents.register();
        SystemEvents.register();
        EntityEvents.register();
        DimensionEvents.register();
        HorrorSteveMod.LOG.info("{} horror events registered", EVENTS.size());
    }

    public static void add(String id, EventRarity rarity, int minStage, int maxStage, int cooldownSeconds,
                           Predicate<EventContext> cond, Consumer<EventContext> action) {
        EVENTS.put(id, new HorrorEvent(id, rarity, minStage, maxStage, cooldownSeconds, cond, action));
    }

    public static void add(String id, EventRarity rarity, int minStage, int cooldownSeconds, Consumer<EventContext> action) {
        add(id, rarity, minStage, 7, cooldownSeconds, c -> true, action);
    }

    public static HorrorEvent get(String id) {
        return EVENTS.get(id);
    }

    public static List<String> ids() {
        return new ArrayList<>(EVENTS.keySet());
    }

    public static int count() {
        return EVENTS.size();
    }

    /** Picks a weighted event whose stage, cooldown and condition all fit right now. */
    public static HorrorEvent pick(EventContext c) {
        List<HorrorEvent> pool = new ArrayList<>();
        long now = Scheduler.now();
        double fear = c.profile().fear / 100.0;
        for (HorrorEvent e : EVENTS.values()) {
            if (c.stage() < e.minStage || c.stage() > e.maxStage) continue;
            Long last = c.session().eventCooldowns.get(e.id);
            if (last != null && now - last < 20L * e.cooldownSeconds) continue;
            pool.add(e);
        }
        for (int tries = 0; tries < 8 && !pool.isEmpty(); tries++) {
            HorrorEvent e = Rand.weighted(pool, x -> x.rarity.weight * (x.rarity.ordinal() >= 2 ? (0.5 + fear + HorrorConfig.get().horrorIntensity * 0.4) : 1.0));
            if (e == null) return null;
            if (e.canRun(c)) return e;
            pool.remove(e);
        }
        return null;
    }

    public static boolean run(HorrorEvent e, EventContext c) {
        try {
            c.session().eventCooldowns.put(e.id, Scheduler.now());
            e.run(c);
            if (HorrorConfig.get().debug) HorrorSteveMod.LOG.info("event {} -> {}", e.id, c.player().getName().getString());
            return true;
        } catch (Exception ex) {
            HorrorSteveMod.LOG.error("Event {} failed", e.id, ex);
            return false;
        }
    }

    public static boolean runRandom(EventContext c) {
        HorrorEvent e = pick(c);
        return e != null && run(e, c);
    }
}
