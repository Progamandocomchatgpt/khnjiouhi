package com.horrorsteve.events;

import com.horrorsteve.ai.HorrorBrain;
import com.horrorsteve.ai.SpawnLocator;
import com.horrorsteve.config.HorrorConfig;
import com.horrorsteve.dialogue.DialogueDatabase;
import com.horrorsteve.dialogue.DialogueEngine;
import com.horrorsteve.entity.HorrorSteveEntity;
import com.horrorsteve.network.FxPayload;
import com.horrorsteve.progression.PlayerProfile;
import com.horrorsteve.progression.Stat;
import com.horrorsteve.server.Fx;
import com.horrorsteve.server.HorrorDirector;
import com.horrorsteve.server.InstructionSystem;
import com.horrorsteve.server.Messenger;
import com.horrorsteve.server.Sfx;
import com.horrorsteve.sound.ModSounds;
import com.horrorsteve.util.Geo;
import com.horrorsteve.util.Rand;
import com.horrorsteve.util.Scheduler;
import com.horrorsteve.world.IllusionManager;
import com.horrorsteve.world.RestorationManager;
import com.horrorsteve.world.StructureBuilder;
import com.horrorsteve.world.WorldProtection;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.CampfireBlock;
import net.minecraft.block.CandleBlock;
import net.minecraft.block.DoorBlock;
import net.minecraft.block.enums.DoubleBlockHalf;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.passive.VillagerEntity;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Doors, lights, signs, animals, sounds, silence, weather: the world quietly going wrong. */
public final class EnvironmentEvents {
    private static final Set<MobEntity> FROZEN = new HashSet<>();

    private EnvironmentEvents() {}

    public static void releaseFrozen() {
        for (MobEntity m : FROZEN) {
            try {
                m.setAiDisabled(false);
            } catch (Exception ignored) {
            }
        }
        FROZEN.clear();
    }

    private static boolean doorClosed(BlockState s) {
        return s.isIn(BlockTags.WOODEN_DOORS) && s.get(DoorBlock.HALF) == DoubleBlockHalf.LOWER && !s.get(DoorBlock.OPEN);
    }

    private static boolean doorOpen(BlockState s) {
        return s.isIn(BlockTags.WOODEN_DOORS) && s.get(DoorBlock.HALF) == DoubleBlockHalf.LOWER && s.get(DoorBlock.OPEN);
    }

    private static void toggleDoors(EventContext c, boolean open) {
        List<BlockPos> doors = EventUtil.scan(c.world(), c.player().getBlockPos(), 8, open ? EnvironmentEvents::doorClosed : EnvironmentEvents::doorOpen, 6);
        if (doors.isEmpty()) return;
        int n = Math.min(doors.size(), Rand.range(1, 2));
        for (int i = 0; i < n; i++) {
            BlockPos p = doors.get(Rand.r().nextInt(doors.size()));
            BlockState s = c.world().getBlockState(p);
            if (s.getBlock() instanceof DoorBlock d) d.setOpen(null, c.world(), s, p, open);
        }
    }

    /** Extinguishes nearby torches, candles, lanterns and campfires - on this player's screen only. */
    public static boolean lightsOut(EventContext c) {
        ServerWorld w = c.world();
        Map<BlockPos, BlockState> fake = new HashMap<>();
        for (BlockPos p : EventUtil.scan(w, c.player().getBlockPos(), 12, s ->
                s.isOf(Blocks.TORCH) || s.isOf(Blocks.WALL_TORCH) || s.isOf(Blocks.SOUL_TORCH) || s.isOf(Blocks.SOUL_WALL_TORCH)
                        || s.isOf(Blocks.LANTERN) || s.isOf(Blocks.SOUL_LANTERN)
                        || (s.getBlock() instanceof CandleBlock && s.get(CandleBlock.LIT))
                        || (s.getBlock() instanceof CampfireBlock && s.get(CampfireBlock.LIT)), 120)) {
            BlockState s = w.getBlockState(p);
            if (s.getBlock() instanceof CandleBlock) fake.put(p, s.with(CandleBlock.LIT, false));
            else if (s.getBlock() instanceof CampfireBlock) fake.put(p, s.with(CampfireBlock.LIT, false));
            else fake.put(p, Blocks.AIR.getDefaultState());
        }
        if (fake.isEmpty()) return false;
        IllusionManager.show(c.player(), fake, 20 * Rand.range(20, 50), 0);
        BlockPos first = fake.keySet().iterator().next();
        Sfx.at(c.player(), SoundEvents.BLOCK_FIRE_EXTINGUISH, Vec3d.ofCenter(first), 0.7f, 1.0f, false);
        return true;
    }

    private static void freezeMobs(EventContext c, int radius, int max, int ticks, boolean everything) {
        List<MobEntity> mobs = c.world().getEntitiesByClass(MobEntity.class, c.player().getBoundingBox().expand(radius),
                m -> !(m instanceof HorrorSteveEntity) && m.isAlive() && !m.isAiDisabled());
        int n = 0;
        for (MobEntity m : mobs) {
            if (n++ >= max) break;
            if (!everything && Rand.chance(0.25)) continue;
            m.setAiDisabled(true);
            FROZEN.add(m);
            for (int t = 0; t < ticks; t += 5) {
                Scheduler.later(t, () -> {
                    if (m.isAlive()) m.getLookControl().lookAt(c.player(), 40f, 40f);
                });
            }
            Scheduler.later(ticks, () -> {
                m.setAiDisabled(false);
                FROZEN.remove(m);
            });
        }
    }

    public static void register() {
        EventRegistry.add("door_open", EventRarity.COMMON, 2, 7, 60,
                c -> !EventUtil.scan(c.world(), c.player().getBlockPos(), 8, EnvironmentEvents::doorClosed, 1).isEmpty(),
                c -> toggleDoors(c, true));
        EventRegistry.add("door_close", EventRarity.COMMON, 2, 7, 60,
                c -> !EventUtil.scan(c.world(), c.player().getBlockPos(), 8, EnvironmentEvents::doorOpen, 1).isEmpty(),
                c -> toggleDoors(c, false));
        EventRegistry.add("lights_out", EventRarity.COMMON, 2, 7, 90, c -> true, c -> {
            if (!lightsOut(c)) Sfx.behind(c.player(), ModSounds.BREATH, 2.5, 0.4f, 0.9f);
        });
        EventRegistry.add("sign_appear", EventRarity.UNCOMMON, 3, 7, 240, c -> true, c -> {
            Vec3d v = SpawnLocator.ring(c.world(), c.player(), 8, 18, 0, 360, false);
            if (v == null) return;
            StructureBuilder.placeTemporarySign(c.world(), BlockPos.ofFloored(v), StructureBuilder.randomLines(), 20 * 60);
        });
        EventRegistry.add("clue_sign", EventRarity.UNCOMMON, 3, 7, 480, c -> true, c -> {
            Vec3d v = SpawnLocator.ring(c.world(), c.player(), 7, 14, 0, 360, false);
            if (v == null) return;
            BlockPos target = StructureBuilder.nearestStructure(c.world(), c.player().getBlockPos());
            if (target == null) target = c.player().getBlockPos().add(Rand.range(-400, 400), 0, Rand.range(-400, 400));
            String head = DialogueDatabase.pick("signs.clue");
            String[] lines = {head == null ? "Come" : head, "x " + target.getX(), "y " + target.getY(), "z " + target.getZ()};
            StructureBuilder.placeTemporarySign(c.world(), BlockPos.ofFloored(v), lines, 20 * 60 * 5);
        });
        EventRegistry.add("terrain_shift", EventRarity.UNCOMMON, 3, 7, 200, c -> true, c -> {
            Vec3d v = SpawnLocator.ring(c.world(), c.player(), 6, 14, 0, 360, false);
            if (v == null) return;
            BlockPos base = BlockPos.ofFloored(v);
            int delay = 300;
            if (Rand.chance(0.6)) {
                BlockState b = Rand.pick(Blocks.DIRT.getDefaultState(), Blocks.STONE.getDefaultState(), Blocks.MOSS_BLOCK.getDefaultState());
                for (int i = 0; i < 3; i++) if (WorldProtection.isFree(c.world(), base.up(i))) RestorationManager.change(c.world(), base.up(i), b, delay);
            } else if (WorldProtection.canChange(c.world(), base.down())) {
                RestorationManager.change(c.world(), base.down(), Blocks.AIR.getDefaultState(), delay);
            }
        });
        EventRegistry.add("animals_stare", EventRarity.COMMON, 2, 7, 120,
                c -> !c.world().getEntitiesByClass(AnimalEntity.class, c.player().getBoundingBox().expand(24), a -> true).isEmpty(),
                c -> {
                    List<AnimalEntity> animals = c.world().getEntitiesByClass(AnimalEntity.class, c.player().getBoundingBox().expand(24), a -> true);
                    int n = 0;
                    for (AnimalEntity a : animals) {
                        if (n++ >= 8) break;
                        a.getNavigation().stop();
                        for (int t = 0; t < 120; t += 5) {
                            Scheduler.later(t, () -> {
                                if (a.isAlive()) a.getLookControl().lookAt(c.player(), 40f, 40f);
                            });
                        }
                    }
                });
        EventRegistry.add("villager_headshake", EventRarity.UNCOMMON, 2, 7, 150,
                c -> !c.world().getEntitiesByClass(VillagerEntity.class, c.player().getBoundingBox().expand(24), v -> true).isEmpty(),
                c -> {
                    for (VillagerEntity v : c.world().getEntitiesByClass(VillagerEntity.class, c.player().getBoundingBox().expand(24), x -> true)) {
                        v.setHeadRollingTimeLeft(40);
                        v.playSound(SoundEvents.ENTITY_VILLAGER_NO, 1.0f, 0.8f);
                        if (c.stage() >= 5) {
                            v.getNavigation().stop();
                            for (int t = 0; t < 160; t += 5) {
                                Scheduler.later(t, () -> {
                                    if (v.isAlive()) v.getLookControl().lookAt(c.player(), 40f, 40f);
                                });
                            }
                        }
                    }
                });
        EventRegistry.add("cave_sounds", EventRarity.COMMON, 2, 7, 60, EventContext::underground, c ->
                Sfx.around(c.player(), ModSounds.AMBIENT_FAR, 18, 40, 0.55f, Rand.range(0.7f, 1.1f)));
        EventRegistry.add("sudden_silence", EventRarity.UNCOMMON, 2, 7, 300, c -> true, c -> {
            int len = Rand.range(140, 260);
            for (int t = 0; t < len; t += 10) {
                Scheduler.later(t, () -> {
                    if (!c.player().isRemoved()) Sfx.stopAll(c.player());
                });
            }
            Fx.send(c.player(), FxPayload.VIGNETTE, len, 0.4f);
        });
        EventRegistry.add("weather_change", EventRarity.UNCOMMON, 5, 7, 900,
                c -> c.world().getRegistryKey() == net.minecraft.world.World.OVERWORLD && !c.world().isRaining(),
                c -> c.world().setWeather(0, 20 * Rand.range(300, 600), true, Rand.chance(0.4)));
        EventRegistry.add("time_flicker", EventRarity.RARE, 5, 7, 900,
                c -> c.server().getCurrentPlayerCount() == 1 && c.world().getRegistryKey() == net.minecraft.world.World.OVERWORLD,
                c -> {
                    final long orig = c.world().getTimeOfDay();
                    c.world().setTimeOfDay(18000);
                    Scheduler.later(120, () -> c.world().setTimeOfDay(orig + 120));
                });
        EventRegistry.add("invisible_footsteps", EventRarity.COMMON, 2, 7, 120, c -> true, c -> {
            for (int k = 0; k < 9; k++) {
                final double dist = 14 - k * 1.5;
                Scheduler.later(k * 10, () -> {
                    if (!c.player().isRemoved()) Sfx.behind(c.player(), ModSounds.STEP, Math.max(1.5, dist), 0.7f, Rand.range(0.85f, 1.05f));
                });
            }
        });
        EventRegistry.add("breathing", EventRarity.COMMON, 2, 7, 90, c -> true, c ->
                Sfx.behind(c.player(), ModSounds.BREATH, 1.4, 0.4f, Rand.range(0.8f, 1.0f)));
        EventRegistry.add("whispers", EventRarity.COMMON, 2, 7, 90, c -> true, c -> {
            for (int k = 0; k < 3; k++) {
                Scheduler.later(k * 25, () -> {
                    if (!c.player().isRemoved()) Sfx.around(c.player(), ModSounds.WHISPER, 2, 5, 0.6f, Rand.range(0.9f, 1.1f));
                });
            }
        });
        EventRegistry.add("shadow_pulse", EventRarity.UNCOMMON, 2, 7, 150, c -> true, c -> {
            Fx.send(c.player(), FxPayload.DARKNESS, 35, 0.35f);
            Fx.send(c.player(), FxPayload.VIGNETTE, 90, 0.6f);
            Sfx.behind(c.player(), ModSounds.STATIC, 3, 0.3f, 0.8f);
        });
        EventRegistry.add("window_watcher", EventRarity.UNCOMMON, 2, 7, 300, c -> !c.world().isSkyVisible(c.player().getBlockPos()), c -> {
            Vec3d v = SpawnLocator.ring(c.world(), c.player(), 4, 9, 0, 360, false);
            if (v != null) HorrorDirector.spawnDecoy(c.player(), v, 20 * 25, HorrorBrain.DecoyMode.STARE);
        });
        EventRegistry.add("mob_freeze", EventRarity.UNCOMMON, 3, 7, 240, c -> true, c -> freezeMobs(c, 20, 12, 160, false));
        EventRegistry.add("follow_glimpse", EventRarity.COMMON, 2, 7, 150, c -> true, c -> {
            Vec3d v = SpawnLocator.behind(c.world(), c.player(), 6, 10);
            if (v != null) HorrorDirector.spawnDecoy(c.player(), v, 20 * 8, HorrorBrain.DecoyMode.STARE);
        });
        EventRegistry.add("eye_ambush", EventRarity.UNCOMMON, 3, 7, 300, c -> true, c -> {
            Vec3d v = SpawnLocator.ring(c.world(), c.player(), 10, 22, 0, 30, false);
            if (v != null) HorrorDirector.spawnDecoy(c.player(), v, 20 * 10, HorrorBrain.DecoyMode.STARE);
        });
        EventRegistry.add("fake_sounds", EventRarity.COMMON, 2, 7, 60, c -> true, c -> {
            SoundEvent s = Rand.pick(SoundEvents.ENTITY_CREEPER_PRIMED, SoundEvents.ENTITY_ZOMBIE_AMBIENT,
                    SoundEvents.ENTITY_SKELETON_AMBIENT, SoundEvents.BLOCK_WOODEN_DOOR_OPEN, SoundEvents.BLOCK_CHEST_OPEN,
                    SoundEvents.BLOCK_STONE_BREAK, SoundEvents.ENTITY_ENDERMAN_STARE, ModSounds.KNOCK);
            if (Rand.chance(0.5)) Sfx.behind(c.player(), s, Rand.range(3, 8), 0.8f, 1.0f);
            else Sfx.around(c.player(), s, 4, 20, 0.8f, 1.0f);
        });
        EventRegistry.add("instruction", EventRarity.UNCOMMON, 2, 7, 200, c -> c.session().instruction == null,
                c -> InstructionSystem.give(c.player()));
        EventRegistry.add("structure_spawn", EventRarity.VERY_RARE, 3, 7, 1200,
                c -> HorrorConfig.get().structuresEnabled, c -> StructureBuilder.buildRandom(c.world(), c.player()));
        EventRegistry.add("fake_player", EventRarity.UNCOMMON, 3, 7, 400, c -> true, c -> {
            Vec3d v = SpawnLocator.ring(c.world(), c.player(), 14, 30, 0, 360, false);
            if (v == null) return;
            if (HorrorDirector.spawnFakePlayer(c.player(), v) != null) c.profile().inc(Stat.FAKE_PLAYERS_SEEN);
        });
        EventRegistry.add("echo_player", EventRarity.LEGENDARY, 4, 7, 1800, c -> !c.profile().chatHistory.isEmpty(), c -> {
            String last = c.profile().chatHistory.peekLast();
            String t = DialogueDatabase.pick("echo.templates");
            if (t == null) t = "You said: \"{msg}\"";
            Messenger.say(c.player(), DialogueEngine.fill(t, c.player(), last));
        });
        EventRegistry.add("legendary_stare", EventRarity.LEGENDARY, 6, 7, 2400, c -> true, c -> {
            freezeMobs(c, 40, 40, 240, true);
            for (int t = 0; t < 240; t += 10) {
                Scheduler.later(t, () -> {
                    if (!c.player().isRemoved()) Sfx.stopAll(c.player());
                });
            }
            Fx.send(c.player(), FxPayload.VIGNETTE, 260, 0.8f);
            Vec3d v = SpawnLocator.ring(c.world(), c.player(), 10, 14, 0, 40, false);
            if (v != null) HorrorDirector.spawnDecoy(c.player(), v, 20 * 14, HorrorBrain.DecoyMode.STARE);
            String line = DialogueDatabase.pick("legendary.stare");
            if (line != null) Messenger.sayLater(c.player(), line, 60);
        });
    }
}
