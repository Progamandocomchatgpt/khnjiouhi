package com.horrorsteve.events;

import java.util.function.Consumer;
import java.util.function.Predicate;

public final class HorrorEvent {
    public final String id;
    public final EventRarity rarity;
    public final int minStage;
    public final int maxStage;
    public final int cooldownSeconds;
    private final Predicate<EventContext> condition;
    private final Consumer<EventContext> action;

    public HorrorEvent(String id, EventRarity rarity, int minStage, int maxStage, int cooldownSeconds,
                       Predicate<EventContext> condition, Consumer<EventContext> action) {
        this.id = id;
        this.rarity = rarity;
        this.minStage = minStage;
        this.maxStage = maxStage;
        this.cooldownSeconds = cooldownSeconds;
        this.condition = condition;
        this.action = action;
    }

    public boolean canRun(EventContext c) {
        return c.stage() >= minStage && c.stage() <= maxStage && condition.test(c);
    }

    public void run(EventContext c) {
        action.accept(c);
    }
}
