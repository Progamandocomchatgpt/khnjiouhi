package com.horrorsteve.events;

public enum EventRarity {
    COMMON(100), UNCOMMON(40), RARE(12), VERY_RARE(4), LEGENDARY(1);

    public final double weight;

    EventRarity(double weight) {
        this.weight = weight;
    }
}
