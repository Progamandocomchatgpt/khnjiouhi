package com.horrorsteve.events;

import com.horrorsteve.ai.HorrorBrain;
import com.horrorsteve.ai.SpawnLocator;
import com.horrorsteve.server.HorrorDirector;
import com.horrorsteve.util.Geo;
import com.horrorsteve.util.Rand;
import com.horrorsteve.world.IllusionManager;
import com.horrorsteve.world.WorldProtection;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.Map;

/** Fake structures, fake tunnels, fake copies. Packets only: nothing here ever touches the real world. */
public final class IllusionEvents {
    private IllusionEvents() {}

    public static void register() {
        EventRegistry.add("fake_pillar", EventRarity.UNCOMMON, 3, 7, 300, c -> true, c -> {
            Vec3d v = SpawnLocator.ring(c.world(), c.player(), 10, 18, 0, 60, false);
            if (v == null) return;
            BlockPos base = BlockPos.ofFloored(v);
            Map<BlockPos, BlockState> m = new HashMap<>();
            for (int i = 0; i < 8; i++) {
                BlockPos p = base.up(i);
                if (!WorldProtection.isFree(c.world(), p)) break;
                m.put(p, i == 7 ? Blocks.GLOWSTONE.getDefaultState() : Blocks.COBBLESTONE.getDefaultState());
            }
            IllusionManager.show(c.player(), m, 20 * 60, 6);
        });

        EventRegistry.add("fake_hut", EventRarity.RARE, 5, 7, 600, c -> true, c -> {
            Vec3d v = SpawnLocator.ring(c.world(), c.player(), 12, 25, 0, 90, false);
            if (v == null) return;
            BlockPos o = BlockPos.ofFloored(v);
            Map<BlockPos, BlockState> m = new HashMap<>();
            for (int x = -2; x <= 2; x++) for (int z = -2; z <= 2; z++) for (int y = 0; y <= 3; y++) {
                boolean wall = Math.abs(x) == 2 || Math.abs(z) == 2;
                boolean roof = y == 3;
                boolean door = x == 0 && z == -2 && y < 2;
                if ((wall || roof) && !door) {
                    BlockPos p = o.add(x, y, z);
                    if (WorldProtection.isFree(c.world(), p)) m.put(p, Blocks.OAK_PLANKS.getDefaultState());
                }
            }
            IllusionManager.show(c.player(), m, 20 * 90, 7);
        });

        EventRegistry.add("fake_tunnel", EventRarity.UNCOMMON, 5, 7, 400, EventContext::underground, c -> {
            Vec3d look = Geo.horizontalLook(c.player());
            double ax = Math.abs(look.x), az = Math.abs(look.z);
            int dx = ax > az ? (int) Math.signum(look.x) : 0;
            int dz = ax > az ? 0 : (int) Math.signum(look.z);
            BlockPos start = c.player().getBlockPos();
            Map<BlockPos, BlockState> m = new HashMap<>();
            for (int i = 3; i <= 11; i++) {
                for (int y = 0; y <= 1; y++) {
                    BlockPos p = start.add(dx * i, y, dz * i);
                    BlockState s = c.world().getBlockState(p);
                    if (!s.isAir() && WorldProtection.isNatural(s)) m.put(p, Blocks.AIR.getDefaultState());
                }
            }
            IllusionManager.show(c.player(), m, 20 * 40, 3);
        });

        EventRegistry.add("fake_decoys", EventRarity.RARE, 5, 7, 500, c -> true, c -> {
            for (int i = 0; i < 3; i++) {
                Vec3d v = SpawnLocator.ring(c.world(), c.player(), 14, 26, 0, 360, false);
                if (v != null) HorrorDirector.spawnDecoy(c.player(), v, 20 * 30, HorrorBrain.DecoyMode.STARE);
            }
        });
    }
}
