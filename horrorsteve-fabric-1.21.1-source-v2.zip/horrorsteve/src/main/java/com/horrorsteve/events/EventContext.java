package com.horrorsteve.events;

import com.horrorsteve.entity.HorrorSteveEntity;
import com.horrorsteve.progression.PlayerProfile;
import com.horrorsteve.server.PlayerSession;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;

/** Everything an event needs to know about the moment it runs. */
public record EventContext(MinecraftServer server, ServerWorld world, ServerPlayerEntity player, PlayerProfile profile,
                           PlayerSession session, int stage, HorrorSteveEntity entity) {
    public boolean underground() {
        return !world.isSkyVisible(player.getBlockPos()) && world.getRegistryKey() == net.minecraft.world.World.OVERWORLD;
    }

    public boolean night() {
        long t = world.getTimeOfDay() % 24000;
        return t >= 13000 && t <= 23000;
    }
}
