package com.horrorsteve.events;

import com.horrorsteve.ai.HorrorBrain;
import com.horrorsteve.ai.HorrorState;
import com.horrorsteve.ai.SpawnLocator;
import com.horrorsteve.dialogue.DialogueDatabase;
import com.horrorsteve.dialogue.DialogueEngine;
import com.horrorsteve.entity.HorrorSteveEntity;
import com.horrorsteve.network.FxPayload;
import com.horrorsteve.server.Fx;
import com.horrorsteve.server.HorrorDirector;
import com.horrorsteve.server.Messenger;
import com.horrorsteve.server.Sfx;
import com.horrorsteve.sound.ModSounds;
import com.horrorsteve.util.Rand;
import com.horrorsteve.util.Scheduler;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** Per-dimension behaviour (Nether is aggressive, the End is quiet and wrong) plus the stage-8 "unknown" events. */
public final class DimensionEvents {
    private DimensionEvents() {}

    private static boolean nether(EventContext c) {
        return c.world().getRegistryKey() == World.NETHER;
    }

    private static boolean end(EventContext c) {
        return c.world().getRegistryKey() == World.END;
    }

    public static void register() {
        EventRegistry.add("nether_ambush", EventRarity.UNCOMMON, 2, 7, 240,
                c -> nether(c) && HorrorDirector.mainEntityOf(c.player()) == null, c -> {
                    HorrorSteveEntity e = HorrorDirector.spawnMain(c.player(), SpawnLocator.Strategy.NEAR);
                    if (e != null && c.stage() >= 3 && e.hsBrain != null) e.hsBrain.forceState(HorrorState.HUNTING);
                });
        EventRegistry.add("nether_whisper", EventRarity.COMMON, 1, 7, 90, DimensionEvents::nether, c -> {
            Sfx.behind(c.player(), ModSounds.WHISPER, 2.0, 0.6f, 0.7f);
            if (Rand.chance(0.3)) DialogueEngine.context(c.player(), "nether", 30);
        });
        EventRegistry.add("end_stare", EventRarity.RARE, 1, 7, 400, DimensionEvents::end, c -> {
            Vec3d v = SpawnLocator.find(c.world(), c.player(), SpawnLocator.Strategy.SKY);
            if (v != null) HorrorDirector.spawnDecoy(c.player(), v, 20 * 25, HorrorBrain.DecoyMode.STARE);
        });
        EventRegistry.add("end_whisper", EventRarity.UNCOMMON, 2, 7, 150, DimensionEvents::end, c -> {
            Sfx.around(c.player(), ModSounds.WHISPER, 3, 8, 0.5f, 0.6f);
            if (Rand.chance(0.4)) DialogueEngine.context(c.player(), "end", 40);
        });
        EventRegistry.add("end_silence", EventRarity.VERY_RARE, 3, 7, 900, DimensionEvents::end, c -> {
            for (int t = 0; t < 400; t += 10) {
                Scheduler.later(t, () -> {
                    if (!c.player().isRemoved()) Sfx.stopAll(c.player());
                });
            }
            Fx.send(c.player(), FxPayload.VIGNETTE, 420, 0.6f);
            DialogueEngine.context(c.player(), "end", 120);
        });

        // stage 8: only reachable inside an unknown window
        EventRegistry.add("unknown_silence", EventRarity.LEGENDARY, 8, 8, 60, c -> true, c -> {
            for (int t = 0; t < 1000; t += 20) {
                Scheduler.later(t, () -> {
                    if (!c.player().isRemoved()) Sfx.stopAll(c.player());
                });
            }
            Fx.send(c.player(), FxPayload.VIGNETTE, 1000, 0.7f);
        });
        EventRegistry.add("unknown_watch", EventRarity.LEGENDARY, 8, 8, 60, c -> true, c -> {
            Vec3d v = SpawnLocator.ring(c.world(), c.player(), 40, 55, 0, 360, true);
            if (v == null) v = SpawnLocator.find(c.world(), c.player(), SpawnLocator.Strategy.SKY);
            if (v == null) return;
            HorrorSteveEntity e = HorrorDirector.spawnDecoy(c.player(), v, 20 * 60, HorrorBrain.DecoyMode.STARE);
            if (e != null) e.setDistort(HorrorSteveEntity.D_UNKNOWN);
        });
        EventRegistry.add("unknown_message", EventRarity.LEGENDARY, 8, 8, 30, c -> true, c -> {
            String line = DialogueDatabase.pick("unknown.message");
            if (line != null) Messenger.say(c.player(), line);
        });
    }
}
