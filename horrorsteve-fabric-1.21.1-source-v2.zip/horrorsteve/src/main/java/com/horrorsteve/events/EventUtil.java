package com.horrorsteve.events;

import com.horrorsteve.config.HorrorConfig;
import com.horrorsteve.util.Rand;
import com.horrorsteve.world.RestorationManager;
import com.horrorsteve.world.WorldProtection;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

public final class EventUtil {
    private EventUtil() {}

    public static List<BlockPos> scan(ServerWorld w, BlockPos center, int radius, Predicate<BlockState> test, int max) {
        List<BlockPos> out = new ArrayList<>();
        for (BlockPos p : BlockPos.iterate(center.add(-radius, -radius / 2, -radius), center.add(radius, radius / 2, radius))) {
            if (!w.isChunkLoaded(p)) continue;
            if (test.test(w.getBlockState(p))) {
                out.add(p.toImmutable());
                if (out.size() >= max) break;
            }
        }
        return out;
    }

    /**
     * Destroys up to "count" natural blocks around a point (never inside the protected set), logged for restoration.
     * Honours blockDestruction and maxDestructionRadius from the config.
     */
    public static int destroyAround(ServerWorld w, Vec3d center, int radius, int count, int restoreSeconds) {
        HorrorConfig c = HorrorConfig.get();
        if (!c.blockDestruction || c.maxDestructionRadius <= 0) return 0;
        int r = Math.min(radius, c.maxDestructionRadius);
        int done = 0;
        BlockPos o = BlockPos.ofFloored(center);
        for (int i = 0; i < count * 4 && done < count; i++) {
            BlockPos p = o.add(Rand.range(-r, r), Rand.range(-1, 3), Rand.range(-r, r));
            BlockState s = w.getBlockState(p);
            if (s.isAir() || !WorldProtection.canChange(w, p)) continue;
            if (RestorationManager.change(w, p, Blocks.AIR.getDefaultState(), restoreSeconds)) done++;
        }
        return done;
    }
}
