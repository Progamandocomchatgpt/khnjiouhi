package com.horrorsteve.events;

import com.horrorsteve.config.HorrorConfig;
import com.horrorsteve.dialogue.DialogueDatabase;
import com.horrorsteve.dialogue.DialogueEngine;
import com.horrorsteve.network.FxPayload;
import com.horrorsteve.network.OverlayPayload;
import com.horrorsteve.server.Fx;
import com.horrorsteve.server.HorrorDirector;
import com.horrorsteve.server.Jumpscares;
import com.horrorsteve.server.Messenger;
import com.horrorsteve.server.Sfx;
import com.horrorsteve.sound.ModSounds;
import com.horrorsteve.util.Rand;
import com.horrorsteve.world.IllusionManager;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Fake mod notices, fake loading, fake errors, fake join messages, fake advancements, fake crash screens.
 * All of it is chat text or HUD drawing. Nothing is written to disk and nothing can crash the game.
 */
public final class SystemEvents {
    private SystemEvents() {}

    private static boolean enabled() {
        return HorrorConfig.get().fakeSystemMessages;
    }

    private static String mod() {
        String m = DialogueDatabase.pick("fake_mod.names");
        return m == null ? "hollow_core" : m;
    }

    private static void lines(ServerPlayerEntity p, String key, String mod, Formatting color) {
        List<String> l = DialogueDatabase.get(key);
        if (l.isEmpty()) return;
        int n = Math.min(l.size(), Rand.range(2, 4));
        int delay = 0;
        for (int i = 0; i < n; i++) {
            String s = Rand.pick(l).replace("{mod}", mod).replace("{name}", p.getName().getString());
            Messenger.systemLater(p, s, color, delay);
            delay += Rand.range(8, 30);
        }
    }

    public static void register() {
        EventRegistry.add("fake_mod_notice", EventRarity.UNCOMMON, 6, 7, 300, c -> enabled(), c -> {
            String m = mod();
            String t = DialogueDatabase.pick("fake_mod.notices");
            if (t != null) Messenger.system(c.player(), "[" + m + "] " + t.replace("{mod}", m), Formatting.YELLOW);
            com.horrorsteve.server.Advancements.grant(c.player(), "who_installed_this");
        });
        EventRegistry.add("fake_registration", EventRarity.UNCOMMON, 6, 7, 300, c -> enabled(), c -> {
            lines(c.player(), "fake_mod.registration", mod(), Formatting.GRAY);
            com.horrorsteve.server.Advancements.grant(c.player(), "who_installed_this");
        });
        EventRegistry.add("fake_compat", EventRarity.UNCOMMON, 6, 7, 300, c -> enabled(),
                c -> lines(c.player(), "fake_mod.compat", mod(), Formatting.GOLD));
        EventRegistry.add("fake_error", EventRarity.RARE, 6, 7, 500, c -> enabled(),
                c -> lines(c.player(), "fake_mod.errors", mod(), Formatting.RED));
        EventRegistry.add("fake_loading", EventRarity.RARE, 6, 7, 600, c -> enabled(), c -> {
            Fx.overlay(c.player(), OverlayPayload.FAKE_LOADING, "Loading terrain...", 70);
            lines(c.player(), "fake_mod.loading", mod(), Formatting.GRAY);
        });
        EventRegistry.add("fake_saving", EventRarity.UNCOMMON, 6, 7, 400, c -> enabled(), c -> {
            Fx.overlay(c.player(), OverlayPayload.FAKE_SAVING, "Saving world...", 50);
            Messenger.systemLater(c.player(), "Saved the game", Formatting.WHITE, 40);
        });
        EventRegistry.add("fake_join_leave", EventRarity.UNCOMMON, 4, 7, 400, c -> enabled(), c -> {
            String n = HorrorDirector.randomFakeName();
            c.player().sendMessage(Text.literal(n + " joined the game").formatted(Formatting.YELLOW), false);
            if (Rand.chance(0.6)) {
                Messenger.sayAs(c.player(), n, DialogueEngine.fakePlayerChat());
            }
            com.horrorsteve.util.Scheduler.later(20 * Rand.range(4, 12), () -> {
                if (!c.player().isRemoved()) c.player().sendMessage(Text.literal(n + " left the game").formatted(Formatting.YELLOW), false);
            });
        });
        EventRegistry.add("fake_chat_player", EventRarity.UNCOMMON, 3, 7, 300, c -> enabled(), c -> {
            String n = HorrorDirector.randomFakeName();
            Messenger.sayAs(c.player(), n, DialogueEngine.fakePlayerChat());
        });
        EventRegistry.add("fake_advancement", EventRarity.RARE, 6, 7, 600, c -> enabled(), c -> {
            String a = DialogueDatabase.pick("fake_mod.advancements");
            if (a == null) a = "Are You Alone?";
            Text msg = Text.literal("Steve has made the advancement ").append(Text.literal("[" + a + "]").formatted(Formatting.GREEN));
            c.player().sendMessage(msg, false);
        });
        EventRegistry.add("fake_death", EventRarity.RARE, 6, 7, 800, c -> enabled(), c -> {
            String t = DialogueDatabase.pick("fake_mod.deaths");
            if (t == null) return;
            Messenger.system(c.player(), t.replace("{name}", c.player().getName().getString()), Formatting.WHITE);
        });
        EventRegistry.add("fake_crash", EventRarity.VERY_RARE, 7, 7, 1800, c -> Jumpscares.allowed(c.player(), false),
                c -> Jumpscares.fakeCrash(c.player(), false));
        EventRegistry.add("fake_title", EventRarity.VERY_RARE, 7, 7, 1800, c -> Jumpscares.allowed(c.player(), false),
                c -> Jumpscares.fakeTitle(c.player(), false));
        EventRegistry.add("glitch_world", EventRarity.RARE, 7, 7, 600, c -> true, c -> {
            Map<BlockPos, BlockState> m = new HashMap<>();
            BlockPos o = c.player().getBlockPos().down();
            for (int i = 0; i < 40; i++) {
                BlockPos p = o.add(Rand.range(-6, 6), Rand.range(-1, 1), Rand.range(-6, 6));
                BlockState s = c.world().getBlockState(p);
                if (s.isAir() || !s.getFluidState().isEmpty() || c.world().getBlockEntity(p) != null) continue;
                m.put(p, Rand.pick(Blocks.AIR.getDefaultState(), Blocks.NETHERRACK.getDefaultState(), Blocks.PURPLE_WOOL.getDefaultState(), Blocks.BLACK_CONCRETE.getDefaultState()));
            }
            IllusionManager.show(c.player(), m, 60, 0);
            Fx.send(c.player(), FxPayload.GLITCH, 60, 0.8f);
            Fx.send(c.player(), FxPayload.STATIC, 40, 0.5f);
            Sfx.at(c.player(), ModSounds.GLITCH, c.player().getPos(), 0.6f, 1.0f, true);
        });
    }
}
