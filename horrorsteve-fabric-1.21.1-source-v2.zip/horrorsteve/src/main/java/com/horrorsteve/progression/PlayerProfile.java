package com.horrorsteve.progression;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtString;

import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** Everything the entity knows about one player. Saved with the world. */
public class PlayerProfile {
    public static final int HISTORY = 12;

    public final UUID id;
    public String name = "";
    private final long[] stats = new long[Stat.values().length];
    private final double[] traits = new double[Trait.values().length];
    public double fear = 0;
    public double score = 0;
    public int stage = 1;
    public boolean unknownUnlocked = false;
    public int endings = 0;
    public final Set<String> flags = new HashSet<>();
    public long lastSeenMs = 0;
    public String lastDeathCause = "";
    public String lastDeathDim = "";
    public long lastDeathPos = 0;
    public final ArrayDeque<String> chatHistory = new ArrayDeque<>();
    public final ArrayDeque<String> categoryHistory = new ArrayDeque<>();

    public PlayerProfile(UUID id) {
        this.id = id;
    }

    public long get(Stat s) {
        return stats[s.ordinal()];
    }

    public void add(Stat s, long n) {
        stats[s.ordinal()] += n;
    }

    public void inc(Stat s) {
        stats[s.ordinal()]++;
    }

    public void set(Stat s, long v) {
        stats[s.ordinal()] = v;
    }

    public double trait(Trait t) {
        return traits[t.ordinal()];
    }

    public void bump(Trait t, double amount) {
        traits[t.ordinal()] = Math.max(0, Math.min(100, traits[t.ordinal()] + amount));
    }

    public Trait dominantTrait() {
        Trait best = null;
        double v = 4;
        for (Trait t : Trait.values()) {
            if (traits[t.ordinal()] > v) {
                v = traits[t.ordinal()];
                best = t;
            }
        }
        return best;
    }

    public boolean flag(String f) {
        return flags.contains(f);
    }

    public void setFlag(String f) {
        flags.add(f);
    }

    public boolean hasEnding(int bit) {
        return (endings & (1 << bit)) != 0;
    }

    public void remember(String chat, String category) {
        chatHistory.addLast(chat.length() > 80 ? chat.substring(0, 80) : chat);
        categoryHistory.addLast(category);
        while (chatHistory.size() > HISTORY) chatHistory.removeFirst();
        while (categoryHistory.size() > HISTORY) categoryHistory.removeFirst();
    }

    public NbtCompound toNbt() {
        NbtCompound n = new NbtCompound();
        n.putString("name", name);
        NbtCompound st = new NbtCompound();
        for (Stat s : Stat.values()) st.putLong(s.name(), stats[s.ordinal()]);
        n.put("stats", st);
        NbtCompound tr = new NbtCompound();
        for (Trait t : Trait.values()) tr.putDouble(t.name(), traits[t.ordinal()]);
        n.put("traits", tr);
        n.putDouble("fear", fear);
        n.putDouble("score", score);
        n.putInt("stage", stage);
        n.putBoolean("unknown", unknownUnlocked);
        n.putInt("endings", endings);
        n.putLong("lastSeen", lastSeenMs);
        n.putString("deathCause", lastDeathCause);
        n.putString("deathDim", lastDeathDim);
        n.putLong("deathPos", lastDeathPos);
        NbtList fl = new NbtList();
        for (String f : flags) fl.add(NbtString.of(f));
        n.put("flags", fl);
        NbtList ch = new NbtList();
        for (String c : chatHistory) ch.add(NbtString.of(c));
        n.put("chat", ch);
        NbtList cat = new NbtList();
        for (String c : categoryHistory) cat.add(NbtString.of(c));
        n.put("cats", cat);
        return n;
    }

    public static PlayerProfile fromNbt(UUID id, NbtCompound n) {
        PlayerProfile p = new PlayerProfile(id);
        p.name = n.getString("name");
        NbtCompound st = n.getCompound("stats");
        for (Stat s : Stat.values()) if (st.contains(s.name())) p.stats[s.ordinal()] = st.getLong(s.name());
        NbtCompound tr = n.getCompound("traits");
        for (Trait t : Trait.values()) if (tr.contains(t.name())) p.traits[t.ordinal()] = tr.getDouble(t.name());
        p.fear = n.getDouble("fear");
        p.score = n.getDouble("score");
        p.stage = Math.max(1, n.getInt("stage"));
        p.unknownUnlocked = n.getBoolean("unknown");
        p.endings = n.getInt("endings");
        p.lastSeenMs = n.getLong("lastSeen");
        p.lastDeathCause = n.getString("deathCause");
        p.lastDeathDim = n.getString("deathDim");
        p.lastDeathPos = n.getLong("deathPos");
        NbtList fl = n.getList("flags", NbtElement.STRING_TYPE);
        for (int i = 0; i < fl.size(); i++) p.flags.add(fl.getString(i));
        NbtList ch = n.getList("chat", NbtElement.STRING_TYPE);
        for (int i = 0; i < ch.size(); i++) p.chatHistory.addLast(ch.getString(i));
        NbtList cat = n.getList("cats", NbtElement.STRING_TYPE);
        for (int i = 0; i < cat.size(); i++) p.categoryHistory.addLast(cat.getString(i));
        return p;
    }

    public void resetAll() {
        java.util.Arrays.fill(stats, 0);
        java.util.Arrays.fill(traits, 0);
        fear = 0;
        score = 0;
        stage = 1;
        unknownUnlocked = false;
        endings = 0;
        flags.clear();
        chatHistory.clear();
        categoryHistory.clear();
        lastDeathCause = "";
    }
}
