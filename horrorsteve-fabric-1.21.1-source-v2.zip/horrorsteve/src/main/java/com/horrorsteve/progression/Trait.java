package com.horrorsteve.progression;

public enum Trait {
    CURIOUS, AGGRESSIVE, FEARFUL, EXPLORATIVE, AVOIDANT, CONFRONTATIONAL
}
