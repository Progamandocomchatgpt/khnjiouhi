package com.horrorsteve.progression;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.PersistentState;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** World-saved storage of every player's profile (data/horrorsteve_profiles.dat). */
public class ProfileState extends PersistentState {
    public static final PersistentState.Type<ProfileState> TYPE =
            new PersistentState.Type<>(ProfileState::new, ProfileState::fromNbt, null);

    private final Map<UUID, PlayerProfile> profiles = new HashMap<>();

    public static ProfileState get(MinecraftServer server) {
        return server.getOverworld().getPersistentStateManager().getOrCreate(TYPE, "horrorsteve_profiles");
    }

    public PlayerProfile profile(UUID id) {
        return profiles.computeIfAbsent(id, PlayerProfile::new);
    }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registryLookup) {
        NbtCompound all = new NbtCompound();
        for (Map.Entry<UUID, PlayerProfile> e : profiles.entrySet()) {
            all.put(e.getKey().toString(), e.getValue().toNbt());
        }
        nbt.put("profiles", all);
        return nbt;
    }

    public static ProfileState fromNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup registryLookup) {
        ProfileState s = new ProfileState();
        NbtCompound all = nbt.getCompound("profiles");
        for (String key : all.getKeys()) {
            try {
                UUID id = UUID.fromString(key);
                s.profiles.put(id, PlayerProfile.fromNbt(id, all.getCompound(key)));
            } catch (IllegalArgumentException ignored) {
            }
        }
        return s;
    }
}
