package com.horrorsteve.progression;

import com.horrorsteve.config.HorrorConfig;

/** Turns hidden counters into one of eight stages. The player is never told how. */
public final class StageManager {
    /** Score needed for stage 2..7 (stage 1 starts at 0). Stage 8 is never reached by score alone. */
    private static final double[] THRESHOLDS = {10, 35, 80, 150, 250, 400};

    private StageManager() {}

    public static double computeScore(PlayerProfile p) {
        double minutes = p.get(Stat.TICKS_IN_WORLD) / (20.0 * 60.0);
        double s = minutes * 0.5
                + p.get(Stat.ENCOUNTERS) * 3
                + p.get(Stat.FACE_SECONDS) * 0.3
                + p.get(Stat.LOOK_SECONDS) * 0.1
                + p.get(Stat.CONVERSATIONS) * 2
                + p.get(Stat.DEATHS) * 4
                + p.get(Stat.ESCAPES) * 3
                + p.get(Stat.ATTACKS) * 2
                + p.get(Stat.NIGHTS) * 6
                + p.get(Stat.SLEEPS) * 2
                + p.get(Stat.STRUCTURES_VISITED) * 4
                + p.get(Stat.UNDERGROUND_SECONDS) / 60.0 * 0.2
                + p.get(Stat.SIGNS_READ) * 2
                + p.get(Stat.MEME67)
                + p.get(Stat.INSTRUCTIONS_FOLLOWED) * 1.5
                + p.get(Stat.IGNORED) * 0.5;
        return s * HorrorConfig.get().progressionSpeed;
    }

    /** Recomputes the stored stage (1..7). Never goes down on its own. */
    public static void update(PlayerProfile p) {
        p.score = Math.max(p.score, computeScore(p));
        int st = 1;
        for (int i = 0; i < THRESHOLDS.length; i++) {
            if (p.score >= THRESHOLDS[i]) st = i + 2;
        }
        if (st > p.stage) p.stage = st;
    }

    public static double thresholdFor(int stage) {
        if (stage <= 1) return 0;
        if (stage > 7) return THRESHOLDS[THRESHOLDS.length - 1];
        return THRESHOLDS[stage - 2];
    }

    /** Stage the entity actually behaves at right now. */
    public static int effective(PlayerProfile p, boolean unknownWindowOpen) {
        int st = Math.min(7, p.stage);
        if (p.flag("ending_peace")) st = Math.min(st, 2);
        if (p.flag("ending_true")) st = Math.min(st, 1);
        if (unknownWindowOpen && p.unknownUnlocked) return 8;
        return st;
    }
}
