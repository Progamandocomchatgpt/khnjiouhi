package com.horrorsteve.ai;

import com.horrorsteve.entity.HorrorSteveEntity;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

/** Works out how a player is looking at the entity: away / peripheral / near / direct, face vs body, through glass, far away. */
public final class EyeContact {
    public enum Type { AWAY, PERIPHERAL, NEAR, DIRECT }

    public enum Sight { CLEAR, GLASS, BLOCKED }

    public record Look(Type type, boolean visible, boolean face, boolean glass, double dist, double dot) {
        public static final Look NONE = new Look(Type.AWAY, false, false, false, 999, -1);

        /** True when the player is actually looking at it (direct or near, with a line of sight). */
        public boolean seen() {
            return visible && (type == Type.NEAR || type == Type.DIRECT);
        }

        public boolean far() {
            return dist > 64;
        }
    }

    private EyeContact() {}

    public static Look evaluate(ServerPlayerEntity p, HorrorSteveEntity e) {
        Vec3d eye = p.getEyePos();
        Vec3d head = e.getEyePos();
        Vec3d to = head.subtract(eye);
        double dist = to.length();
        if (dist < 0.2) return new Look(Type.DIRECT, true, true, false, dist, 1);
        Vec3d look = p.getRotationVec(1.0F);
        double dot = look.dotProduct(to.normalize());
        double direct = dist > 40 ? 0.995 : 0.985;
        double near = dist > 40 ? 0.975 : 0.93;
        Type type = dot >= direct ? Type.DIRECT : dot >= near ? Type.NEAR : dot >= 0.6 ? Type.PERIPHERAL : Type.AWAY;
        boolean visible = false;
        boolean glass = false;
        if (type != Type.AWAY) {
            Sight s = sight(p.getWorld(), eye, head, p);
            visible = s != Sight.BLOCKED;
            glass = s == Sight.GLASS;
        }
        boolean face = false;
        if (visible && (type == Type.DIRECT || type == Type.NEAR)) {
            Box headBox = new Box(head.x - 0.32, head.y - 0.32, head.z - 0.32, head.x + 0.32, head.y + 0.32, head.z + 0.32);
            face = headBox.raycast(eye, eye.add(look.multiply(dist + 1.0))).isPresent();
        }
        return new Look(type, visible, face, glass, dist, dot);
    }

    /** Raycast that treats glass as see-through (but reports it). */
    public static Sight sight(World w, Vec3d from, Vec3d to, Entity ctx) {
        Vec3d start = from;
        boolean glass = false;
        for (int i = 0; i < 4; i++) {
            BlockHitResult hit = w.raycast(new RaycastContext(start, to, RaycastContext.ShapeType.COLLIDER,
                    RaycastContext.FluidHandling.NONE, ctx));
            if (hit.getType() == HitResult.Type.MISS) return glass ? Sight.GLASS : Sight.CLEAR;
            BlockState bs = w.getBlockState(hit.getBlockPos());
            if (isGlass(bs)) {
                glass = true;
                Vec3d dir = to.subtract(start).normalize();
                start = hit.getPos().add(dir.multiply(0.05));
                continue;
            }
            return Sight.BLOCKED;
        }
        return Sight.BLOCKED;
    }

    public static boolean clearSight(World w, Vec3d from, Vec3d to, Entity ctx) {
        return sight(w, from, to, ctx) != Sight.BLOCKED;
    }

    public static boolean isGlass(BlockState bs) {
        return Registries.BLOCK.getId(bs.getBlock()).getPath().contains("glass");
    }
}
