package com.horrorsteve.ai;

import com.horrorsteve.util.Geo;
import com.horrorsteve.util.Rand;
import net.minecraft.block.BlockState;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;

/** Finds believable (and impossible) places for the entity to stand. Never generates chunks. */
public final class SpawnLocator {
    public enum Strategy { FAR_OPEN, ROOFTOP, WINDOW, CAVE, BEHIND, FRONT, SKY, NEAR }

    private SpawnLocator() {}

    /** Picks the best strategy for where the player currently is. */
    public static Strategy defaultFor(ServerWorld w, ServerPlayerEntity p, int stage) {
        boolean underground = !w.isSkyVisible(p.getBlockPos()) && w.getRegistryKey() == net.minecraft.world.World.OVERWORLD;
        if (w.getDimension().hasCeiling() || underground) {
            return Rand.chance(0.7) ? Strategy.CAVE : (stage >= 3 ? Strategy.BEHIND : Strategy.CAVE);
        }
        double r = Rand.r().nextDouble();
        if (stage >= 4 && r < 0.15) return Strategy.SKY;
        if (r < 0.45) return Strategy.FAR_OPEN;
        if (r < 0.65) return Strategy.ROOFTOP;
        if (r < 0.85) return Strategy.WINDOW;
        return stage >= 3 ? Strategy.BEHIND : Strategy.FAR_OPEN;
    }

    public static Vec3d find(ServerWorld w, ServerPlayerEntity p, Strategy s) {
        Vec3d pp = p.getPos();
        for (int attempt = 0; attempt < 14; attempt++) {
            Vec3d v = switch (s) {
                case FAR_OPEN -> ring(w, p, 36, 62, 0, 360, true);
                case ROOFTOP -> rooftop(w, p);
                case WINDOW -> ring(w, p, 4, 9, 0, 360, false);
                case CAVE -> ring(w, p, 8, 22, 0, 360, false);
                case BEHIND -> ring(w, p, 5, 9, 180, 70, false);
                case FRONT -> ring(w, p, 10, 22, 0, 30, false);
                case SKY -> sky(p);
                case NEAR -> ring(w, p, 12, 26, 0, 360, false);
            };
            if (v != null) return v;
        }
        return null;
    }

    /** A point on a ring around the player. biasDeg is relative to the player's facing; spreadDeg is the total arc. */
    public static Vec3d ring(ServerWorld w, ServerPlayerEntity p, double min, double max, double biasDeg, double spreadDeg, boolean surfaceOnly) {
        double ang = Math.toRadians(p.getYaw() + biasDeg + (Rand.r().nextDouble() - 0.5) * spreadDeg);
        double d = Rand.range(min, max);
        double x = p.getX() + (-Math.sin(ang)) * d;
        double z = p.getZ() + Math.cos(ang) * d;
        int bx = (int) Math.floor(x);
        int bz = (int) Math.floor(z);
        boolean underground = !w.isSkyVisible(p.getBlockPos());
        if (surfaceOnly && !w.getDimension().hasCeiling() && !underground) {
            if (!loaded(w, bx, bz)) return null;
            int top = w.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, bx, bz);
            return ground(w, bx, bz, top, 4, 8);
        }
        return ground(w, bx, bz, p.getBlockY(), 6, 12);
    }

    private static Vec3d rooftop(ServerWorld w, ServerPlayerEntity p) {
        if (w.getDimension().hasCeiling()) return null;
        int bestY = Integer.MIN_VALUE;
        int bx = 0, bz = 0;
        for (int i = 0; i < 14; i++) {
            double ang = Rand.range(0, Math.PI * 2);
            double d = Rand.range(6, 22);
            int x = (int) Math.floor(p.getX() + Math.cos(ang) * d);
            int z = (int) Math.floor(p.getZ() + Math.sin(ang) * d);
            if (!loaded(w, x, z)) continue;
            int top = w.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z);
            if (top > bestY) {
                bestY = top;
                bx = x;
                bz = z;
            }
        }
        if (bestY == Integer.MIN_VALUE || bestY < p.getBlockY() + 2) return null;
        return ground(w, bx, bz, bestY, 2, 3);
    }

    private static Vec3d sky(ServerPlayerEntity p) {
        double ang = Rand.range(0, Math.PI * 2);
        double d = Rand.range(10, 25);
        return new Vec3d(p.getX() + Math.cos(ang) * d, p.getY() + Rand.range(14, 24), p.getZ() + Math.sin(ang) * d);
    }

    public static boolean loaded(ServerWorld w, int bx, int bz) {
        return w.getChunkManager().isChunkLoaded(bx >> 4, bz >> 4);
    }

    /** Finds a standing spot (solid floor, two empty blocks) in a column near refY. */
    public static Vec3d ground(ServerWorld w, int x, int z, int refY, int up, int down) {
        if (!loaded(w, x, z)) return null;
        int minY = w.getBottomY() + 1;
        int maxY = w.getTopY() - 2;
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int y = Math.min(maxY, refY + up); y >= Math.max(minY, refY - down); y--) {
            m.set(x, y - 1, z);
            BlockState below = w.getBlockState(m);
            if (below.getCollisionShape(w, m).isEmpty() || !below.getFluidState().isEmpty()) continue;
            m.set(x, y, z);
            BlockState feet = w.getBlockState(m);
            if (!feet.getCollisionShape(w, m).isEmpty() || !feet.getFluidState().isEmpty()) continue;
            m.set(x, y + 1, z);
            BlockState head = w.getBlockState(m);
            if (!head.getCollisionShape(w, m).isEmpty() || !head.getFluidState().isEmpty()) continue;
            return new Vec3d(x + 0.5, y, z + 0.5);
        }
        return null;
    }

    /** A spot within [min,max] blocks of the player around the given world position (any direction). */
    public static Vec3d around(ServerWorld w, Vec3d center, double min, double max, int refY) {
        for (int i = 0; i < 10; i++) {
            double ang = Rand.range(0, Math.PI * 2);
            double d = Rand.range(min, max);
            int x = (int) Math.floor(center.x + Math.cos(ang) * d);
            int z = (int) Math.floor(center.z + Math.sin(ang) * d);
            Vec3d v = ground(w, x, z, refY, 5, 8);
            if (v != null) return v;
        }
        return null;
    }

    public static Vec3d behind(ServerWorld w, ServerPlayerEntity p, double min, double max) {
        for (int i = 0; i < 10; i++) {
            Vec3d v = ring(w, p, min, max, 180, 60, false);
            if (v != null) return v;
        }
        return null;
    }

    public static float yawToPlayer(Vec3d from, ServerPlayerEntity p) {
        return Geo.yawTo(from, p.getPos());
    }
}
