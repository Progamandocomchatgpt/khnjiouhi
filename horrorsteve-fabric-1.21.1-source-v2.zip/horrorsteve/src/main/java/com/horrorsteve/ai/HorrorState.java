package com.horrorsteve.ai;

public enum HorrorState {
    IDLE,
    WATCHING,
    FOLLOWING,
    HIDING,
    FLEEING,
    OBSERVING,
    MANIPULATING,
    HUNTING,
    ATTACKING,
    TELEPORTING,
    DISAPPEARING,
    PRETENDING,
    PERFORMING_EVENT,
    PERFORMING_67
}
