package com.horrorsteve.ai;

import com.horrorsteve.ai.EyeContact.Look;
import com.horrorsteve.config.HorrorConfig;
import com.horrorsteve.dialogue.DialogueEngine;
import com.horrorsteve.entity.HorrorSteveEntity;
import com.horrorsteve.fear.FearTracker;
import com.horrorsteve.progression.PlayerProfile;
import com.horrorsteve.progression.Stat;
import com.horrorsteve.progression.Trait;
import com.horrorsteve.server.Advancements;
import com.horrorsteve.server.Fx;
import com.horrorsteve.server.HorrorDirector;
import com.horrorsteve.server.Messenger;
import com.horrorsteve.server.PlayerSession;
import com.horrorsteve.server.Sfx;
import com.horrorsteve.sound.ModSounds;
import com.horrorsteve.util.Geo;
import com.horrorsteve.util.Rand;
import com.horrorsteve.util.Scheduler;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/**
 * Server-side hsBrain of every Horror Steve entity. A weighted state machine for the MAIN role plus small scripts for
 * DECOY and FAKE_PLAYER. Heavy work (eye contact raycasts, pathing, decisions) is throttled to a few ticks.
 */
public class HorrorBrain {
    public enum DecoyMode { STARE, RUSH, BEHIND }

    private record W(HorrorState s, double w) {}

    private final HorrorSteveEntity e;

    public HorrorState state = HorrorState.IDLE;
    private HorrorState resume = HorrorState.WATCHING;
    private int stateAge = 0;
    private int stateLen = 100;

    private int interruptTicks = 0;
    private Runnable interruptEnd;

    private Look look = Look.NONE;
    private int seenTicks = 0;
    private int faceTicks = 0;
    private int unseenNear = 0;
    private int distortRemaining = 0;
    private int distortCd = 60;
    private int tpCd = 100;
    private int attackCd = 0;
    private int hits = 0;
    private int flyTicks = 0;
    private int lostTicks = 0;
    private boolean encounterCounted = false;

    private Vec3d orbit;
    private Vec3d hideSpot;
    private float awayYaw;

    // decoy
    public DecoyMode decoyMode = DecoyMode.STARE;
    // fake player
    public String fakeName = "Steve";
    private int fakeVariant = -1;
    private int fakePhase = 0;
    private int fakeTimer = 0;
    private int pretendLen = 600;

    public HorrorBrain(HorrorSteveEntity e) {
        this.e = e;
    }

    // ---------------------------------------------------------------- main tick

    public void tick(ServerWorld w) {
        ServerPlayerEntity t = e.resolveTarget();
        if (t == null) {
            if (++lostTicks > 200) e.discard();
            return;
        }
        lostTicks = 0;
        PlayerProfile prof = HorrorDirector.profile(t);
        PlayerSession sess = HorrorDirector.session(t);
        int stage = HorrorDirector.effectiveStage(t);
        if (e.age % 20 == 0) e.setStageValue(stage);
        double dist = e.distanceTo(t);
        stateAge++;
        if (tpCd > 0) tpCd--;
        if (attackCd > 0) attackCd--;

        int role = e.getRole();
        if (role == HorrorSteveEntity.ROLE_DECOY) {
            decoyTick(w, t, dist);
            return;
        }
        if (role == HorrorSteveEntity.ROLE_FAKE_PLAYER) {
            fakePlayerTick(w, t, prof, dist);
            return;
        }

        if (interruptTicks > 0) {
            interruptTicks--;
            e.faceToward(t.getPos());
            e.lookAt(t.getEyePos());
            if (interruptTicks == 0) endInterrupt();
            return;
        }

        if (e.age % 3 == 0) look = EyeContact.evaluate(t, e);
        trackLooking(w, t, prof, sess, stage, dist);
        distortion(prof, stage, dist);

        if (e.age > e.lifespan && state != HorrorState.HUNTING && state != HorrorState.ATTACKING
                && state != HorrorState.DISAPPEARING) {
            enter(HorrorState.DISAPPEARING, stage);
        }

        switch (state) {
            case IDLE -> idle(t, stage);
            case WATCHING -> watching(w, t, stage, dist);
            case OBSERVING -> observing(w, t, stage, dist);
            case FOLLOWING -> following(w, t, stage, dist);
            case HIDING -> hiding(w, t, stage, dist);
            case FLEEING -> fleeing(t, stage);
            case MANIPULATING -> manipulating(t, stage);
            case HUNTING -> hunting(w, t, prof, sess, stage, dist);
            case ATTACKING -> attacking(w, t, prof, stage, dist);
            case TELEPORTING -> teleporting(w, t, stage);
            case DISAPPEARING -> disappearing(w);
            case PRETENDING -> pretendTick(w, t, prof, dist, true);
            case PERFORMING_EVENT, PERFORMING_67 -> {
                e.faceToward(t.getPos());
                if (stateAge > 400) enter(HorrorState.WATCHING, stage);
            }
        }
    }

    // ---------------------------------------------------------------- interrupts (used by the 67 event and scripted scenes)

    public void interrupt(HorrorState s, int ticks, Runnable onEnd) {
        this.state = s;
        this.interruptTicks = Math.max(1, ticks);
        this.interruptEnd = onEnd;
        e.getNavigation().stop();
        e.setVelocity(Vec3d.ZERO);
        clearPose();
    }

    private void endInterrupt() {
        Runnable r = interruptEnd;
        interruptEnd = null;
        enter(HorrorState.WATCHING, HorrorDirector.effectiveStage(e.resolveTarget()));
        if (r != null) r.run();
    }

    public boolean isInterrupted() {
        return interruptTicks > 0;
    }

    public void forceState(HorrorState s) {
        enter(s, e.getStageValue());
    }

    // ---------------------------------------------------------------- state entry

    private void clearPose() {
        e.setHsFlag(HorrorSteveEntity.F_FROZEN, false);
        e.setHsFlag(HorrorSteveEntity.F_FLOAT, false);
        e.setHsFlag(HorrorSteveEntity.F_NO_LIMBS, false);
        e.setHsFlag(HorrorSteveEntity.F_BROKEN_WALK, false);
        e.setHsFlag(HorrorSteveEntity.F_ARMS_WRONG, false);
        e.setHsFlag(HorrorSteveEntity.F_BACKWARD, false);
        e.setHsFlag(HorrorSteveEntity.F_TWITCH, false);
        e.setHsFlag(HorrorSteveEntity.F_TPOSE, false);
        e.unlockBody();
        e.releaseHead();
        if (e.isNoGravity()) e.setNoGravity(false);
        e.noClip = false;
        e.setAnim(HorrorSteveEntity.ANIM_NONE);
    }

    public void enter(HorrorState s, int stage) {
        if (s != HorrorState.TELEPORTING) resume = (state == HorrorState.TELEPORTING || state == HorrorState.DISAPPEARING) ? resume : state;
        if (state == HorrorState.HUNTING && s != HorrorState.ATTACKING) flyTicks = 0;
        state = s;
        stateAge = 0;
        if (s != HorrorState.PRETENDING) clearPose();
        switch (s) {
            case IDLE -> {
                stateLen = Rand.range(60, 200);
                e.getNavigation().stop();
            }
            case WATCHING -> {
                stateLen = Rand.range(100, 320);
                e.getNavigation().stop();
                awayYaw = Geo.yawTo(e.getPos(), e.resolveTarget() != null ? e.resolveTarget().getPos() : e.getPos())
                        + (Rand.chance(0.5) ? 1 : -1) * Rand.range(70, 160);
                rollStationaryAbnormality(stage);
            }
            case OBSERVING -> {
                stateLen = Rand.range(200, 420);
                orbit = null;
                rollMovementAbnormality(stage);
            }
            case FOLLOWING -> {
                stateLen = Rand.range(500, 1000);
                rollMovementAbnormality(stage);
            }
            case HIDING -> {
                stateLen = Rand.range(160, 360);
                hideSpot = null;
            }
            case FLEEING -> stateLen = 50;
            case MANIPULATING -> {
                stateLen = 110;
                e.getNavigation().stop();
            }
            case HUNTING -> {
                stateLen = 20 * Rand.range(30, 60);
                hits = 0;
                HorrorDirector.onChaseStart(e.resolveTarget());
            }
            case ATTACKING -> {
                stateLen = 120;
                hits = 0;
            }
            case TELEPORTING -> stateLen = 4;
            case DISAPPEARING -> stateLen = 2;
            case PRETENDING -> {
                stateLen = 1200;
                fakePhase = 0;
                fakeTimer = 0;
                pretendLen = Rand.range(300, 700);
                fakeName = HorrorDirector.randomFakeName();
                e.setCustomName(net.minecraft.text.Text.literal(fakeName));
                e.setCustomNameVisible(true);
            }
            default -> stateLen = 200;
        }
    }

    private void rollStationaryAbnormality(int stage) {
        if (stage >= 2 && Rand.chance(0.35)) {
            e.lockBody(awayYaw);
        }
        if (stage >= 3 && Rand.chance(0.15)) e.setHsFlag(HorrorSteveEntity.F_TWITCH, true);
        if (stage >= 4 && Rand.chance(0.10)) {
            e.setHsFlag(HorrorSteveEntity.F_FLOAT, true);
            e.setNoGravity(true);
            e.teleportTo(e.getX(), e.getY() + 1.2, e.getZ());
        }
        if (stage >= 5 && Rand.chance(0.05)) e.setHsFlag(HorrorSteveEntity.F_TPOSE, true);
        if (stage >= 2 && Rand.chance(0.12)) e.setHsFlag(HorrorSteveEntity.F_ARMS_WRONG, true);
    }

    private void rollMovementAbnormality(int stage) {
        if (stage >= 2 && Rand.chance(0.25)) e.setHsFlag(HorrorSteveEntity.F_BROKEN_WALK, true);
        if (stage >= 3 && Rand.chance(0.18)) e.setHsFlag(HorrorSteveEntity.F_NO_LIMBS, true);
        if (stage >= 3 && Rand.chance(0.20)) e.setHsFlag(HorrorSteveEntity.F_ARMS_WRONG, true);
        if (stage >= 3 && Rand.chance(0.15)) {
            ServerPlayerEntity t = e.resolveTarget();
            if (t != null) {
                e.lockBody(Geo.yawTo(e.getPos(), t.getPos()));
                e.setHsFlag(HorrorSteveEntity.F_BACKWARD, true);
            }
        }
    }

    // ---------------------------------------------------------------- looking / distortion

    private void trackLooking(ServerWorld w, ServerPlayerEntity t, PlayerProfile prof, PlayerSession sess, int stage, double dist) {
        if (look.seen()) {
            seenTicks++;
            unseenNear = 0;
            sess.lastSeenEntityTick = Scheduler.now();
            if (look.face()) faceTicks++;
            else faceTicks = Math.max(0, faceTicks - 1);
            if (!encounterCounted) {
                encounterCounted = true;
                if (Scheduler.now() - sess.lastEncounterTick > 20 * 150) {
                    prof.inc(Stat.ENCOUNTERS);
                    sess.lastEncounterTick = Scheduler.now();
                    Advancements.grant(t, "first_encounter");
                    FearTracker.spike(prof, 4);
                }
            }
        } else {
            seenTicks = Math.max(0, seenTicks - 2);
            faceTicks = Math.max(0, faceTicks - 2);
            if (dist < 28 && look.type() == EyeContact.Type.AWAY) {
                if (++unseenNear >= 600) {
                    unseenNear = 0;
                    prof.inc(Stat.IGNORED);
                    prof.bump(Trait.AVOIDANT, 1.5);
                }
            }
        }
        if (e.age % 20 == 0) {
            if (seenTicks > 0) prof.inc(Stat.LOOK_SECONDS);
            if (faceTicks > 0) prof.inc(Stat.FACE_SECONDS);
            if (look.glass() && look.seen()) prof.inc(Stat.GLASS_LOOKS);
        }
        if (faceTicks == 40) Advancements.grant(t, "eye_contact");
        if (faceTicks == 120) {
            prof.bump(Trait.CURIOUS, 1.0);
            Advancements.grant(t, "dont_look");
        }
        if (seenTicks == 60 && stage >= 2) Advancements.grant(t, "it_saw_you");
    }

    private record V(int id, int minStage, double w, int minDur, int maxDur) {}

    private static final List<V> VARIANTS = List.of(
            new V(HorrorSteveEntity.D_SHAKE, 1, 12, 6, 14),
            new V(HorrorSteveEntity.D_TILT, 1, 8, 20, 50),
            new V(HorrorSteveEntity.D_FLICKER, 2, 10, 6, 14),
            new V(HorrorSteveEntity.D_SQUASH, 2, 5, 8, 20),
            new V(HorrorSteveEntity.D_STRETCH, 3, 8, 10, 30),
            new V(HorrorSteveEntity.D_BIG, 3, 6, 10, 30),
            new V(HorrorSteveEntity.D_TINY, 3, 6, 10, 30),
            new V(HorrorSteveEntity.D_SPIN, 3, 6, 8, 24),
            new V(HorrorSteveEntity.D_DARK, 3, 6, 30, 80),
            new V(HorrorSteveEntity.D_SMILE, 4, 5, 20, 70),
            new V(HorrorSteveEntity.D_BLANK, 4, 3, 20, 60),
            new V(HorrorSteveEntity.D_VANISH, 4, 3, 4, 8),
            new V(HorrorSteveEntity.D_EYES, 5, 2, 30, 90),
            new V(HorrorSteveEntity.D_LONGNECK, 5, 3, 10, 30),
            new V(HorrorSteveEntity.D_UNKNOWN, 8, 25, 40, 100));

    private void distortion(PlayerProfile prof, int stage, double dist) {
        if (distortRemaining > 0) {
            if (--distortRemaining == 0) e.setDistort(HorrorSteveEntity.D_NONE);
        }
        if (distortCd > 0) distortCd--;
        if (!HorrorConfig.get().visualDistortion || HorrorConfig.get().horrorIntensity <= 0.05) return;
        if (!look.face() || distortRemaining > 0 || distortCd > 0) return;
        if (faceTicks < 20 || faceTicks % 20 != 0) return;
        double fear = prof.fear / 100.0;
        double distFactor = dist < 6 ? 1.2 : dist < 20 ? 1.0 : 0.5;
        double p = (0.20 + 0.07 * stage + Math.min(0.15, prof.get(Stat.ENCOUNTERS) * 0.01)) * (0.5 + fear)
                * distFactor * HorrorConfig.get().horrorIntensity;
        if (!Rand.chance(p)) return;
        final int st = stage;
        V v = Rand.weighted(VARIANTS, x -> (st >= x.minStage() && (x.id() != HorrorSteveEntity.D_UNKNOWN || st >= 8))
                ? x.w() * (x.w() < 5 ? (0.3 + fear) : 1.0) : 0);
        if (v == null) return;
        e.setDistort(v.id());
        distortRemaining = Rand.range(v.minDur(), v.maxDur());
        distortCd = Rand.range(100, 400);
        ServerPlayerEntity t = e.resolveTarget();
        if (t != null) {
            FearTracker.spike(prof, v.w() < 5 ? 5 : 2);
            if (v.w() < 5 && Rand.chance(0.5)) Sfx.at(t, ModSounds.DISTORT, e.getPos(), 0.35f, Rand.range(0.8f, 1.2f), true);
        }
    }

    // ---------------------------------------------------------------- decisions

    private void pickNext(ServerPlayerEntity t, int stage) {
        PlayerProfile prof = HorrorDirector.profile(t);
        PlayerSession sess = HorrorDirector.session(t);
        double avoid = 1 + prof.trait(Trait.AVOIDANT) / 60.0;
        double aggr = 1 + prof.trait(Trait.AGGRESSIVE) / 50.0;
        double curious = 1 + prof.trait(Trait.CURIOUS) / 60.0;
        boolean peaceful = prof.flag("ending_peace");
        boolean chaseOk = !peaceful && stage >= 4 && HorrorConfig.get().horrorIntensity > 0.2
                && Scheduler.now() - sess.lastChaseTick > 20 * (stage >= 6 ? 60 : 150);
        List<W> list = new ArrayList<>();
        list.add(new W(HorrorState.IDLE, Math.max(6, 26 - stage * 2)));
        list.add(new W(HorrorState.WATCHING, 40));
        if (stage >= 2) {
            list.add(new W(HorrorState.OBSERVING, 18));
            list.add(new W(HorrorState.FOLLOWING, 12 * avoid));
            list.add(new W(HorrorState.HIDING, 12));
            list.add(new W(HorrorState.MANIPULATING, 8 * curious));
        }
        if (stage >= 3) {
            list.add(new W(HorrorState.TELEPORTING, 8));
            list.add(new W(HorrorState.PRETENDING, 5));
        }
        if (stage >= 4) {
            list.add(new W(HorrorState.FOLLOWING, 8 * avoid));
            list.add(new W(HorrorState.MANIPULATING, 6 * curious));
        }
        if (chaseOk) list.add(new W(HorrorState.HUNTING, (6 + stage * 2.5) * aggr * HorrorConfig.get().horrorIntensity));
        list.add(new W(HorrorState.DISAPPEARING, stage <= 2 ? 8 : 3));
        W pick = Rand.weighted(list, W::w);
        HorrorState next = pick == null ? HorrorState.WATCHING : pick.s();
        if (next == state && next != HorrorState.WATCHING) next = HorrorState.WATCHING;
        enter(next, stage);
    }

    // ---------------------------------------------------------------- states

    private void idle(ServerPlayerEntity t, int stage) {
        if (stateAge >= stateLen) pickNext(t, stage);
    }

    private void watching(ServerWorld w, ServerPlayerEntity t, int stage, double dist) {
        e.lookAt(t.getEyePos());
        if (!e.hasHsFlag(HorrorSteveEntity.F_BODY_LOCK)) {
            e.faceToward(t.getPos());
            e.setHsFlag(HorrorSteveEntity.F_HEAD_LOCK, stage >= 2);
        }
        if (stage >= 2 && look.seen() && Rand.chance(0.02)) e.setHsFlag(HorrorSteveEntity.F_FROZEN, true);
        double vanish = stage <= 1 ? 14 : stage == 2 ? 9 : stage == 3 ? 6 : 4;
        if (dist < vanish) {
            if (stage <= 2) enter(HorrorState.DISAPPEARING, stage);
            else if (stage == 3) enter(HorrorState.TELEPORTING, stage);
            else if (Rand.chance(0.5)) enter(HorrorState.FLEEING, stage);
            else enter(HorrorState.TELEPORTING, stage);
            return;
        }
        if (stateAge >= stateLen) pickNext(t, stage);
    }

    private void observing(ServerWorld w, ServerPlayerEntity t, int stage, double dist) {
        e.lookAt(t.getEyePos());
        if (stage >= 2 && look.seen()) {
            e.getNavigation().stop();
            e.setHsFlag(HorrorSteveEntity.F_FROZEN, true);
        } else {
            e.setHsFlag(HorrorSteveEntity.F_FROZEN, false);
            if (e.age % 20 == 0) {
                if (orbit == null || e.getPos().squaredDistanceTo(orbit) < 4) {
                    double ring = Math.max(9, 28 - stateAge / 40.0 - stage);
                    orbit = SpawnLocator.around(w, t.getPos(), ring - 4, ring + 4, t.getBlockY());
                }
                if (orbit != null) e.getNavigation().startMovingTo(orbit.x, orbit.y, orbit.z, 0.95);
            }
        }
        if (dist < 5 && stage <= 3) enter(HorrorState.DISAPPEARING, stage);
        else if (stateAge >= stateLen) pickNext(t, stage);
    }

    private void following(ServerWorld w, ServerPlayerEntity t, int stage, double dist) {
        e.lookAt(t.getEyePos());
        double followDist = Math.max(6, 22 - stage * 2.5);
        if (stage >= 2 && look.seen()) {
            e.getNavigation().stop();
            e.setHsFlag(HorrorSteveEntity.F_FROZEN, true);
            if (dist < 30 && Rand.chance(0.004)) {
                enter(HorrorState.DISAPPEARING, stage);
                return;
            }
        } else {
            e.setHsFlag(HorrorSteveEntity.F_FROZEN, false);
            if (stage >= 3 && dist > 40 && tpCd == 0 && Rand.chance(0.02)) {
                Vec3d spot = SpawnLocator.behind(w, t, followDist, followDist + 6);
                if (spot != null) {
                    doTeleport(w, t, spot);
                    return;
                }
            }
            if (e.age % 15 == 0 && dist > followDist + 2) {
                Vec3d back = t.getPos().subtract(Geo.horizontalLook(t).multiply(followDist));
                e.getNavigation().startMovingTo(back.x, back.y, back.z, 1.1);
            }
        }
        if (stateAge >= stateLen) pickNext(t, stage);
    }

    private void hiding(ServerWorld w, ServerPlayerEntity t, int stage, double dist) {
        if (hideSpot == null) {
            for (int i = 0; i < 12 && hideSpot == null; i++) {
                Vec3d c = SpawnLocator.around(w, e.getPos(), 2, 8, e.getBlockY());
                if (c != null && !EyeContact.clearSight(w, t.getEyePos(), c.add(0, 1.6, 0), t)) hideSpot = c;
            }
            if (hideSpot == null) {
                enter(HorrorState.WATCHING, stage);
                return;
            }
        }
        if (e.getPos().squaredDistanceTo(hideSpot) > 2.5) {
            if (e.age % 15 == 0) e.getNavigation().startMovingTo(hideSpot.x, hideSpot.y, hideSpot.z, 1.15);
        } else {
            e.getNavigation().stop();
            e.releaseHead();
            if (stateAge % 80 > 50) e.lookAt(t.getEyePos());
            if (look.seen() && Rand.chance(0.02)) {
                enter(HorrorState.DISAPPEARING, stage);
                return;
            }
        }
        if (stateAge >= stateLen) pickNext(t, stage);
    }

    private void fleeing(ServerPlayerEntity t, int stage) {
        if (stateAge == 1 || stateAge % 15 == 0) {
            Vec3d away = e.getPos().subtract(t.getPos()).multiply(1, 0, 1);
            if (away.lengthSquared() < 0.01) away = Geo.horizontalLook(t);
            Vec3d to = e.getPos().add(away.normalize().multiply(14));
            e.getNavigation().startMovingTo(to.x, to.y, to.z, 1.6);
        }
        if (stateAge >= stateLen) enter(HorrorState.DISAPPEARING, stage);
    }

    private void manipulating(ServerPlayerEntity t, int stage) {
        e.lookAt(t.getEyePos());
        e.faceToward(t.getPos());
        if (stateAge == 40) {
            if (!HorrorDirector.runEventNear(t, e)) {
                enter(HorrorState.WATCHING, stage);
                return;
            }
        }
        if (stateAge >= stateLen) enter(HorrorState.WATCHING, stage);
    }

    private void hunting(ServerWorld w, ServerPlayerEntity t, PlayerProfile prof, PlayerSession sess, int stage, double dist) {
        e.releaseHead();
        e.faceToward(t.getPos());
        sess.chaseUntil = Scheduler.now() + 40;
        double speed = Math.min(1.45, 1.0 + 0.06 * stage);
        if (flyTicks > 0) {
            flyTicks--;
            e.noClip = true;
            e.setNoGravity(true);
            e.setHsFlag(HorrorSteveEntity.F_FLOAT, true);
            Vec3d target = t.getPos().add(0, 1.0, 0);
            Vec3d dir = target.subtract(e.getPos());
            if (dir.length() > 0.7) {
                Vec3d step = dir.normalize().multiply(Math.min(0.55, dir.length()));
                e.refreshPositionAndAngles(e.getX() + step.x, e.getY() + step.y, e.getZ() + step.z, e.getYaw(), 0);
            }
            if (flyTicks == 0) {
                e.noClip = false;
                e.setNoGravity(false);
                e.setHsFlag(HorrorSteveEntity.F_FLOAT, false);
            }
        } else {
            if (e.age % 8 == 0) e.getNavigation().startMovingTo(t, speed);
            if (stage >= 4 && dist > 10 && Rand.chance(stage >= 6 ? 0.006 : 0.003)) flyTicks = 60;
            if (tpCd == 0 && dist > 14 && stage >= 4 && Rand.chance(0.012)) {
                Vec3d spot = SpawnLocator.around(w, t.getPos(), 5, 9, t.getBlockY());
                if (spot != null) {
                    doTeleport(w, t, spot);
                    tpCd = Rand.range(100, 240);
                    return;
                }
            }
        }
        if (dist < 2.6) {
            enter(HorrorState.ATTACKING, stage);
            return;
        }
        if (dist > 70) {
            prof.inc(Stat.ESCAPES);
            prof.bump(Trait.AVOIDANT, 2);
            enter(HorrorState.DISAPPEARING, stage);
            return;
        }
        if (stateAge >= stateLen) {
            prof.inc(Stat.ESCAPES);
            enter(HorrorState.DISAPPEARING, stage);
        }
    }

    private void attacking(ServerWorld w, ServerPlayerEntity t, PlayerProfile prof, int stage, double dist) {
        e.faceToward(t.getPos());
        e.lookAt(t.getEyePos());
        if (attackCd == 0 && dist < 3.4) {
            float dmg = (float) Math.min(6.0, 2.0 + stage * 0.6);
            boolean mercy = stage < 5 && t.getHealth() <= dmg + 1;
            if (mercy) {
                enter(HorrorState.DISAPPEARING, stage);
                return;
            }
            e.swingHand(Hand.MAIN_HAND);
            t.damage(w.getDamageSources().mobAttack(e), dmg);
            FearTracker.spike(prof, 12);
            Sfx.at(t, ModSounds.DISTORT, e.getPos(), 0.6f, 0.7f, true);
            attackCd = 25;
            hits++;
        }
        if (dist > 5) enter(HorrorState.HUNTING, stage);
        else if (hits >= 3 || stateAge >= stateLen) enter(HorrorState.TELEPORTING, stage);
    }

    private void teleporting(ServerWorld w, ServerPlayerEntity t, int stage) {
        Vec3d spot;
        if (resume == HorrorState.HUNTING) spot = SpawnLocator.around(w, t.getPos(), 5, 9, t.getBlockY());
        else if (resume == HorrorState.FOLLOWING) spot = SpawnLocator.behind(w, t, 12, 20);
        else spot = SpawnLocator.around(w, t.getPos(), 15, 30, t.getBlockY());
        if (spot != null) doTeleport(w, t, spot);
        if (tpCd < 120) tpCd = Rand.range(160, 420);
        HorrorState back = resume == HorrorState.TELEPORTING || resume == HorrorState.DISAPPEARING ? HorrorState.WATCHING : resume;
        enter(back, stage);
    }

    private void doTeleport(ServerWorld w, ServerPlayerEntity t, Vec3d spot) {
        w.spawnParticles(ParticleTypes.SMOKE, e.getX(), e.getY() + 1, e.getZ(), 6, 0.2, 0.5, 0.2, 0.01);
        Sfx.at(t, ModSounds.TELEPORT, e.getPos(), 0.35f, Rand.range(0.7f, 1.2f), false);
        e.teleportTo(spot.x, spot.y, spot.z);
        e.faceToward(t.getPos());
        w.spawnParticles(ParticleTypes.SMOKE, spot.x, spot.y + 1, spot.z, 6, 0.2, 0.5, 0.2, 0.01);
        tpCd = Rand.range(100, 300);
    }

    private void disappearing(ServerWorld w) {
        w.spawnParticles(ParticleTypes.LARGE_SMOKE, e.getX(), e.getY() + 1, e.getZ(), 5, 0.25, 0.6, 0.25, 0.01);
        e.discard();
    }

    // ---------------------------------------------------------------- attacked

    public void onAttacked(ServerPlayerEntity p) {
        PlayerProfile prof = HorrorDirector.profile(p);
        prof.inc(Stat.ATTACKS);
        prof.bump(Trait.AGGRESSIVE, 2.5);
        prof.bump(Trait.CONFRONTATIONAL, 1.5);
        int stage = HorrorDirector.effectiveStage(p);
        DialogueEngine.reactAttack(p, prof, stage);
        if (interruptTicks > 0 || e.getRole() != HorrorSteveEntity.ROLE_MAIN) {
            if (e.getRole() != HorrorSteveEntity.ROLE_MAIN) disappearing((ServerWorld) e.getWorld());
            return;
        }
        enter(Rand.chance(0.5) ? HorrorState.TELEPORTING : HorrorState.DISAPPEARING, stage);
    }

    // ---------------------------------------------------------------- decoy

    private void decoyTick(ServerWorld w, ServerPlayerEntity t, double dist) {
        e.lookAt(t.getEyePos());
        switch (decoyMode) {
            case STARE -> {
                e.faceToward(t.getPos());
                if (dist < 5.0 || e.age > e.lifespan) vanish(w, t, true);
                else if (e.age % 3 == 0) {
                    Look l = EyeContact.evaluate(t, e);
                    if (l.seen() && l.face()) seenTicks += 3;
                    if (seenTicks > 80 && Rand.chance(0.05)) vanish(w, t, false);
                }
            }
            case BEHIND -> {
                e.faceToward(t.getPos());
                if (e.age > e.lifespan) vanish(w, t, false);
            }
            case RUSH -> {
                Vec3d to = t.getPos().add(0, 0.2, 0).subtract(e.getPos());
                double len = to.length();
                if (len < 2.3 || e.age > e.lifespan) {
                    Sfx.at(t, ModSounds.JUMPSCARE, t.getPos(), 0.9f, Rand.range(0.9f, 1.1f), true);
                    vanish(w, t, false);
                    return;
                }
                Vec3d step = to.normalize().multiply(0.85);
                e.faceToward(t.getPos());
                e.refreshPositionAndAngles(e.getX() + step.x, e.getY() + step.y, e.getZ() + step.z, e.getYaw(), 0);
            }
        }
    }

    private void vanish(ServerWorld w, ServerPlayerEntity t, boolean quiet) {
        w.spawnParticles(ParticleTypes.SMOKE, e.getX(), e.getY() + 1, e.getZ(), 4, 0.2, 0.5, 0.2, 0.01);
        if (!quiet) Sfx.at(t, ModSounds.STATIC, e.getPos(), 0.25f, 1.0f, false);
        e.discard();
    }

    // ---------------------------------------------------------------- fake player / pretending

    private void fakePlayerTick(ServerWorld w, ServerPlayerEntity t, PlayerProfile prof, double dist) {
        if (fakeVariant < 0) {
            fakeVariant = Rand.r().nextInt(4);
            fakeName = e.hasCustomName() && e.getCustomName() != null ? e.getCustomName().getString() : "Steve";
            pretendLen = Rand.range(250, 600);
            if (Rand.chance(0.6)) e.equipStack(EquipmentSlot.MAINHAND, new ItemStack(Items.IRON_PICKAXE));
        }
        pretendTick(w, t, prof, dist, false);
    }

    /** Pretends to be a normal player, then breaks the act. */
    private void pretendTick(ServerWorld w, ServerPlayerEntity t, PlayerProfile prof, double dist, boolean asMainState) {
        fakeTimer++;
        if (fakePhase == 0) {
            if (fakeVariant == 2) {
                e.getNavigation().stop();
            } else if (fakeTimer % 60 == 0 && fakeVariant != 3) {
                Vec3d c = SpawnLocator.around(w, e.getPos(), 3, 9, e.getBlockY());
                if (c != null) e.getNavigation().startMovingTo(c.x, c.y, c.z, 0.9);
            }
            if (fakeTimer % 25 == 0 && (fakeVariant == 3 || Rand.chance(0.5))) e.swingHand(Hand.MAIN_HAND);
            if (dist < 4 && Rand.chance(0.05)) fakePhase = 1;
            if (fakeTimer > pretendLen) {
                fakePhase = 1;
                fakeTimer = 0;
            }
        } else if (fakePhase == 1) {
            e.getNavigation().stop();
            e.setHsFlag(HorrorSteveEntity.F_NO_LIMBS, true);
            if (fakeTimer == 1) {
                if (fakeVariant == 0) {
                    wallDir = nearestWallDir(w);
                    if (wallDir != null) e.lockBody(Geo.yawTo(Vec3d.ZERO, wallDir));
                }
                if (Rand.chance(0.6)) Messenger.sayAs(t, fakeName, DialogueEngine.fakePlayerChat());
            }
            if (fakeVariant == 0 && wallDir != null && fakeTimer < 120) {
                e.setVelocity(wallDir.multiply(0.06));
                e.velocityModified = true;
                e.setHsFlag(HorrorSteveEntity.F_NO_LIMBS, false);
            } else {
                e.lookAt(t.getEyePos());
                e.faceToward(t.getPos());
                e.setHsFlag(HorrorSteveEntity.F_FROZEN, true);
            }
            if (fakeTimer > 120 + Rand.range(0, 120)) fakePhase = 2;
        } else {
            e.lookAt(t.getEyePos());
            if (Rand.chance(0.01) || fakeTimer > 400) {
                if (Rand.chance(0.5)) Messenger.sayAs(t, fakeName, DialogueEngine.fakePlayerChat());
                w.spawnParticles(ParticleTypes.SMOKE, e.getX(), e.getY() + 1, e.getZ(), 4, 0.2, 0.5, 0.2, 0.01);
                e.discard();
            }
        }
    }

    private Vec3d wallDir;

    private Vec3d nearestWallDir(ServerWorld w) {
        Vec3d[] dirs = {new Vec3d(1, 0, 0), new Vec3d(-1, 0, 0), new Vec3d(0, 0, 1), new Vec3d(0, 0, -1)};
        for (int dist = 1; dist <= 6; dist++) {
            for (Vec3d d : dirs) {
                net.minecraft.util.math.BlockPos p = net.minecraft.util.math.BlockPos.ofFloored(e.getX() + d.x * dist, e.getY() + 1, e.getZ() + d.z * dist);
                if (!w.getBlockState(p).getCollisionShape(w, p).isEmpty()) return d;
            }
        }
        return null;
    }
}
