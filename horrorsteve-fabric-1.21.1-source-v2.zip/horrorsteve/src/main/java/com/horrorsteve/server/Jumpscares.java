package com.horrorsteve.server;

import com.horrorsteve.ai.HorrorBrain;
import com.horrorsteve.ai.SpawnLocator;
import com.horrorsteve.config.HorrorConfig;
import com.horrorsteve.entity.HorrorSteveEntity;
import com.horrorsteve.fear.FearTracker;
import com.horrorsteve.network.FxPayload;
import com.horrorsteve.network.OverlayPayload;
import com.horrorsteve.progression.PlayerProfile;
import com.horrorsteve.progression.Stat;
import com.horrorsteve.sound.ModSounds;
import com.horrorsteve.util.Geo;
import com.horrorsteve.util.Rand;
import com.horrorsteve.util.Scheduler;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;

/** Used sparingly: global cooldown scaled by jumpscareFrequency, and a hard off switch in the config. */
public final class Jumpscares {
    private Jumpscares() {}

    public static boolean allowed(ServerPlayerEntity p, boolean force) {
        HorrorConfig c = HorrorConfig.get();
        if (force) return true;
        if (!c.jumpscares || c.jumpscareFrequency <= 0.01 || c.horrorIntensity <= 0.2) return false;
        PlayerSession s = HorrorDirector.session(p);
        long gap = (long) (20L * 60 * 4 / c.jumpscareFrequency);
        return Scheduler.now() - s.lastJumpscareTick > gap;
    }

    private static void mark(ServerPlayerEntity p) {
        PlayerSession s = HorrorDirector.session(p);
        PlayerProfile prof = HorrorDirector.profile(p);
        s.lastJumpscareTick = Scheduler.now();
        prof.inc(Stat.JUMPSCARES);
        FearTracker.spike(prof, 20);
    }

    public static boolean face(ServerPlayerEntity p, boolean force) {
        if (!allowed(p, force)) return false;
        mark(p);
        Sfx.at(p, ModSounds.JUMPSCARE, p.getEyePos(), 1.0f, Rand.range(0.9f, 1.1f), true);
        Fx.overlay(p, OverlayPayload.FACE, "", 10);
        Fx.send(p, FxPayload.SHAKE, 12, 1.0f);
        Fx.send(p, FxPayload.FLASH, 3, 0.5f);
        return true;
    }

    public static boolean blackout(ServerPlayerEntity p, boolean force) {
        if (!allowed(p, force)) return false;
        mark(p);
        Fx.send(p, FxPayload.BLACKOUT, 30, 1.0f);
        Sfx.at(p, ModSounds.STATIC, p.getEyePos(), 0.8f, 0.8f, true);
        Scheduler.later(32, () -> {
            if (!p.isRemoved()) Sfx.behind(p, ModSounds.BREATH, 1.5, 0.7f, 0.8f);
        });
        return true;
    }

    public static boolean behind(ServerPlayerEntity p, boolean force) {
        if (!allowed(p, force)) return false;
        ServerWorld w = (ServerWorld) p.getWorld();
        Vec3d pos = p.getPos().subtract(Geo.horizontalLook(p).multiply(1.9));
        Vec3d g = SpawnLocator.ground(w, (int) Math.floor(pos.x), (int) Math.floor(pos.z), p.getBlockY(), 2, 3);
        HorrorSteveEntity e = HorrorDirector.spawnDecoy(p, g != null ? g : pos, 35, HorrorBrain.DecoyMode.BEHIND);
        if (e == null) return false;
        mark(p);
        Sfx.at(p, ModSounds.JUMPSCARE, p.getEyePos(), 0.8f, 1.1f, true);
        Fx.send(p, FxPayload.SHAKE, 10, 0.8f);
        return true;
    }

    public static boolean rush(ServerPlayerEntity p, boolean force) {
        if (!allowed(p, force)) return false;
        ServerWorld w = (ServerWorld) p.getWorld();
        Vec3d pos = SpawnLocator.ring(w, p, 17, 20, 0, 40, false);
        if (pos == null) return false;
        HorrorSteveEntity e = HorrorDirector.spawnDecoy(p, pos, 90, HorrorBrain.DecoyMode.RUSH);
        if (e == null) return false;
        mark(p);
        Sfx.at(p, ModSounds.DISTORT, pos, 0.8f, 0.6f, true);
        return true;
    }

    public static boolean fakeCrash(ServerPlayerEntity p, boolean force) {
        if (!allowed(p, force)) return false;
        mark(p);
        Fx.overlay(p, OverlayPayload.FAKE_CRASH, "", 60);
        Sfx.at(p, ModSounds.STATIC, p.getEyePos(), 0.6f, 1.0f, true);
        return true;
    }

    public static boolean fakeTitle(ServerPlayerEntity p, boolean force) {
        if (!allowed(p, force)) return false;
        mark(p);
        Fx.overlay(p, OverlayPayload.FAKE_TITLE, "", 50);
        return true;
    }
}
