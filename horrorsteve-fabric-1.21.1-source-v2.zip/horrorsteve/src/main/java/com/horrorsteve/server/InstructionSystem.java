package com.horrorsteve.server;

import com.horrorsteve.dialogue.DialogueDatabase;
import com.horrorsteve.dialogue.DialogueEngine;
import com.horrorsteve.progression.PlayerProfile;
import com.horrorsteve.progression.Stat;
import com.horrorsteve.progression.Trait;
import com.horrorsteve.server.PlayerSession.Instruction;
import com.horrorsteve.server.PlayerSession.InstructionType;
import com.horrorsteve.util.Rand;
import com.horrorsteve.util.Scheduler;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.math.MathHelper;

/** Orders like "Don't turn around." The entity checks whether you obeyed, and remembers. */
public final class InstructionSystem {
    private InstructionSystem() {}

    public static void give(ServerPlayerEntity p) {
        PlayerSession s = HorrorDirector.session(p);
        if (s.instruction != null) return;
        InstructionType t = Rand.pick(InstructionType.values());
        String key = switch (t) {
            case DONT_TURN -> "instructions.dont_turn";
            case KEEP_WALKING -> "instructions.keep_walking";
            case STOP_LOOKING -> "instructions.stop_looking";
        };
        String line = DialogueDatabase.pick(key);
        if (line == null) return;
        Instruction i = new Instruction();
        i.type = t;
        i.startTick = Scheduler.now();
        i.deadline = i.startTick + 20 * (t == InstructionType.DONT_TURN ? 6 : 8);
        i.startPos = p.getPos();
        i.startYaw = p.getYaw();
        i.startFace = HorrorDirector.profile(p).get(Stat.FACE_SECONDS);
        s.instruction = i;
        Messenger.whisper(p, line);
    }

    /** Called once per second per player. */
    public static void tick(ServerPlayerEntity p, PlayerProfile prof, PlayerSession s) {
        Instruction i = s.instruction;
        if (i == null) return;
        long now = Scheduler.now();
        if (i.type == InstructionType.DONT_TURN && Math.abs(MathHelper.wrapDegrees(p.getYaw() - i.startYaw)) > 110) {
            i.refused = true;
            finish(p, prof, s, false);
            return;
        }
        if (now < i.deadline) return;
        boolean ok = switch (i.type) {
            case DONT_TURN -> true;
            case KEEP_WALKING -> p.getPos().squaredDistanceTo(i.startPos) >= 49;
            case STOP_LOOKING -> prof.get(Stat.FACE_SECONDS) == i.startFace;
        };
        finish(p, prof, s, ok);
    }

    private static void finish(ServerPlayerEntity p, PlayerProfile prof, PlayerSession s, boolean followed) {
        s.instruction = null;
        if (followed) {
            prof.inc(Stat.INSTRUCTIONS_FOLLOWED);
            prof.bump(Trait.AVOIDANT, 0.5);
            DialogueEngine.line(p, "instructions.followed", Rand.range(10, 40));
        } else {
            prof.inc(Stat.INSTRUCTIONS_REFUSED);
            prof.bump(Trait.CONFRONTATIONAL, 1.0);
            Advancements.grant(p, "wrong_answer");
            DialogueEngine.line(p, "instructions.refused", Rand.range(10, 40));
        }
    }
}
