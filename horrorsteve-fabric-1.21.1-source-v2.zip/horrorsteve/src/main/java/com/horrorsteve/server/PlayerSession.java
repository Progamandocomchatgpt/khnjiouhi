package com.horrorsteve.server;

import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Runtime-only (not saved) state for one online player. */
public class PlayerSession {
    public enum InstructionType { DONT_TURN, KEEP_WALKING, STOP_LOOKING }

    public static final class Instruction {
        public InstructionType type;
        public long startTick;
        public long deadline;
        public Vec3d startPos;
        public float startYaw;
        public long startFace;
        public boolean refused;
    }

    public final UUID id;
    public long joinTick;
    public long nextEventTick;
    public long nextMessageTick;
    public long nextAppearTick;
    public long lastMessageTick = -100000;
    public long lastJumpscareTick = -100000;
    public long lastChaseTick = -100000;
    public long lastEncounterTick = -100000;
    public long lastSeenEntityTick = -100000;
    public long lastMemeTick = -100000;
    public long lastEndingCheck = 0;
    public long lastChatTick = -100000;
    public long chaseUntil = 0;
    public long unknownWindowUntil = 0;
    public int forcedStage = 0;
    public Vec3d lastPos;
    public String lastDim = "";
    public long lastDay = -1;
    public UUID mainEntity;
    public boolean placedDoor = false;
    public long minedAtLastComment = 0;
    public Instruction instruction;
    public boolean sleeping = false;
    public final Map<String, Long> eventCooldowns = new HashMap<>();

    public PlayerSession(UUID id) {
        this.id = id;
    }
}
