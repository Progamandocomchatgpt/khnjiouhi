package com.horrorsteve.server;

import com.horrorsteve.ai.HorrorBrain;
import com.horrorsteve.ai.SpawnLocator;
import com.horrorsteve.config.HorrorConfig;
import com.horrorsteve.dialogue.DialogueDatabase;
import com.horrorsteve.dialogue.DialogueEngine;
import com.horrorsteve.entity.HorrorSteveEntity;
import com.horrorsteve.events.EventRegistry;
import com.horrorsteve.events.HorrorEvent;
import com.horrorsteve.network.FxPayload;
import com.horrorsteve.progression.PlayerProfile;
import com.horrorsteve.progression.Stat;
import com.horrorsteve.progression.Trait;
import com.horrorsteve.sound.ModSounds;
import com.horrorsteve.util.Rand;
import com.horrorsteve.util.Scheduler;
import com.horrorsteve.world.HorrorWorldState;
import com.horrorsteve.world.IllusionManager;
import com.horrorsteve.world.RestorationManager;
import net.fabricmc.fabric.api.entity.event.v1.EntitySleepEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityWorldChangeEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** Wires every Fabric event the mod listens to. */
public final class ServerHooks {
    private ServerHooks() {}

    public static void register() {
        ServerLifecycleEvents.SERVER_STARTED.register(HorrorDirector::init);
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            IllusionManager.clearAll(server);
            RestorationManager.restoreAll(server);
            HorrorDirector.clearEntities(server);
            HorrorDirector.shutdown(server);
            Scheduler.clear();
        });

        ServerEntityEvents.ENTITY_UNLOAD.register((entity, world) -> {
            if (entity instanceof HorrorSteveEntity h) HorrorDirector.onEntityRemoved(h);
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            Scheduler.tick();
            HorrorDirector.tick(server);
            IllusionManager.tick(server);
            if (Scheduler.now() % 40 == 0) RestorationManager.tick(server);
        });

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> HorrorDirector.onJoin(handler.player));
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> HorrorDirector.onLeave(handler.player));

        // chat: the exact message "67" fires the meme event; everything else goes to the dialogue engine
        ServerMessageEvents.CHAT_MESSAGE.register((message, sender, params) -> {
            String content = message.getSignedContent();
            if (Meme67.isMeme(content)) Meme67.trigger(sender, false);
            else DialogueEngine.onChat(sender, content);
        });

        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (entity instanceof ServerPlayerEntity p) onDeath(p, source.getType().msgId());
        });
        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
            if (!alive) onRespawn(newPlayer);
        });

        EntitySleepEvents.START_SLEEPING.register((entity, pos) -> {
            if (entity instanceof ServerPlayerEntity p) onSleep(p);
        });
        EntitySleepEvents.STOP_SLEEPING.register((entity, pos) -> {
            if (entity instanceof ServerPlayerEntity p) onWake(p);
        });

        ServerEntityWorldChangeEvents.AFTER_PLAYER_CHANGE_WORLD.register((player, origin, destination) -> {
            if (!HorrorConfig.get().modEnabled) return;
            PlayerProfile prof = HorrorDirector.profile(player);
            if (prof.get(Stat.TICKS_IN_WORLD) < 20L * HorrorConfig.get().graceSeconds) return;
            if (destination.getRegistryKey() == World.NETHER && Rand.chance(0.4)) DialogueEngine.context(player, "nether", 100);
            if (destination.getRegistryKey() == World.END && Rand.chance(0.5)) DialogueEngine.context(player, "end", 100);
        });

        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, be) -> {
            if (world.isClient || !(player instanceof ServerPlayerEntity p)) return;
            PlayerProfile prof = HorrorDirector.profile(p);
            PlayerSession s = HorrorDirector.session(p);
            prof.inc(Stat.BLOCKS_MINED);
            HorrorWorldState ws = HorrorWorldState.get(p.server);
            String key = HorrorWorldState.signKey(world.getRegistryKey().getValue().toString(), pos.asLong());
            if (ws.signs.remove(key)) {
                prof.inc(Stat.SIGNS_DESTROYED);
                prof.bump(Trait.AGGRESSIVE, 1.0);
                ws.markDirty();
            }
            if (prof.get(Stat.BLOCKS_MINED) - s.minedAtLastComment >= 500 && !world.isSkyVisible(p.getBlockPos())
                    && prof.get(Stat.TICKS_IN_WORLD) > 20L * HorrorConfig.get().graceSeconds) {
                s.minedAtLastComment = prof.get(Stat.BLOCKS_MINED);
                if (Rand.chance(0.5)) DialogueEngine.context(p, "mining", Rand.range(40, 200));
            }
        });

        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            if (world.isClient || !(player instanceof ServerPlayerEntity p)) return ActionResult.PASS;
            PlayerProfile prof = HorrorDirector.profile(p);
            PlayerSession s = HorrorDirector.session(p);
            ItemStack stack = p.getStackInHand(hand);
            if (stack.getItem() instanceof BlockItem) {
                prof.inc(Stat.BLOCKS_PLACED);
                if (stack.isIn(ItemTags.DOORS)) s.placedDoor = true;
                if (s.placedDoor && prof.get(Stat.BLOCKS_PLACED) >= 40 && !prof.flag("house_said")) {
                    prof.setFlag("house_said");
                    prof.inc(Stat.HOUSES_BUILT);
                    if (prof.get(Stat.TICKS_IN_WORLD) > 20L * HorrorConfig.get().graceSeconds && HorrorConfig.get().modEnabled) {
                        DialogueEngine.context(p, "house", Rand.range(200, 700));
                    }
                }
            }
            HorrorWorldState ws = HorrorWorldState.get(p.server);
            String key = HorrorWorldState.signKey(world.getRegistryKey().getValue().toString(), hit.getBlockPos().asLong());
            if (ws.signs.contains(key)) {
                String f = "sign:" + key;
                if (!prof.flag(f)) {
                    prof.setFlag(f);
                    prof.inc(Stat.SIGNS_READ);
                    prof.bump(Trait.CURIOUS, 2.0);
                }
            }
            return ActionResult.PASS;
        });
    }

    // ------------------------------------------------------------------ death

    private static String deathKey(String msgId) {
        String m = msgId == null ? "" : msgId.toLowerCase();
        if (m.contains("fall") || m.contains("flyintowall")) return "death_fall";
        if (m.contains("fire") || m.contains("lava") || m.contains("hotfloor")) return "death_fire";
        if (m.contains("drown")) return "death_drown";
        if (m.contains("explosion")) return "death_explosion";
        if (m.contains("outofworld") || m.contains("generickill")) return "death_void";
        if (m.contains("mob") || m.contains("arrow") || m.contains("player") || m.contains("thrown") || m.contains("trident")
                || m.contains("sting") || m.contains("fireball")) return "death_mob";
        return "death_other";
    }

    private static void onDeath(ServerPlayerEntity p, String msgId) {
        PlayerProfile prof = HorrorDirector.profile(p);
        prof.inc(Stat.DEATHS);
        prof.lastDeathCause = deathKey(msgId);
        prof.lastDeathDim = p.getWorld().getRegistryKey().getValue().toString();
        prof.lastDeathPos = p.getBlockPos().asLong();
        com.horrorsteve.fear.FearTracker.spike(prof, 12);
        PlayerSession s = HorrorDirector.session(p);
        s.chaseUntil = 0;
    }

    private static void onRespawn(ServerPlayerEntity p) {
        if (!HorrorConfig.get().modEnabled) return;
        PlayerProfile prof = HorrorDirector.profile(p);
        if (prof.get(Stat.TICKS_IN_WORLD) < 20L * HorrorConfig.get().graceSeconds) return;
        int stage = HorrorDirector.effectiveStage(p);
        String key = prof.lastDeathCause.isEmpty() ? "death_other" : prof.lastDeathCause;
        if (Rand.chance(0.75)) DialogueEngine.context(p, key, Rand.range(80, 240));
        if (stage >= 3 && Rand.chance(0.5) && prof.lastDeathDim.equals(p.getWorld().getRegistryKey().getValue().toString())) {
            final java.util.UUID id = p.getUuid();
            final MinecraftServer server = p.server;
            final BlockPos death = BlockPos.fromLong(prof.lastDeathPos);
            Scheduler.later(20 * Rand.range(8, 25), () -> {
                ServerPlayerEntity q = server.getPlayerManager().getPlayer(id);
                if (q == null || !(q.getWorld() instanceof ServerWorld w)) return;
                Vec3d g = SpawnLocator.ground(w, death.getX(), death.getZ(), death.getY(), 4, 6);
                if (g != null && q.squaredDistanceTo(g) < 150 * 150) {
                    HorrorDirector.spawnDecoy(q, g, 20 * 30, HorrorBrain.DecoyMode.STARE);
                }
            });
        }
    }

    // ------------------------------------------------------------------ sleep

    private static void onSleep(ServerPlayerEntity p) {
        PlayerProfile prof = HorrorDirector.profile(p);
        PlayerSession s = HorrorDirector.session(p);
        s.sleeping = true;
        prof.inc(Stat.SLEEPS);
        int stage = HorrorDirector.effectiveStage(p);
        if (HorrorConfig.get().modEnabled && stage >= 2 && Rand.chance(0.12)) {
            String line = DialogueDatabase.pick("context.dream");
            if (line != null) Messenger.sayLater(p, line, Rand.range(40, 100));
        }
    }

    private static void onWake(ServerPlayerEntity p) {
        PlayerSession s = HorrorDirector.session(p);
        if (!s.sleeping) return;
        s.sleeping = false;
        HorrorConfig cfg = HorrorConfig.get();
        PlayerProfile prof = HorrorDirector.profile(p);
        int stage = HorrorDirector.effectiveStage(p);
        if (!cfg.modEnabled || stage < 2 || prof.get(Stat.TICKS_IN_WORLD) < 20L * cfg.graceSeconds) return;
        if (!Rand.chance(0.22 * Math.max(0.2, cfg.horrorIntensity))) return;
        ServerWorld w = (ServerWorld) p.getWorld();
        Advancements.grant(p, "dont_sleep");
        switch (Rand.range(0, 5)) {
            case 0 -> DialogueEngine.context(p, prof.get(Stat.SLEEPS) >= 5 ? "sleep_many" : "wake", 60);
            case 1 -> {
                Vec3d v = SpawnLocator.ring(w, p, 6, 12, 0, 360, false);
                if (v != null) HorrorDirector.spawnDecoy(p, v, 20 * 20, HorrorBrain.DecoyMode.STARE);
                Sfx.behind(p, ModSounds.KNOCK, 3, 0.7f, 0.9f);
            }
            case 2 -> {
                HorrorEvent e = EventRegistry.get("door_open");
                if (e != null) EventRegistry.run(e, HorrorDirector.ctx(p, null));
            }
            case 3 -> HorrorDirector.spawnMain(p, SpawnLocator.Strategy.FAR_OPEN);
            case 4 -> {
                Sfx.around(p, ModSounds.WHISPER, 2, 5, 0.6f, 0.9f);
                Sfx.behind(p, ModSounds.BREATH, 1.5, 0.4f, 0.9f);
            }
            default -> {
                Fx.send(p, FxPayload.FOV_WIDE, 120, 0.5f);
                Fx.send(p, FxPayload.VIGNETTE, 160, 0.5f);
                DialogueEngine.context(p, "wake", 100);
            }
        }
    }
}
