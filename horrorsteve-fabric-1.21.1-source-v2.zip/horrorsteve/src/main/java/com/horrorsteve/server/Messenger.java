package com.horrorsteve.server;

import com.horrorsteve.config.HorrorConfig;
import com.horrorsteve.util.Rand;
import com.horrorsteve.util.Scheduler;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/** Everything the entity "types". Uses vanilla chat formats so it looks like a real player or system message. */
public final class Messenger {
    private Messenger() {}

    private static String nameFor(int stage) {
        if (stage >= 8) return "???";
        if (stage == 6 && Rand.chance(0.25)) return "St3ve";
        return "Steve";
    }

    /** Plain "<name> text" chat line, as if the named player had spoken. */
    public static void sayAs(ServerPlayerEntity p, String name, String text) {
        if (p == null || p.isRemoved() || text == null) return;
        p.sendMessage(Text.literal("<" + name + "> " + text), false);
    }

    /** The entity speaking, styled by stage (late stages look wrong). */
    public static void say(ServerPlayerEntity p, String text) {
        if (p == null || p.isRemoved() || text == null || text.isEmpty()) return;
        int stage = HorrorDirector.effectiveStage(p);
        String name = nameFor(stage);
        MutableText line = Text.literal("<");
        MutableText n = Text.literal(name);
        if (stage >= 7 && Rand.chance(0.4)) n = n.formatted(Formatting.OBFUSCATED);
        line.append(n).append(Text.literal("> "));
        MutableText body = Text.literal(text);
        if (stage >= 7) body = body.formatted(Formatting.GRAY, Formatting.ITALIC);
        line.append(body);
        p.sendMessage(line, false);
        HorrorDirector.session(p).lastMessageTick = Scheduler.now();
    }

    public static void sayLater(ServerPlayerEntity p, String text, int delayTicks) {
        final java.util.UUID id = p.getUuid();
        final net.minecraft.server.MinecraftServer server = p.server;
        Scheduler.later(delayTicks, () -> {
            ServerPlayerEntity q = server.getPlayerManager().getPlayer(id);
            if (q != null) say(q, text);
        });
    }

    /** Looks like the vanilla /msg whisper. */
    public static void whisper(ServerPlayerEntity p, String text) {
        if (p == null || p.isRemoved() || text == null) return;
        int stage = HorrorDirector.effectiveStage(p);
        p.sendMessage(Text.literal(nameFor(stage) + " whispers to you: " + text).formatted(Formatting.GRAY, Formatting.ITALIC), false);
        HorrorDirector.session(p).lastMessageTick = Scheduler.now();
    }

    /** A line of fake system output (server log style). */
    public static void system(ServerPlayerEntity p, String text, Formatting color) {
        if (!HorrorConfig.get().fakeSystemMessages || p == null || p.isRemoved()) return;
        p.sendMessage(Text.literal(text).formatted(color), false);
    }

    public static void systemLater(ServerPlayerEntity p, String text, Formatting color, int delay) {
        final java.util.UUID id = p.getUuid();
        final net.minecraft.server.MinecraftServer server = p.server;
        Scheduler.later(delay, () -> {
            ServerPlayerEntity q = server.getPlayerManager().getPlayer(id);
            if (q != null) system(q, text, color);
        });
    }

    /** Unsolicited messages are rate-limited so chat never spams. */
    public static boolean canSpeakUnprompted(PlayerSession s) {
        return Scheduler.now() - s.lastMessageTick > 20 * 25;
    }
}
