package com.horrorsteve.server;

import com.horrorsteve.HorrorSteveMod;
import net.minecraft.advancement.AdvancementEntry;
import net.minecraft.server.network.ServerPlayerEntity;

public final class Advancements {
    private Advancements() {}

    /** Grants data/horrorsteve/advancement/<key>.json (all use an impossible trigger and are granted from code). */
    public static void grant(ServerPlayerEntity p, String key) {
        try {
            AdvancementEntry entry = p.server.getAdvancementLoader().get(HorrorSteveMod.id(key));
            if (entry == null) return;
            if (p.getAdvancementTracker().getProgress(entry).isDone()) return;
            p.getAdvancementTracker().grantCriterion(entry, "done");
        } catch (Exception e) {
            HorrorSteveMod.LOG.warn("Could not grant advancement {}", key, e);
        }
    }
}
