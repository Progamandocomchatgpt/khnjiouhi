package com.horrorsteve.server;

import com.horrorsteve.entity.HorrorSteveEntity;
import com.horrorsteve.fear.FearTracker;
import com.horrorsteve.progression.PlayerProfile;
import com.horrorsteve.progression.Stat;
import com.horrorsteve.progression.Trait;
import com.horrorsteve.util.Scheduler;
import com.horrorsteve.world.HorrorWorldState;
import com.horrorsteve.world.RestorationManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/** Once-per-second bookkeeping that feeds the hidden progression, fear and personality systems. */
public final class PlayerTracker {
    private PlayerTracker() {}

    public static void tick(ServerWorld w, ServerPlayerEntity p, PlayerProfile prof, PlayerSession s) {
        long now = Scheduler.now();
        prof.add(Stat.TICKS_IN_WORLD, 20);
        prof.lastSeenMs = System.currentTimeMillis();

        String dim = RestorationManager.dimKey(w);
        boolean overworld = w.getRegistryKey() == World.OVERWORLD;
        boolean underground = overworld && !w.isSkyVisible(p.getBlockPos()) && p.getY() < 56;
        if (underground) prof.inc(Stat.UNDERGROUND_SECONDS);
        if (w.getRegistryKey() == World.NETHER) prof.inc(Stat.NETHER_SECONDS);
        if (w.getRegistryKey() == World.END) prof.inc(Stat.END_SECONDS);

        boolean alone = true;
        for (ServerPlayerEntity o : w.getPlayers()) {
            if (o != p && !o.isSpectator() && o.squaredDistanceTo(p) < 100 * 100) {
                alone = false;
                break;
            }
        }
        if (alone) prof.inc(Stat.ALONE_SECONDS);

        // movement
        double moved = 0;
        if (s.lastPos != null && dim.equals(s.lastDim)) {
            double dx = p.getX() - s.lastPos.x;
            double dz = p.getZ() - s.lastPos.z;
            moved = Math.sqrt(dx * dx + dz * dz);
            if (moved < 30) {
                prof.add(Stat.DISTANCE_BLOCKS, Math.round(moved));
                prof.bump(Trait.EXPLORATIVE, moved * 0.004);
            }
        }
        s.lastPos = p.getPos();
        s.lastDim = dim;
        if (now < s.chaseUntil && moved > 5.0) {
            prof.inc(Stat.RAN);
            prof.bump(Trait.AVOIDANT, 0.6);
        }

        // nights survived
        long day = w.getTimeOfDay() / 24000L;
        if (s.lastDay >= 0 && day > s.lastDay) prof.inc(Stat.NIGHTS);
        s.lastDay = day;

        // fear
        HorrorSteveEntity main = HorrorDirector.mainEntityOf(p);
        double ed = main != null ? main.distanceTo(p) : 999;
        boolean visible = main != null && now - s.lastSeenEntityTick < 40;
        int light = w.getLightLevel(p.getBlockPos());
        FearTracker.tick(prof, ed, visible, visible && ed < 10, light, underground, p.getHealth(), now < s.chaseUntil);

        // structures visited
        HorrorWorldState st = HorrorWorldState.get(w.getServer());
        for (HorrorWorldState.Structure rec : st.structures) {
            if (!rec.dim.equals(dim)) continue;
            BlockPos bp = BlockPos.fromLong(rec.pos);
            if (net.minecraft.util.math.Vec3d.ofCenter(bp).squaredDistanceTo(p.getPos()) < 8 * 8) {
                String f = "visited:" + rec.pos;
                if (!prof.flag(f)) {
                    prof.setFlag(f);
                    prof.inc(Stat.STRUCTURES_VISITED);
                    prof.bump(Trait.EXPLORATIVE, 3);
                    prof.bump(Trait.CURIOUS, 2);
                    Advancements.grant(p, "something_changed");
                    if (prof.get(Stat.SIGNS_READ) > 0) Advancements.grant(p, "shouldnt_have_followed");
                }
            }
        }
        if (prof.get(Stat.STRUCTURES_VISITED) > 0 && alone) Advancements.grant(p, "are_you_alone");
    }
}
