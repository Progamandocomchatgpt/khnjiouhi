package com.horrorsteve.server;

import com.horrorsteve.config.HorrorConfig;
import com.horrorsteve.network.FxPayload;
import com.horrorsteve.network.OverlayPayload;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.network.ServerPlayerEntity;

/** Server helpers for client-side effects. The client applies its own accessibility filters on top. */
public final class Fx {
    private Fx() {}

    public static void send(ServerPlayerEntity p, int type, int ticks, float intensity) {
        HorrorConfig c = HorrorConfig.get();
        if (!c.cameraEffects) return;
        float scaled = (float) (intensity * Math.max(0.2, c.horrorIntensity));
        ServerPlayNetworking.send(p, new FxPayload(type, ticks, scaled));
    }

    public static void overlay(ServerPlayerEntity p, int kind, String text, int ticks) {
        ServerPlayNetworking.send(p, new OverlayPayload(kind, text == null ? "" : text, ticks));
    }
}
