package com.horrorsteve.server;

import com.horrorsteve.ai.HorrorBrain;
import com.horrorsteve.ai.HorrorState;
import com.horrorsteve.ai.SpawnLocator;
import com.horrorsteve.config.HorrorConfig;
import com.horrorsteve.dialogue.DialogueDatabase;
import com.horrorsteve.dialogue.DialogueEngine;
import com.horrorsteve.entity.HorrorSteveEntity;
import com.horrorsteve.entity.ModEntities;
import com.horrorsteve.events.EnvironmentEvents;
import com.horrorsteve.events.EventContext;
import com.horrorsteve.events.EventRegistry;
import com.horrorsteve.events.EventUtil;
import com.horrorsteve.events.HorrorEvent;
import com.horrorsteve.progression.PlayerProfile;
import com.horrorsteve.progression.ProfileState;
import com.horrorsteve.progression.Stat;
import com.horrorsteve.progression.StageManager;
import com.horrorsteve.sound.ModSounds;
import com.horrorsteve.network.FxPayload;
import com.horrorsteve.util.Geo;
import com.horrorsteve.util.Rand;
import com.horrorsteve.util.Scheduler;
import net.minecraft.entity.Entity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** The conductor: decides when each player gets an appearance, an event or a message, and owns every entity spawn. */
public final class HorrorDirector {
    private static final Map<UUID, PlayerSession> SESSIONS = new HashMap<>();
    private static final Set<UUID> LIVE = new HashSet<>();
    private static final Set<UUID> DECOYS = new HashSet<>();
    private static ProfileState state;

    // {min, max} seconds per stage 1..8
    private static final int[][] EVENT_INTERVAL = {{420, 720}, {240, 480}, {180, 360}, {120, 240}, {90, 180}, {60, 120}, {40, 90}, {30, 60}};
    private static final int[][] APPEAR_INTERVAL = {{300, 600}, {240, 480}, {180, 360}, {120, 300}, {120, 240}, {90, 200}, {60, 150}, {60, 120}};
    private static final int[][] MESSAGE_INTERVAL = {{480, 900}, {300, 600}, {180, 420}, {120, 300}, {120, 300}, {90, 240}, {60, 180}, {60, 150}};

    private HorrorDirector() {}

    // ------------------------------------------------------------------ lifecycle

    public static void init(MinecraftServer server) {
        state = ProfileState.get(server);
        SESSIONS.clear();
        LIVE.clear();
        DECOYS.clear();
        DialogueDatabase.reload();
    }

    public static void shutdown(MinecraftServer server) {
        EnvironmentEvents.releaseFrozen();
        SESSIONS.clear();
        LIVE.clear();
        DECOYS.clear();
        state = null;
    }

    private static ProfileState state(MinecraftServer s) {
        if (state == null) state = ProfileState.get(s);
        return state;
    }

    public static PlayerProfile profile(ServerPlayerEntity p) {
        PlayerProfile prof = state(p.server).profile(p.getUuid());
        if (prof.name.isEmpty()) prof.name = p.getName().getString();
        return prof;
    }

    public static PlayerSession session(ServerPlayerEntity p) {
        return SESSIONS.computeIfAbsent(p.getUuid(), id -> {
            PlayerSession s = new PlayerSession(id);
            long now = Scheduler.now();
            s.joinTick = now;
            s.nextEventTick = now + 20L * Rand.range(180, 420);
            s.nextAppearTick = now + 20L * Rand.range(240, 600);
            s.nextMessageTick = now + 20L * Rand.range(300, 700);
            return s;
        });
    }

    public static int effectiveStage(ServerPlayerEntity p) {
        if (p == null) return 1;
        PlayerSession s = session(p);
        if (s.forcedStage > 0) return s.forcedStage;
        return StageManager.effective(profile(p), Scheduler.now() < s.unknownWindowUntil);
    }

    public static void onJoin(ServerPlayerEntity p) {
        PlayerProfile prof = profile(p);
        PlayerSession s = session(p);
        Advancements.grant(p, "root");
        long absentMs = prof.lastSeenMs == 0 ? 0 : System.currentTimeMillis() - prof.lastSeenMs;
        boolean past = prof.get(Stat.TICKS_IN_WORLD) > 20L * HorrorConfig.get().graceSeconds;
        if (past && HorrorConfig.get().modEnabled) {
            if (absentMs > 6L * 3600_000L && prof.get(Stat.CONVERSATIONS) + prof.get(Stat.ENCOUNTERS) > 0) {
                DialogueEngine.context(p, "came_back_long", 20 * Rand.range(40, 120));
            } else if (Rand.chance(0.3)) {
                DialogueEngine.context(p, "came_back", 20 * Rand.range(60, 240));
            }
        }
        state(p.server).markDirty();
    }

    public static void onLeave(ServerPlayerEntity p) {
        PlayerProfile prof = profile(p);
        prof.lastSeenMs = System.currentTimeMillis();
        PlayerSession s = SESSIONS.remove(p.getUuid());
        if (s != null && s.mainEntity != null && p.getWorld() instanceof ServerWorld w) {
            Entity e = w.getEntity(s.mainEntity);
            if (e != null) e.discard();
        }
        com.horrorsteve.world.IllusionManager.clear(p.getUuid(), p.server);
        state(p.server).markDirty();
    }

    // ------------------------------------------------------------------ tick

    public static void tick(MinecraftServer server) {
        HorrorConfig cfg = HorrorConfig.get();
        if (!cfg.modEnabled) return;
        long now = Scheduler.now();
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            if (p.isSpectator() || p.isRemoved()) continue;
            if ((now + p.getId()) % 20 != 0) continue;
            try {
                perSecond(server, p);
            } catch (Exception e) {
                com.horrorsteve.HorrorSteveMod.LOG.error("Director error for {}", p.getName().getString(), e);
            }
        }
    }

    private static int pick(int[][] table, int stage) {
        int[] r = table[Math.max(0, Math.min(7, stage - 1))];
        return Rand.range(r[0], r[1]);
    }

    private static double endingMultiplier(PlayerProfile prof) {
        double m = 1.0;
        if (prof.flag("ending_escape")) m *= 0.15;
        if (prof.flag("ending_vanish")) m *= 0.04;
        if (prof.flag("ending_true")) m *= 0.05;
        if (prof.flag("ending_peace")) m *= 0.5;
        if (prof.flag("ending_wins")) m *= 1.5;
        return m;
    }

    private static void perSecond(MinecraftServer server, ServerPlayerEntity p) {
        HorrorConfig cfg = HorrorConfig.get();
        PlayerProfile prof = profile(p);
        PlayerSession s = session(p);
        ServerWorld w = (ServerWorld) p.getWorld();
        PlayerTracker.tick(w, p, prof, s);
        StageManager.update(prof);
        InstructionSystem.tick(p, prof, s);
        state(server).markDirty();
        long now = Scheduler.now();
        HorrorSteveEntity main = mainEntityOf(p);
        int stage = effectiveStage(p);
        unknownLogic(p, prof, s, stage);
        if (prof.get(Stat.TICKS_IN_WORLD) < 20L * cfg.graceSeconds) return;
        if (cfg.horrorIntensity <= 0.01) return;
        EndingManager.check(p, prof, s);
        double ending = endingMultiplier(prof);
        double evMult = Math.max(0.05, cfg.eventFrequency) * (0.5 + cfg.horrorIntensity / 2) * ending;
        double entMult = Math.max(0.05, cfg.entityFrequency) * (0.5 + cfg.horrorIntensity / 2) * ending;
        double msgMult = Math.max(0.05, cfg.dialogueFrequency) * ending;

        if (cfg.entityFrequency > 0 && main == null && now >= s.nextAppearTick) {
            s.nextAppearTick = now + (long) (20L * pick(APPEAR_INTERVAL, stage) / entMult);
            if (Rand.chance(0.8)) {
                SpawnLocator.Strategy strat = SpawnLocator.defaultFor(w, p, stage);
                spawnMain(p, strat);
            }
        }
        if (cfg.eventFrequency > 0 && now >= s.nextEventTick) {
            s.nextEventTick = now + (long) (20L * pick(EVENT_INTERVAL, stage) / evMult);
            if (stage >= 2 && Rand.chance(0.8)) runRandomEvent(p);
        }
        if (cfg.dialogueFrequency > 0 && now >= s.nextMessageTick) {
            s.nextMessageTick = now + (long) (20L * pick(MESSAGE_INTERVAL, stage) / msgMult);
            if (Rand.chance(0.7)) DialogueEngine.randomMessage(p, prof, s, stage);
        }
    }

    private static void unknownLogic(ServerPlayerEntity p, PlayerProfile prof, PlayerSession s, int stage) {
        long now = Scheduler.now();
        if (prof.stage >= 7 && !prof.unknownUnlocked && prof.get(Stat.NIGHTS) >= 10 && Rand.chance(1.0 / 600.0)) {
            prof.unknownUnlocked = true;
        }
        if (prof.unknownUnlocked && now >= s.unknownWindowUntil && Rand.chance(1.0 / 420.0)
                && prof.get(Stat.TICKS_IN_WORLD) > 20L * HorrorConfig.get().graceSeconds) {
            openUnknownWindow(p, prof, s);
        }
    }

    public static void openUnknownWindow(ServerPlayerEntity p, PlayerProfile prof, PlayerSession s) {
        s.unknownWindowUntil = Scheduler.now() + 20L * Rand.range(40, 90);
        prof.inc(Stat.UNKNOWN_WINDOWS);
        Advancements.grant(p, "final_encounter");
        EventContext c = ctx(p, null);
        for (String id : new String[]{"unknown_silence", "unknown_watch", "unknown_message"}) {
            HorrorEvent e = EventRegistry.get(id);
            if (e != null && Rand.chance(0.7)) EventRegistry.run(e, c);
        }
    }

    // ------------------------------------------------------------------ events

    public static EventContext ctx(ServerPlayerEntity p, HorrorSteveEntity e) {
        return new EventContext(p.server, (ServerWorld) p.getWorld(), p, profile(p), session(p), effectiveStage(p), e);
    }

    public static boolean runRandomEvent(ServerPlayerEntity p) {
        return EventRegistry.runRandom(ctx(p, mainEntityOf(p)));
    }

    public static boolean runEventNear(ServerPlayerEntity p, HorrorSteveEntity e) {
        return EventRegistry.runRandom(ctx(p, e));
    }

    // ------------------------------------------------------------------ spawning

    private static int lifespanFor(int stage) {
        if (stage <= 1) return 20 * Rand.range(25, 50);
        if (stage == 2) return 20 * Rand.range(40, 80);
        return 20 * Rand.range(60, 150);
    }

    public static HorrorSteveEntity mainEntityOf(ServerPlayerEntity p) {
        PlayerSession s = session(p);
        if (s.mainEntity == null) return null;
        Entity e = ((ServerWorld) p.getWorld()).getEntity(s.mainEntity);
        if (e instanceof HorrorSteveEntity h && !h.isRemoved() && h.getRole() == HorrorSteveEntity.ROLE_MAIN) return h;
        if (e == null) s.mainEntity = null;
        return null;
    }

    public static HorrorSteveEntity spawnMain(ServerPlayerEntity p, SpawnLocator.Strategy strat) {
        ServerWorld w = (ServerWorld) p.getWorld();
        Vec3d pos = SpawnLocator.find(w, p, strat);
        if (pos == null) return null;
        return spawnMainAt(p, pos, strat == SpawnLocator.Strategy.SKY, false);
    }

    public static HorrorSteveEntity spawnMainAt(ServerPlayerEntity p, Vec3d pos, boolean floating, boolean ignoreLimit) {
        HorrorConfig cfg = HorrorConfig.get();
        if (!ignoreLimit && LIVE.size() >= cfg.maxEntitiesTotal) return null;
        if (mainEntityOf(p) != null) return null;
        ServerWorld w = (ServerWorld) p.getWorld();
        HorrorSteveEntity e = ModEntities.HORROR_STEVE.create(w);
        if (e == null) return null;
        int stage = effectiveStage(p);
        e.setRole(HorrorSteveEntity.ROLE_MAIN);
        e.targetId = p.getUuid();
        e.setStageValue(stage);
        e.lifespan = lifespanFor(stage);
        e.refreshPositionAndAngles(pos.x, pos.y, pos.z, 0, 0);
        e.faceToward(p.getPos());
        if (floating) {
            e.setNoGravity(true);
            e.setHsFlag(HorrorSteveEntity.F_FLOAT, true);
        }
        e.hsBrain = new HorrorBrain(e);
        e.hsBrain.enter(HorrorState.WATCHING, stage);
        w.spawnEntity(e);
        LIVE.add(e.getUuid());
        session(p).mainEntity = e.getUuid();
        return e;
    }

    public static HorrorSteveEntity spawnDecoy(ServerPlayerEntity p, Vec3d pos, int lifeTicks, HorrorBrain.DecoyMode mode) {
        if (DECOYS.size() >= 14) return null;
        ServerWorld w = (ServerWorld) p.getWorld();
        HorrorSteveEntity e = ModEntities.HORROR_STEVE.create(w);
        if (e == null) return null;
        e.setRole(HorrorSteveEntity.ROLE_DECOY);
        e.targetId = p.getUuid();
        e.setVisibleTo(p.getUuid());
        e.setStageValue(effectiveStage(p));
        e.setAiDisabled(true);
        e.setInvulnerable(true);
        e.setSilent(true);
        e.noClip = true;
        e.setNoGravity(true);
        e.lifespan = lifeTicks;
        e.refreshPositionAndAngles(pos.x, pos.y, pos.z, 0, 0);
        e.faceToward(p.getPos());
        e.hsBrain = new HorrorBrain(e);
        e.hsBrain.decoyMode = mode;
        w.spawnEntity(e);
        DECOYS.add(e.getUuid());
        return e;
    }

    public static HorrorSteveEntity spawnFakePlayer(ServerPlayerEntity p, Vec3d pos) {
        if (LIVE.size() >= HorrorConfig.get().maxEntitiesTotal + 2) return null;
        ServerWorld w = (ServerWorld) p.getWorld();
        HorrorSteveEntity e = ModEntities.HORROR_STEVE.create(w);
        if (e == null) return null;
        e.setRole(HorrorSteveEntity.ROLE_FAKE_PLAYER);
        e.targetId = p.getUuid();
        e.setStageValue(effectiveStage(p));
        e.lifespan = 20 * 120;
        e.setCustomName(Text.literal(randomFakeName()));
        e.setCustomNameVisible(true);
        e.refreshPositionAndAngles(pos.x, pos.y, pos.z, 0, 0);
        e.faceToward(p.getPos());
        e.hsBrain = new HorrorBrain(e);
        w.spawnEntity(e);
        LIVE.add(e.getUuid());
        return e;
    }

    public static String randomFakeName() {
        String n = DialogueDatabase.pick("fake_players.names");
        return n == null ? "Player" + Rand.range(100, 999) : n;
    }

    public static void spawnBehind(ServerPlayerEntity p) {
        ServerWorld w = (ServerWorld) p.getWorld();
        Vec3d spot = SpawnLocator.behind(w, p, 5, 9);
        if (spot == null) return;
        HorrorSteveEntity main = mainEntityOf(p);
        if (main != null) {
            main.teleportTo(spot.x, spot.y, spot.z);
            main.faceToward(p.getPos());
        } else {
            spawnMainAt(p, spot, false, false);
        }
    }

    public static void dismissMain(ServerPlayerEntity p) {
        HorrorSteveEntity m = mainEntityOf(p);
        if (m == null) return;
        if (m.hsBrain == null) m.hsBrain = new HorrorBrain(m);
        m.hsBrain.forceState(HorrorState.DISAPPEARING);
    }

    public static void startChase(ServerPlayerEntity p) {
        HorrorSteveEntity m = mainEntityOf(p);
        if (m == null) m = spawnMain(p, SpawnLocator.Strategy.NEAR);
        if (m == null) return;
        if (m.hsBrain == null) m.hsBrain = new HorrorBrain(m);
        m.lifespan = Math.max(m.lifespan, m.age + 20 * 90);
        m.hsBrain.forceState(HorrorState.HUNTING);
    }

    public static void onEntityRemoved(HorrorSteveEntity e) {
        LIVE.remove(e.getUuid());
        DECOYS.remove(e.getUuid());
        for (PlayerSession s : SESSIONS.values()) {
            if (e.getUuid().equals(s.mainEntity)) {
                s.mainEntity = null;
                s.nextAppearTick = Math.max(s.nextAppearTick, Scheduler.now() + 20L * Rand.range(40, 120));
            }
        }
    }

    public static int liveCount() {
        return LIVE.size() + DECOYS.size();
    }

    /** Removes every spawned Horror Steve in the server (command / reset). */
    public static int clearEntities(MinecraftServer server) {
        int n = 0;
        for (ServerWorld w : server.getWorlds()) {
            List<Entity> list = new ArrayList<>();
            for (Entity e : w.iterateEntities()) if (e instanceof HorrorSteveEntity) list.add(e);
            for (Entity e : list) {
                e.discard();
                n++;
            }
        }
        return n;
    }

    // ------------------------------------------------------------------ chase

    /** Called when a HUNTING state begins. Every chase mixes a different set of effects, so no two feel alike. */
    public static void onChaseStart(ServerPlayerEntity p) {
        if (p == null) return;
        PlayerSession s = session(p);
        PlayerProfile prof = profile(p);
        ServerWorld w = (ServerWorld) p.getWorld();
        int stage = effectiveStage(p);
        s.lastChaseTick = Scheduler.now();
        com.horrorsteve.fear.FearTracker.spike(prof, 10);
        Sfx.at(p, ModSounds.HEARTBEAT, p.getPos(), 0.8f, 1.0f, false);
        Fx.send(p, FxPayload.SHAKE, 20, 0.5f);
        List<Integer> opts = new ArrayList<>(List.of(0, 1, 2, 3, 4));
        java.util.Collections.shuffle(opts);
        int n = stage >= 6 ? 3 : 2;
        final UUID id = p.getUuid();
        final MinecraftServer server = p.server;
        for (int i = 0; i < n; i++) {
            switch (opts.get(i)) {
                case 0 -> {
                    Fx.send(p, FxPayload.DARKNESS, 140, 0.45f);
                    Fx.send(p, FxPayload.VIGNETTE, 500, 0.8f);
                    EnvironmentEvents.lightsOut(ctx(p, null));
                }
                case 1 -> {
                    for (int k = 0; k < 2; k++) {
                        Vec3d v = SpawnLocator.around(w, p.getPos(), 12, 22, p.getBlockY());
                        if (v != null) spawnDecoy(p, v, 20 * 20, HorrorBrain.DecoyMode.STARE);
                    }
                }
                case 2 -> {
                    for (int k = 0; k < 12; k++) {
                        Scheduler.later(15 * k + 10, () -> {
                            ServerPlayerEntity q = server.getPlayerManager().getPlayer(id);
                            if (q == null || !(q.getWorld() instanceof ServerWorld qw)) return;
                            Vec3d back = q.getPos().subtract(Geo.horizontalLook(q).multiply(3.5));
                            EventUtil.destroyAround(qw, back, 3, 2, HorrorConfig.get().restoreDelaySeconds);
                        });
                    }
                }
                case 3 -> {
                    for (int k = 0; k < 10; k++) {
                        Scheduler.later(30 * k + 20, () -> {
                            ServerPlayerEntity q = server.getPlayerManager().getPlayer(id);
                            if (q != null) Sfx.around(q, Rand.chance(0.5) ? ModSounds.STEP : ModSounds.BREATH, 3, 9, 0.8f, Rand.range(0.8f, 1.1f));
                        });
                    }
                }
                default -> Sfx.music(p, ModSounds.MUSIC_CHASE, 0.7f);
            }
        }
    }
}
