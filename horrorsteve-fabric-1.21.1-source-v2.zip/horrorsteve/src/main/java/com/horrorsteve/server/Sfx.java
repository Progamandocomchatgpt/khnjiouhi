package com.horrorsteve.server;

import com.horrorsteve.config.HorrorConfig;
import com.horrorsteve.util.Geo;
import com.horrorsteve.util.Rand;
import net.minecraft.network.packet.s2c.play.PlaySoundS2CPacket;
import net.minecraft.network.packet.s2c.play.StopSoundS2CPacket;
import net.minecraft.registry.Registries;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.math.Vec3d;

/** Per-player positional audio. Only the target hears these, which lets sounds "come from behind". */
public final class Sfx {
    private Sfx() {}

    public static void at(ServerPlayerEntity p, SoundEvent ev, Vec3d pos, float vol, float pitch, boolean loud) {
        HorrorConfig c = HorrorConfig.get();
        if (!c.soundEffects) return;
        float v = loud && !c.loudSounds ? vol * 0.25f : vol;
        p.networkHandler.sendPacket(new PlaySoundS2CPacket(Registries.SOUND_EVENT.getEntry(ev), SoundCategory.HOSTILE,
                pos.x, pos.y, pos.z, v, pitch, Rand.r().nextLong()));
    }

    /** Plays a sound dist blocks behind the player's view direction. */
    public static void behind(ServerPlayerEntity p, SoundEvent ev, double dist, float vol, float pitch) {
        Vec3d pos = p.getEyePos().subtract(Geo.horizontalLook(p).multiply(dist));
        at(p, ev, pos, vol, pitch, false);
    }

    /** Plays a sound at a random bearing and distance. */
    public static void around(ServerPlayerEntity p, SoundEvent ev, double min, double max, float vol, float pitch) {
        double a = Rand.range(0, Math.PI * 2);
        double d = Rand.range(min, max);
        at(p, ev, p.getPos().add(Math.cos(a) * d, 0, Math.sin(a) * d), vol, pitch, false);
    }

    public static void stopAll(ServerPlayerEntity p) {
        p.networkHandler.sendPacket(new StopSoundS2CPacket(null, null));
    }

    public static void music(ServerPlayerEntity p, SoundEvent ev, float vol) {
        HorrorConfig c = HorrorConfig.get();
        if (!c.music || !c.soundEffects) return;
        p.networkHandler.sendPacket(new PlaySoundS2CPacket(Registries.SOUND_EVENT.getEntry(ev), SoundCategory.MUSIC,
                p.getX(), p.getY(), p.getZ(), vol, 1.0f, Rand.r().nextLong()));
    }
}
