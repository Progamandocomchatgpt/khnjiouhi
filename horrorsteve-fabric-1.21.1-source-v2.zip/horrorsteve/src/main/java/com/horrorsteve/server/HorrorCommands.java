package com.horrorsteve.server;

import com.horrorsteve.ai.SpawnLocator;
import com.horrorsteve.config.HorrorConfig;
import com.horrorsteve.dialogue.DialogueDatabase;
import com.horrorsteve.entity.HorrorSteveEntity;
import com.horrorsteve.events.EventRegistry;
import com.horrorsteve.events.HorrorEvent;
import com.horrorsteve.progression.PlayerProfile;
import com.horrorsteve.progression.StageManager;
import com.horrorsteve.progression.Stat;
import com.horrorsteve.world.IllusionManager;
import com.horrorsteve.world.RestorationManager;
import com.horrorsteve.world.StructureBuilder;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.command.CommandSource;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

/** /horrorsteve ... (operators). Handy for testing: spawn, stage, event, meme, jumpscare, ending, reset. */
public final class HorrorCommands {
    private HorrorCommands() {}

    private static void say(CommandContext<ServerCommandSource> c, String msg) {
        c.getSource().sendFeedback(() -> Text.literal(msg), false);
    }

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(CommandManager.literal("horrorsteve")
                    .requires(src -> src.hasPermissionLevel(2))
                    .then(CommandManager.literal("status").executes(c -> {
                        ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
                        PlayerProfile prof = HorrorDirector.profile(p);
                        say(c, "stage " + HorrorDirector.effectiveStage(p) + " (stored " + prof.stage + "), score "
                                + String.format("%.1f", prof.score) + ", fear " + String.format("%.0f", prof.fear)
                                + ", trait " + prof.dominantTrait() + ", endings mask " + prof.endings);
                        say(c, "encounters " + prof.get(Stat.ENCOUNTERS) + ", talks " + prof.get(Stat.CONVERSATIONS)
                                + ", deaths " + prof.get(Stat.DEATHS) + ", nights " + prof.get(Stat.NIGHTS)
                                + ", 67 uses " + prof.get(Stat.MEME67) + ", live entities " + HorrorDirector.liveCount());
                        return 1;
                    }))
                    .then(CommandManager.literal("spawn").executes(c -> {
                        ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
                        HorrorSteveEntity e = HorrorDirector.spawnMain(p, SpawnLocator.Strategy.FRONT);
                        if (e == null) e = HorrorDirector.spawnMain(p, SpawnLocator.Strategy.NEAR);
                        say(c, e != null ? "Spawned Horror Steve." : "No valid spot found (or one already exists).");
                        return e != null ? 1 : 0;
                    }))
                    .then(CommandManager.literal("stage")
                            .then(CommandManager.argument("n", IntegerArgumentType.integer(0, 8)).executes(c -> {
                                ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
                                int n = IntegerArgumentType.getInteger(c, "n");
                                PlayerSession s = HorrorDirector.session(p);
                                PlayerProfile prof = HorrorDirector.profile(p);
                                s.forcedStage = n;
                                if (n >= 1 && n <= 7) {
                                    prof.stage = n;
                                    prof.score = Math.max(prof.score, StageManager.thresholdFor(n));
                                } else if (n == 8) {
                                    prof.unknownUnlocked = true;
                                }
                                say(c, n == 0 ? "Stage back to automatic." : "Stage forced to " + n + " (use 0 to return to automatic).");
                                return 1;
                            })))
                    .then(CommandManager.literal("event")
                            .then(CommandManager.argument("id", StringArgumentType.word())
                                    .suggests((c, b) -> CommandSource.suggestMatching(EventRegistry.ids(), b))
                                    .executes(c -> {
                                        ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
                                        HorrorEvent e = EventRegistry.get(StringArgumentType.getString(c, "id"));
                                        if (e == null) {
                                            say(c, "Unknown event.");
                                            return 0;
                                        }
                                        EventRegistry.run(e, HorrorDirector.ctx(p, HorrorDirector.mainEntityOf(p)));
                                        say(c, "Ran event " + e.id);
                                        return 1;
                                    })))
                    .then(CommandManager.literal("events").executes(c -> {
                        say(c, EventRegistry.count() + " events: " + String.join(", ", EventRegistry.ids()));
                        return 1;
                    }))
                    .then(CommandManager.literal("say")
                            .then(CommandManager.argument("text", StringArgumentType.greedyString()).executes(c -> {
                                ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
                                Messenger.say(p, StringArgumentType.getString(c, "text"));
                                return 1;
                            })))
                    .then(CommandManager.literal("fear")
                            .then(CommandManager.argument("n", IntegerArgumentType.integer(0, 100)).executes(c -> {
                                ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
                                HorrorDirector.profile(p).fear = IntegerArgumentType.getInteger(c, "n");
                                return 1;
                            })))
                    .then(CommandManager.literal("meme").executes(c -> {
                        ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
                        boolean ok = Meme67.trigger(p, true);
                        say(c, ok ? "67." : "Could not stage the 67 scene here.");
                        return ok ? 1 : 0;
                    }))
                    .then(CommandManager.literal("chase").executes(c -> {
                        HorrorDirector.startChase(c.getSource().getPlayerOrThrow());
                        return 1;
                    }))
                    .then(CommandManager.literal("jumpscare")
                            .then(CommandManager.argument("type", StringArgumentType.word())
                                    .suggests((c, b) -> CommandSource.suggestMatching(java.util.List.of("face", "blackout", "behind", "rush", "crash", "title"), b))
                                    .executes(c -> {
                                        ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
                                        boolean ok = switch (StringArgumentType.getString(c, "type")) {
                                            case "face" -> Jumpscares.face(p, true);
                                            case "blackout" -> Jumpscares.blackout(p, true);
                                            case "behind" -> Jumpscares.behind(p, true);
                                            case "rush" -> Jumpscares.rush(p, true);
                                            case "crash" -> Jumpscares.fakeCrash(p, true);
                                            case "title" -> Jumpscares.fakeTitle(p, true);
                                            default -> false;
                                        };
                                        return ok ? 1 : 0;
                                    })))
                    .then(CommandManager.literal("ending")
                            .then(CommandManager.argument("name", StringArgumentType.word())
                                    .suggests((c, b) -> CommandSource.suggestMatching(java.util.Arrays.stream(EndingManager.Ending.values()).map(e -> e.key).toList(), b))
                                    .executes(c -> {
                                        ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
                                        String n = StringArgumentType.getString(c, "name");
                                        for (EndingManager.Ending e : EndingManager.Ending.values()) {
                                            if (e.key.equals(n)) return EndingManager.trigger(p, e) ? 1 : 0;
                                        }
                                        return 0;
                                    })))
                    .then(CommandManager.literal("structure").executes(c -> {
                        ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
                        boolean ok = StructureBuilder.buildRandom((net.minecraft.server.world.ServerWorld) p.getWorld(), p);
                        say(c, ok ? "A structure was built somewhere nearby." : "No valid site found (try again, or check structuresEnabled).");
                        return ok ? 1 : 0;
                    }))
                    .then(CommandManager.literal("clear").executes(c -> {
                        int n = HorrorDirector.clearEntities(c.getSource().getServer());
                        int r = RestorationManager.restoreAll(c.getSource().getServer());
                        IllusionManager.clearAll(c.getSource().getServer());
                        say(c, "Removed " + n + " entities, restored " + r + " blocks.");
                        return 1;
                    }))
                    .then(CommandManager.literal("reset").executes(c -> {
                        ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
                        HorrorDirector.profile(p).resetAll();
                        HorrorDirector.session(p).forcedStage = 0;
                        say(c, "Your profile was wiped. It has forgotten you.");
                        return 1;
                    }))
                    .then(CommandManager.literal("reload").executes(c -> {
                        HorrorConfig.load();
                        DialogueDatabase.reload();
                        say(c, "Config and dialogue reloaded (" + DialogueDatabase.totalLines() + " lines).");
                        return 1;
                    }))
                    .then(CommandManager.literal("dialogue").executes(c -> {
                        say(c, DialogueDatabase.totalLines() + " dialogue lines loaded, language " + HorrorConfig.get().language);
                        return 1;
                    })));
        });
    }
}
