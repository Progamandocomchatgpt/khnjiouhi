package com.horrorsteve.server;

import com.horrorsteve.dialogue.DialogueDatabase;
import com.horrorsteve.network.FxPayload;
import com.horrorsteve.progression.PlayerProfile;
import com.horrorsteve.progression.Stat;
import com.horrorsteve.progression.Trait;
import com.horrorsteve.util.Rand;
import com.horrorsteve.util.Scheduler;
import net.minecraft.server.network.ServerPlayerEntity;

import java.util.List;
import java.util.UUID;

/** Seven hidden endings chosen purely by how the player behaved. Each leaves a permanent mark on the haunting. */
public final class EndingManager {
    public enum Ending {
        ESCAPE("escape"), VANISH("vanish"), WINS("wins"), WORLD("world"), PEACE("peace"), UNKNOWN("unknown"), TRUE("true");

        public final String key;

        Ending(String key) {
            this.key = key;
        }
    }

    private EndingManager() {}

    public static void check(ServerPlayerEntity p, PlayerProfile prof, PlayerSession s) {
        long now = Scheduler.now();
        if (now - s.lastEndingCheck < 20 * 60) return;
        s.lastEndingCheck = now;
        if (Scheduler.now() < s.chaseUntil) return;
        int stage = prof.stage;
        if (stage < 5) return;
        long talk = prof.get(Stat.CONVERSATIONS);
        if (!has(prof, Ending.TRUE) && prof.get(Stat.UNKNOWN_WINDOWS) >= 4 && prof.get(Stat.MEME67) >= 3
                && prof.get(Stat.NIGHTS) >= 15 && talk >= 40 && prof.get(Stat.INSULTS) <= 5 && Rand.chance(1.0 / 12.0)) {
            trigger(p, Ending.TRUE);
        } else if (!has(prof, Ending.UNKNOWN) && prof.get(Stat.UNKNOWN_WINDOWS) >= 6 && stage >= 7) {
            trigger(p, Ending.UNKNOWN);
        } else if (!has(prof, Ending.PEACE) && talk >= 25 && prof.get(Stat.ATTACKS) == 0 && prof.get(Stat.INSULTS) < 3
                && prof.get(Stat.DEATHS) <= 3 && prof.get(Stat.NIGHTS) >= 8) {
            trigger(p, Ending.PEACE);
        } else if (!has(prof, Ending.WINS) && stage >= 6 && prof.get(Stat.DEATHS) >= 8 && prof.fear > 60) {
            trigger(p, Ending.WINS);
        } else if (!has(prof, Ending.VANISH) && prof.get(Stat.ATTACKS) >= 25 && prof.trait(Trait.AGGRESSIVE) >= 50) {
            trigger(p, Ending.VANISH);
        } else if (!has(prof, Ending.ESCAPE) && prof.get(Stat.ESCAPES) >= 6 && prof.get(Stat.IGNORED) >= 5 && !prof.flag("ending_wins")) {
            trigger(p, Ending.ESCAPE);
        } else if (!has(prof, Ending.WORLD) && stage >= 6 && prof.get(Stat.STRUCTURES_VISITED) >= 4 && prof.get(Stat.SIGNS_READ) >= 4) {
            trigger(p, Ending.WORLD);
        }
    }

    private static boolean has(PlayerProfile prof, Ending e) {
        return prof.hasEnding(e.ordinal());
    }

    public static boolean trigger(ServerPlayerEntity p, Ending e) {
        PlayerProfile prof = HorrorDirector.profile(p);
        if (has(prof, e)) return false;
        prof.endings |= 1 << e.ordinal();
        prof.setFlag("ending_" + e.key);
        List<String> lines = DialogueDatabase.get("ending." + e.key);
        final UUID id = p.getUuid();
        final net.minecraft.server.MinecraftServer server = p.server;
        int t = 20;
        for (String line : lines) {
            final String l = line;
            Scheduler.later(t, () -> {
                ServerPlayerEntity q = server.getPlayerManager().getPlayer(id);
                if (q == null) return;
                Messenger.say(q, l);
                Fx.send(q, FxPayload.VIGNETTE, 120, 0.5f);
            });
            t += Rand.range(90, 140);
        }
        Scheduler.later(t, () -> {
            ServerPlayerEntity q = server.getPlayerManager().getPlayer(id);
            if (q != null) Advancements.grant(q, "ending_" + e.key);
        });
        return true;
    }
}
