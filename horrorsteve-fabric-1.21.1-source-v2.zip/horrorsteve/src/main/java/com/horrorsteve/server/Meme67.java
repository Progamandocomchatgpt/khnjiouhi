package com.horrorsteve.server;

import com.horrorsteve.ai.HorrorState;
import com.horrorsteve.ai.SpawnLocator;
import com.horrorsteve.config.HorrorConfig;
import com.horrorsteve.dialogue.DialogueDatabase;
import com.horrorsteve.entity.HorrorSteveEntity;
import com.horrorsteve.network.OverlayPayload;
import com.horrorsteve.progression.PlayerProfile;
import com.horrorsteve.progression.Stat;
import com.horrorsteve.sound.ModSounds;
import com.horrorsteve.util.Geo;
import com.horrorsteve.util.Rand;
import com.horrorsteve.util.Scheduler;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.Vec3d;

/**
 * The 67 secret. Server-side exact-match detection ("67" and nothing else), per-player cooldown, Stat.MEME67, and a scripted
 * scene: the entity appears in front of you, stares, does the exaggerated 67 gesture, 67 flashes on screen, then it goes
 * completely serious again and drops back into normal horror behaviour.
 */
public final class Meme67 {
    private enum Variant { NORMAL, LONG_STARE, DOUBLE, GLITCH }

    private Meme67() {}

    /** True only for a message that is exactly 67 (surrounding whitespace ignored). 167, 670, 67abc, "67 67" are all no. */
    public static boolean isMeme(String content) {
        return content != null && content.trim().equals("67");
    }

    public static boolean trigger(ServerPlayerEntity p, boolean force) {
        HorrorConfig cfg = HorrorConfig.get();
        if (!force && (!cfg.modEnabled || !cfg.meme67Enabled)) return false;
        PlayerSession s = HorrorDirector.session(p);
        long now = Scheduler.now();
        if (!force && now - s.lastMemeTick < 20L * cfg.meme67CooldownSeconds) return false;
        ServerWorld w = (ServerWorld) p.getWorld();
        Vec3d front = frontOf(w, p);

        HorrorSteveEntity e = HorrorDirector.mainEntityOf(p);
        if (e == null) e = HorrorDirector.spawnMainAt(p, front, false, true);
        if (e == null) return false;
        if (e.hsBrain == null) e.hsBrain = new com.horrorsteve.ai.HorrorBrain(e);
        s.lastMemeTick = now;
        PlayerProfile prof = HorrorDirector.profile(p);
        prof.inc(Stat.MEME67);
        Advancements.grant(p, "why_67");

        Variant v = Rand.weighted(java.util.List.of(Variant.values()), x -> switch (x) {
            case NORMAL -> 70;
            case LONG_STARE -> 18;
            case DOUBLE -> 6;
            case GLITCH -> 6;
        });
        final int stare = v == Variant.LONG_STARE ? Rand.range(80, 150) : v == Variant.GLITCH ? 45 : 22;
        final int animLen = v == Variant.DOUBLE ? 150 : 72;
        final int total = stare + animLen + 45;
        final HorrorSteveEntity ent = e;
        final int animKind = Rand.chance(0.5) ? HorrorSteveEntity.ANIM_MEME67 : HorrorSteveEntity.ANIM_MEME67_B;

        e.lifespan = Math.max(e.lifespan, e.age + total + 200);
        e.teleportTo(front.x, front.y, front.z);
        e.faceToward(p.getPos());
        ent.hsBrain.interrupt(HorrorState.PERFORMING_67, total, () -> returnToHorror(p, ent));
        Sfx.at(p, ModSounds.STATIC, front, 0.3f, 1.4f, false);
        w.spawnParticles(ParticleTypes.SMOKE, front.x, front.y + 1, front.z, 8, 0.2, 0.6, 0.2, 0.01);

        if (v == Variant.GLITCH) {
            Scheduler.later(10, () -> {
                if (!ent.isRemoved()) ent.setDistort(HorrorSteveEntity.D_FLICKER);
            });
            Scheduler.later(36, () -> {
                if (!ent.isRemoved()) ent.setDistort(HorrorSteveEntity.D_NONE);
            });
        }
        // the gesture
        Scheduler.later(stare, () -> {
            if (ent.isRemoved()) return;
            ent.setAnim(animKind);
            Sfx.at(p, ModSounds.MEME67, ent.getPos(), 1.0f, 1.0f, false);
        });
        Scheduler.later(stare + 12, () -> showText(w, p, ent));
        if (v == Variant.DOUBLE) {
            Scheduler.later(stare + 78, () -> {
                if (ent.isRemoved()) return;
                ent.setAnim(animKind == HorrorSteveEntity.ANIM_MEME67 ? HorrorSteveEntity.ANIM_MEME67_B : HorrorSteveEntity.ANIM_MEME67);
                Sfx.at(p, ModSounds.MEME67, ent.getPos(), 1.0f, 1.2f, false);
                showText(w, p, ent);
            });
        }
        // and back to serious
        Scheduler.later(stare + animLen, () -> {
            if (ent.isRemoved()) return;
            ent.setAnim(HorrorSteveEntity.ANIM_NONE);
            if (Rand.chance(0.4)) {
                ent.setDistort(HorrorSteveEntity.D_BLANK);
                Scheduler.later(14, () -> {
                    if (!ent.isRemoved()) ent.setDistort(HorrorSteveEntity.D_NONE);
                });
            }
            Advancements.grant(p, "knows_the_meme");
        });
        Scheduler.later(stare + animLen + 14, () -> {
            String line = Rand.chance(0.2) && DialogueDatabase.has("meme67.rare_after")
                    ? DialogueDatabase.pick("meme67.rare_after") : DialogueDatabase.pick("meme67.after");
            if (line != null && !p.isRemoved() && Rand.chance(0.75)) Messenger.say(p, line);
        });
        return true;
    }

    private static void showText(ServerWorld w, ServerPlayerEntity p, HorrorSteveEntity ent) {
        String text = DialogueDatabase.has("meme67.overlay") ? DialogueDatabase.pick("meme67.overlay") : "67";
        for (ServerPlayerEntity o : w.getPlayers()) {
            if (o == p || (!o.isSpectator() && o.squaredDistanceTo(ent) < 48 * 48)) {
                Fx.overlay(o, OverlayPayload.TEXT_67, text, 36);
            }
        }
    }

    private static void returnToHorror(ServerPlayerEntity p, HorrorSteveEntity e) {
        if (e.isRemoved() || p.isRemoved()) return;
        ServerWorld w = (ServerWorld) e.getWorld();
        e.setAnim(HorrorSteveEntity.ANIM_NONE);
        if (Rand.chance(0.55)) {
            Vec3d spot = SpawnLocator.around(w, p.getPos(), 16, 30, p.getBlockY());
            if (spot != null) {
                Sfx.at(p, ModSounds.TELEPORT, e.getPos(), 0.4f, 0.9f, false);
                e.teleportTo(spot.x, spot.y, spot.z);
                e.faceToward(p.getPos());
                e.hsBrain.forceState(HorrorState.WATCHING);
                return;
            }
        }
        e.hsBrain.forceState(HorrorState.DISAPPEARING);
    }

    private static Vec3d frontOf(ServerWorld w, ServerPlayerEntity p) {
        Vec3d look = Geo.horizontalLook(p);
        for (double d : new double[]{2.4, 2.0, 3.0, 1.6}) {
            Vec3d t = p.getPos().add(look.multiply(d));
            Vec3d g = SpawnLocator.ground(w, (int) Math.floor(t.x), (int) Math.floor(t.z), p.getBlockY(), 2, 3);
            if (g != null) return g;
        }
        return p.getPos().add(look.multiply(2.4));
    }
}
