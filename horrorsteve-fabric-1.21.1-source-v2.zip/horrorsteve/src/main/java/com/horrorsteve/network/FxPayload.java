package com.horrorsteve.network;

import com.horrorsteve.HorrorSteveMod;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** Server -> client: a screen/camera effect. Clients filter it through their own accessibility config. */
public record FxPayload(int type, int ticks, float intensity) implements CustomPayload {
    public static final CustomPayload.Id<FxPayload> ID = new CustomPayload.Id<>(HorrorSteveMod.id("fx"));
    public static final PacketCodec<RegistryByteBuf, FxPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.VAR_INT, FxPayload::type,
            PacketCodecs.VAR_INT, FxPayload::ticks,
            PacketCodecs.FLOAT, FxPayload::intensity,
            FxPayload::new);

    public static final int SHAKE = 1;
    public static final int VIGNETTE = 2;
    public static final int DARKNESS = 3;
    public static final int STATIC = 4;
    public static final int FOV_NARROW = 5;
    public static final int FOV_WIDE = 6;
    public static final int FLASH = 7;
    public static final int TILT = 8;
    public static final int BLACKOUT = 9;
    public static final int GLITCH = 10;

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}
