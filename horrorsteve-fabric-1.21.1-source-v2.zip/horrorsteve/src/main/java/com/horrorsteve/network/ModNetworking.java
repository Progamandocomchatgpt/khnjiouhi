package com.horrorsteve.network;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;

public final class ModNetworking {
    private ModNetworking() {}

    public static void registerCommon() {
        PayloadTypeRegistry.playS2C().register(FxPayload.ID, FxPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(OverlayPayload.ID, OverlayPayload.CODEC);
    }
}
