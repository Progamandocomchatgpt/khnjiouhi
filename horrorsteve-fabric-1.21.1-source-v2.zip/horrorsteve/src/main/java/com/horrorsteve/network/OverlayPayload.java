package com.horrorsteve.network;

import com.horrorsteve.HorrorSteveMod;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;

/** Server -> client: a HUD-only fake screen or big text. Never replaces a real screen, never blocks input. */
public record OverlayPayload(int kind, String text, int ticks) implements CustomPayload {
    public static final CustomPayload.Id<OverlayPayload> ID = new CustomPayload.Id<>(HorrorSteveMod.id("overlay"));
    public static final PacketCodec<RegistryByteBuf, OverlayPayload> CODEC = PacketCodec.tuple(
            PacketCodecs.VAR_INT, OverlayPayload::kind,
            PacketCodecs.STRING, OverlayPayload::text,
            PacketCodecs.VAR_INT, OverlayPayload::ticks,
            OverlayPayload::new);

    public static final int TEXT_67 = 1;
    public static final int FAKE_CRASH = 2;
    public static final int FAKE_TITLE = 3;
    public static final int FAKE_LOADING = 4;
    public static final int FACE = 5;
    public static final int BIG_TEXT = 6;
    public static final int FAKE_SAVING = 7;

    @Override
    public Id<? extends CustomPayload> getId() {
        return ID;
    }
}
