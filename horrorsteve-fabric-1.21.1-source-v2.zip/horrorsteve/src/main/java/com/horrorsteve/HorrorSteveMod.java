package com.horrorsteve;

import com.horrorsteve.config.HorrorConfig;
import com.horrorsteve.events.EventRegistry;
import com.horrorsteve.item.ModItems;
import com.horrorsteve.entity.ModEntities;
import com.horrorsteve.network.ModNetworking;
import com.horrorsteve.server.HorrorCommands;
import com.horrorsteve.server.ServerHooks;
import com.horrorsteve.sound.ModSounds;
import net.fabricmc.api.ModInitializer;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HorrorSteveMod implements ModInitializer {
    public static final String MOD_ID = "horrorsteve";
    public static final Logger LOG = LoggerFactory.getLogger("HorrorSteve");
    /** Entities saved by a previous session carry an old token and are removed on load. */
    public static final int SESSION = new java.util.Random().nextInt();

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        HorrorConfig.load();
        ModSounds.register();
        ModEntities.register();
        ModItems.register();
        ModNetworking.registerCommon();
        EventRegistry.bootstrap();
        ServerHooks.register();
        HorrorCommands.register();
        LOG.info("Horror Steve initialised. Nothing here touches your files.");
    }
}
