package com.horrorsteve.util;

import com.horrorsteve.HorrorSteveMod;

import java.util.PriorityQueue;

/** Tiny server-thread task scheduler. Tasks run on the server tick that reaches their due time. */
public final class Scheduler {
    private static final class Task implements Comparable<Task> {
        final long due;
        final long seq;
        final Runnable run;

        Task(long due, long seq, Runnable run) {
            this.due = due;
            this.seq = seq;
            this.run = run;
        }

        @Override
        public int compareTo(Task o) {
            int c = Long.compare(due, o.due);
            return c != 0 ? c : Long.compare(seq, o.seq);
        }
    }

    private static final PriorityQueue<Task> QUEUE = new PriorityQueue<>();
    private static long now = 0;
    private static long seq = 0;

    private Scheduler() {}

    public static long now() {
        return now;
    }

    public static void later(int ticks, Runnable r) {
        QUEUE.add(new Task(now + Math.max(0, ticks), seq++, r));
    }

    public static void tick() {
        now++;
        while (!QUEUE.isEmpty() && QUEUE.peek().due <= now) {
            Task t = QUEUE.poll();
            try {
                t.run.run();
            } catch (Throwable e) {
                HorrorSteveMod.LOG.error("Scheduled task failed", e);
            }
        }
    }

    public static void clear() {
        QUEUE.clear();
    }
}
