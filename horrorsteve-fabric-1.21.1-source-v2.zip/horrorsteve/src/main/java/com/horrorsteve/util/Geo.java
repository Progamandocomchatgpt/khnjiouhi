package com.horrorsteve.util;

import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class Geo {
    private Geo() {}

    /** Minecraft yaw (degrees) that faces from one point towards another. */
    public static float yawTo(Vec3d from, Vec3d to) {
        double dx = to.x - from.x;
        double dz = to.z - from.z;
        return (float) Math.toDegrees(Math.atan2(-dx, dz));
    }

    public static float pitchTo(Vec3d from, Vec3d to) {
        double dx = to.x - from.x;
        double dy = to.y - from.y;
        double dz = to.z - from.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        return (float) -Math.toDegrees(Math.atan2(dy, h));
    }

    public static Vec3d horizontalLook(Entity e) {
        double yaw = Math.toRadians(e.getYaw());
        return new Vec3d(-Math.sin(yaw), 0, Math.cos(yaw));
    }

    /** Where "target" is relative to the way "viewer" is facing. */
    public static String describe(Entity viewer, Vec3d target) {
        Vec3d rel = target.subtract(viewer.getPos());
        double h = Math.sqrt(rel.x * rel.x + rel.z * rel.z);
        if (rel.length() > 90) return "far away";
        if (rel.y > 6 && rel.y > h) return "above you";
        if (rel.y < -6 && -rel.y > h) return "below you";
        float diff = MathHelper.wrapDegrees(yawTo(viewer.getPos(), target) - viewer.getYaw());
        float a = Math.abs(diff);
        if (a < 45) return "in front of you";
        if (a > 135) return "behind you";
        return diff > 0 ? "to your right" : "to your left";
    }

    public static String opposite(String dir) {
        return switch (dir) {
            case "in front of you" -> "behind you";
            case "behind you" -> "in front of you";
            case "to your left" -> "to your right";
            case "to your right" -> "to your left";
            case "above you" -> "below you";
            case "below you" -> "above you";
            default -> "behind you";
        };
    }
}
