package com.horrorsteve.util;

import java.util.List;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;
import java.util.function.ToDoubleFunction;

public final class Rand {
    private Rand() {}

    public static Random r() {
        return ThreadLocalRandom.current();
    }

    public static boolean chance(double p) {
        return r().nextDouble() < p;
    }

    public static int range(int lo, int hiInclusive) {
        if (hiInclusive <= lo) return lo;
        return lo + r().nextInt(hiInclusive - lo + 1);
    }

    public static float range(float lo, float hi) {
        return lo + r().nextFloat() * (hi - lo);
    }

    public static double range(double lo, double hi) {
        return lo + r().nextDouble() * (hi - lo);
    }

    public static <T> T pick(List<T> list) {
        if (list == null || list.isEmpty()) return null;
        return list.get(r().nextInt(list.size()));
    }

    @SafeVarargs
    public static <T> T pick(T... items) {
        return items[r().nextInt(items.length)];
    }

    public static <T> T weighted(List<T> items, ToDoubleFunction<T> weight) {
        double total = 0;
        for (T t : items) total += Math.max(0, weight.applyAsDouble(t));
        if (total <= 0 || items.isEmpty()) return null;
        double roll = r().nextDouble() * total;
        for (T t : items) {
            roll -= Math.max(0, weight.applyAsDouble(t));
            if (roll <= 0) return t;
        }
        return items.get(items.size() - 1);
    }

    public static double lerp(double a, double b, double t) {
        return a + (b - a) * Math.max(0, Math.min(1, t));
    }
}
