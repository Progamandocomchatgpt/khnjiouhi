# Horror Steve (Fabric 1.21.1)

A psychological-horror mod. Something that looks exactly like Steve watches you, follows you, remembers what you do and
talks back. English only. Fully offline: no API, no internet, nothing written outside the game's own config/world folders.

Status: source is complete, all JSON/resources validate and Java syntax checks. It has NOT been compiled or launched yet
(see "Build"). Expect to fix a few Minecraft API name mismatches on the first build.

## Build
Requires JDK 21 and internet access (Gradle downloads Minecraft + Fabric).

    gradle wrapper --gradle-version 8.10.2     # once, creates gradlew + the wrapper jar
    ./gradlew build                            # Windows: gradlew.bat build

The mod jar is `build/libs/horrorsteve-1.0.0.jar` (ignore the `-sources` jar).
To run a dev client: `./gradlew runClient`.

Versions (gradle.properties): Minecraft 1.21.1, Yarn 1.21.1+build.3, Fabric Loader 0.16.5, Fabric API 0.105.0+1.21.1, Loom 1.7-SNAPSHOT.

## Install
Put `horrorsteve-1.0.0.jar` and Fabric API in `.minecraft/mods`. Needs Fabric Loader for 1.21.1 and Java 21.

## Test it quickly (operator, level 2)
By default nothing happens for the first 5 minutes of playtime. Commands skip that:

    /horrorsteve spawn            spawn Horror Steve in front of you
    /horrorsteve stage 1..8       force a stage (0 = automatic). 8 = the "unknown" stage
    /horrorsteve events           list every event id
    /horrorsteve event door_open  run one event
    /horrorsteve chase | jumpscare face|blackout|behind|rush|crash|title
    /horrorsteve ending peace|escape|wins|vanish|world|unknown|true
    /horrorsteve structure        build one of its structures near you
    /horrorsteve status | fear 80 | say hello | clear | reset | reload

Spawn egg: Creative inventory > Spawn Eggs > Horror Steve Spawn Egg.

## The 67 Easter egg
Type exactly `67` in chat (nothing else; 167, 670, "67 67", 67abc do nothing). Detected on the server, per-player cooldown
(`meme67CooldownSeconds`, default 45), counted in `Stat.MEME67`. Steve appears in front of you, stares, does the 67 gesture,
"67" flashes on screen (also for nearby players), then it goes serious ("Don't do that again.") and teleports away or fades.
Rare variants: long stare, double gesture, glitch. Test without chat: `/horrorsteve meme`.

## Configuration
`config/horrorsteve.json` (server): modEnabled, language ("en"), horrorIntensity (0-2), entityFrequency, eventFrequency,
dialogueFrequency, jumpscareFrequency, progressionSpeed, soundEffects, music, loudSounds, cameraEffects, visualDistortion,
jumpscares, fakeSystemMessages, blockDestruction, maxDestructionRadius, restoreDelaySeconds, structuresEnabled,
multiplayerBehavior (PER_PLAYER | SHARED), meme67Enabled, meme67CooldownSeconds, graceSeconds, maxEntitiesTotal, debug.

`config/horrorsteve-client.json` (each player, accessibility): allowFlashing, allowScreenShake, allowFovEffects,
allowVignette, allowStaticNoise, allowDarkness, allowFakeScreens, allowJumpscareVisuals, allowModelDistortion, effectStrength.
`/horrorsteve reload` re-reads the server config and dialogue.

## Add or change dialogue
Bundled lines: `src/main/resources/data/horrorsteve/dialogue/en.json` (about 650 lines). Nested keys become dotted keys, e.g.
`responses.greeting.early`. Without rebuilding, drop any `*.json` into `config/horrorsteve/dialogue/` with the same shape;
its lines are appended. Placeholders: `{name}`, `{msg}`, `{dir}`, `{mod}`. Run `/horrorsteve reload`.

## Add an event
In any class under `events/`:

    EventRegistry.add("my_event", EventRarity.UNCOMMON, 3 /*min stage*/, 7 /*max stage*/, 120 /*cooldown s*/,
        c -> true /*condition*/, c -> Messenger.say(c.player(), "Hi."));

Register it from `EventRegistry.bootstrap()` (or any existing `register()`). `EventContext` gives server, world, player, profile,
session, stage and (optionally) the entity.

## Safety
Illusions are packets to one player (never real blocks). Real block changes only touch natural blocks, are logged in
`horrorsteve_world`, are put back after `restoreDelaySeconds`, never overwrite a block the player changed, and are all
restored when the server stops. Bedrock, block entities, fluids and the spawn area are protected. Fake crash/title/loading
screens are HUD drawings: they never replace a real screen, block input, or touch files.

## Layout
`entity` (Horror Steve, roles MAIN/DECOY/FAKE_PLAYER) - `ai` (state machine, eye contact, spawn locator) - `dialogue`
(classifier, engine, memory) - `events` - `fear` - `progression` (stats, traits, 8 stages) - `server` (director, hooks,
commands, 67, endings, jumpscares) - `world` (restoration, illusions, structures, protection) - `network` - `client`
(renderer, model, HUD effects) - `sound` - `item` - `config` - `util`.
